# Site yuu : dossier prêt à mettre en ligne (Netlify)

Contenu :
- `index.html` : le site complet (disque 3D, boutique, panneau de modification).
- `assets/` : toutes les images et le son d'ambiance.
- `legal.html` : modèle de mentions légales et CGV à compléter.
- `404.html` : page « introuvable » à ton image (remplace la page par défaut de Netlify).
- `netlify.toml` + `build.mjs` : à chaque déploiement, fabriquent le dossier `dist` (le seul publié sur le site) et protègent les secrets.
- `netlify/` : la porte d'ouverture, le paiement et le classement (petits services côté serveur). `package.json`, `.npmrc`, `.gitignore` : à envoyer aussi.

Envoie TOUT le contenu de ce dossier sur GitHub (fichiers commençant par un point compris).

## 1. Mettre en ligne avec mise à jour automatique (Netlify + GitHub)
1. Crée un dépôt GitHub **privé** (indispensable : il contient tes produits et réglages), par exemple `yuu-site`, et envoie-y tout le contenu de ce dossier (« Add file » puis « Upload files »).
2. Sur Netlify : « Add new site », « Import an existing project », GitHub, ton dépôt. Les réglages sont lus dans `netlify.toml` : laisse tout par défaut et clique « Deploy ».
3. À chaque changement du dépôt, Netlify republie tout seul en 30 secondes à 1 minute.

Si tu glisses le dossier à la main dans Netlify (« Drop »), le site marche, mais « Enregistrer et publier » depuis le panneau ne pourra pas le mettre à jour : passe par GitHub.

## 2. Ton nom de domaine OVH
1. Netlify : « Domain management », « Add a domain », ton domaine. Netlify affiche les valeurs DNS à utiliser.
2. OVH : « Noms de domaine », ton domaine, onglet « Zone DNS ». Supprime les anciens enregistrements A/CNAME de `@` et `www`, puis ajoute ceux demandés par Netlify (un A pour le domaine nu, un CNAME `www` vers `ton-site.netlify.app`).
3. Attends la propagation (quelques minutes à quelques heures), puis dans Netlify : « HTTPS », « Verify DNS », « Provision certificate ».

## 3. Te donner le droit de tout modifier depuis le site
1. GitHub : ton profil, « Settings », « Developer settings », « Personal access tokens », « Fine-grained tokens », « Generate new token ».
2. « Repository access » : « Only select repositories », ton dépôt. « Permissions » : **Contents = Read and write**.
3. Copie le jeton (`github_pat_…`) dans ton gestionnaire de mots de passe.
4. Ouvre `https://ton-domaine/#admin` : dépôt `TON-PSEUDO/yuu-site`, branche `main`, jeton. Le bouton « Personnaliser le site » apparaît.
5. Refais l'étape 4 sur chaque appareil (ordinateur, téléphone). Les visiteurs n'ont pas ton jeton : ils ne voient aucun outil et ne peuvent rien publier.

## 4. Modifier
- Panneau, puis « Enregistrer et publier » : enregistré dans GitHub, Netlify republie en ~1 minute.
- Double-clic sur un texte ou une photo de produit : enregistré automatiquement.

## 5. Mode maintenance (fermeture réelle, côté serveur)
**Depuis le site (toi seul)** : bouton rouge « 🔧 Activer la maintenance » en bas à droite (après connexion `#admin`). Les réglages (textes, mot de passe d'accès équipe) sont dans l'onglet « Contact & ouverture » du panneau.

**Depuis Netlify** : variable `MAINTENANCE` = `on` (fermé), `off` (ouvert), ou absente (le panneau décide). Facultatif : `MAINTENANCE_PASSWORD` remplace le mot de passe équipe. Puis « Deploys », « Trigger deploy ».

Pendant la fermeture, la page publiée ne contient QUE la page d'ouverture : produits, prix, codes et secrets ne sont pas dedans (même si un service du serveur tombait en panne, le site resterait fermé). Le mot de passe d'équipe n'est jamais envoyé aux visiteurs, même chiffré : c'est le serveur (`netlify/functions/porte.mjs`) qui le vérifie, avec 8 essais ratés maximum par quart d'heure. Le bon mot de passe ouvre la boutique pour une seule visite. À chaque rechargement, nouvel onglet ou réouverture de la page, la page d'ouverture revient et le mot de passe est redemandé (toi compris, même connecté en `#admin` : ton panneau se rouvre tout seul après le mot de passe). Pendant la fermeture, seule l'équipe entrée avec le mot de passe peut payer.

Mot de passe : 8 caractères minimum (évite un mot du dictionnaire). Les nouveaux mots de passe sont chiffrés avec PBKDF2 (très lent à deviner).

## 6. Paiement Stripe
1. Compte Stripe activé. Pour chaque produit : « Produits », puis « Payment Links », « Créer un lien de paiement » (adresse de livraison, frais de port, TVA, quantité).
2. « Après le paiement » : rediriger vers `https://ton-domaine/#merci`.
3. Panneau, onglet « Boutique », produit, champ « Lien de paiement Stripe » : colle `https://buy.stripe.com/…`. Publie.
4. Teste en mode test (carte `4242 4242 4242 4242`) avant le mode réel.

## 6 bis. Panier (plusieurs produits, un seul paiement)
1. Stripe : « Développeurs », « Clés API ». Le plus sûr : « Créer une clé restreinte » (`rk_live_…`) avec seulement **Checkout Sessions : écriture** (ajoute « lecture » sur les tarifs de livraison si Stripe le demande au test). À défaut, la clé secrète (`sk_test_…` pour tester, `sk_live_…` en vrai). Une clé restreinte limite les dégâts si elle fuitait un jour.
2. Netlify : « Site configuration », « Environment variables », ajoute `STRIPE_SECRET_KEY` avec cette clé, puis « Trigger deploy ». Ne la mets jamais dans le site ni sur GitHub.
3. Panneau, onglet « Boutique », groupe « 🛒 Panier » : frais de port, livraison offerte à partir de X €, pays livrés, textes. Les prix sont relus côté serveur : un visiteur ne peut pas les modifier.
4. Le dossier `netlify/functions/` contient le petit service de paiement : envoie-le aussi sur GitHub.

## 7. Logo du site, son d'ambiance
- Panneau, onglet « Apparence », « Logo du site et nom » : l'icône des onglets, favoris et de l'écran d'accueil du téléphone. Par défaut : un petit disque. Le site en ligne sert ce logo en vrais fichiers (`favicon.ico`, `favicon.png`, `apple-touch-icon.png`) : l'onglet et les favoris montrent toujours la même image. Si Safari affiche encore une ancienne icône, c'est son cache : Réglages › Safari › Avancé › Données de sites web › supprimer yuu-store.com.
- Les navigateurs interdisent de lancer un son sans geste de l'utilisateur. Le site tente de le lancer dès l'arrivée et, sinon, au premier toucher ou clic n'importe où. Un petit message l'indique (modifiable, ou vide pour le retirer).

## 8. Avant d'ouvrir au public
- Complète `legal.html` : le lien est déjà dans le bas de page.
- Les formulaires « Contact » et « Newsletter » passent par FormSubmit : au premier envoi, ils t'écrivent pour confirmer ton adresse.

## 9. Mini-jeu (secret n°4) et classement mondial
- `netlify/functions/scores.mjs` garde le classement général et un classement par disque (100 meilleurs, 10 affichés) dans Netlify Blobs : rien à configurer. Les scores déjà enregistrés sont gardés et rangés automatiquement par disque.
- Modérer : ajoute la variable `SCORES_ADMIN_KEY` (un mot de passe d'au moins 16 caractères, 10 essais ratés max par quart d'heure), puis ouvre `https://ton-domaine/.netlify/functions/scores?key=TON_MOT_DE_PASSE&del=ABC` (retirer un nom) ou `&reset=1` (tout effacer).
- `package.json` installe le module Netlify Blobs automatiquement au déploiement : envoie-le aussi sur GitHub.
- Musique des parties : à chaque déploiement, `build.mjs` télécharge 5 morceaux de **Komiku** (album « Poupi's incredible adventures! », domaine public CC0, archive.org) dans `assets/music/`. SETSUNA II et GRY (les 2 communs) partagent « The Arcade Game » ; yukyu a « Space Bicycle », le « ? » « Fracture of the universe will happen soon », AHABAH « Universe big takedown » et le DISQUE NOIR « Mr Angst Theme ». Chances par défaut : SETSUNA II 40 %, GRY 40 %, yukyu 13 %, « ? » 5 %, AHABAH 1,5 %, DISQUE NOIR 0,5 %. AHABAH (doré) et le DISQUE NOIR (sombre) donnent ×5 points, ont la texture du « ? » et s'affichent à côté du nom dans le classement. Le classement a un onglet par disque (SETSUNA, GRY, YUKYU, « ? », MYTHIQUES = AHABAH + DISQUE NOIR). Tous les 100 000 points, l'écran du jeu se fissure un peu plus et la musique accélère ; à 1 000 000, il explose en lumière blanche. Chaque joueur voit aussi son record perso, gardé sur son appareil. Tu peux mettre ton propre son pour chaque disque dans le panneau, onglet « 🎮 Mini-jeu ».
- Événements rares (réglables et testables dans le panneau) : disque fêlé au tirage (×10, une vie), disque qui éclate en 3 morceaux pendant 20 s, et sur la page d'accueil le disque qui se brise au toucher (puzzle, version cassée ou gravité). `netlify/functions/brise.mjs` tient le compteur commun « Tu es la Ne personne à avoir brisé le disque » (jamais remis à zéro).
- Tester un CD précis : onglet « 🎮 Mini-jeu », boutons « ▶ » (partie test, score non enregistré).

## 10 bis. Vitesse (déjà en place)
- Images allégées (2048 px max, compression soignée), code du site dans un fichier à part.
- Les fichiers de `assets/` ont des noms uniques : le navigateur les garde en mémoire, les visites suivantes sont quasi instantanées.
- Connexion anticipée à la bibliothèque 3D et à l'image du premier disque ; rendu 3D un peu plus léger sur téléphone.

## 10. Sécurité (déjà en place dans ce dossier)
- **Seul le dossier `dist` est publié** : ton code (`build.mjs`, `netlify/`, ce fichier…) n'est pas lisible depuis le site. Au déploiement, `build.mjs` vérifie qu'aucun secret ne s'est glissé dans les fichiers publiés ; sinon il arrête le déploiement (l'ancien site reste en ligne).
- **Aucun secret dans la page** : ni le mot de passe d'équipe (même chiffré), ni ta clé Stripe. Ton adresse e-mail de contact n'y est jamais écrite en clair (les robots qui ramassent les adresses ne la voient pas).
- **Paiement** : la carte bancaire est saisie chez Stripe, jamais sur ce site. Les prix viennent du serveur (un visiteur ne peut pas les changer), le site ne redirige que vers Stripe, refuse les demandes venant d'autres sites et limite les abus (15 paiements lancés par quart d'heure par connexion).
- **Aucun script étranger** : la bibliothèque 3D et les polices sont servies par le site lui-même (contrôle d'intégrité), les visiteurs ne contactent ni Google ni un autre service pour s'afficher. La politique de sécurité (`netlify.toml`) interdit tout script injecté (cela bloque aussi le badge « Powered by Netlify »).
- **Navigateur verrouillé** : le site ne peut pas être affiché dans un autre site, reste en HTTPS (sous-domaines compris), et n'a accès ni à la caméra, ni au micro, ni à la position, ni aux capteurs.
- **Classement** : noms de 3 lettres filtrés, scores vérifiés (impossible d'inventer un score qui ne s'explique pas par la partie), limite anti-spam. Les adresses IP ne sont jamais enregistrées (seulement une empreinte secrète, pour limiter les abus).
- **Déploiement** : version du module Netlify Blobs figée et aucun script d'installation exécuté (`.npmrc`), contre les modules piégés.

**À faire de ton côté (5 minutes, le plus important)** :
1. Active la double authentification (2FA) sur GitHub, Netlify, Stripe, OVH et ta boîte mail.
2. Mets ton dépôt GitHub en **privé** (« Settings », « Danger Zone », « Change visibility ») : sinon tout le contenu (produits, codes) y est lisible.
3. Jeton GitHub : « fine-grained », limité à ce seul dépôt, « Contents : Read and write », avec une date d'expiration. Sur le site, ne coche « Rester connecté » que sur tes propres appareils.
4. OVH : verrouille le domaine contre les transferts (« Protection contre le transfert ») et active DNSSEC si proposé.
5. Formulaire de contact : FormSubmit t'envoie, après la première confirmation, une adresse masquée (une suite de lettres). Colle-la à la place de ton e-mail dans le panneau, onglet « Contact & ouverture » : même les messages envoyés ne montreront plus ton adresse.
6. Ne mets jamais de clé secrète (Stripe, GitHub) dans le site ou sur GitHub : seulement dans les variables Netlify. Pour Stripe, préfère une clé restreinte (section 6 bis).
7. Protège tes clients contre les faux e-mails à ton nom : dans la zone DNS OVH, si tu n'envoies pas d'e-mails depuis @yuu-store.com, ajoute un TXT `@` = `v=spf1 -all` et un TXT `_dmarc` = `v=DMARC1; p=reject`. Si tu utilises une boîte mail OVH sur ce domaine : TXT `@` = `v=spf1 include:mx.ovh.com -all` et `_dmarc` = `v=DMARC1; p=quarantine`.
8. Toujours dans la zone DNS : un enregistrement CAA `@` = `0 issue "letsencrypt.org"` (seul le fournisseur de certificats de Netlify peut en créer pour ton domaine).
9. Netlify : « Site configuration », « Build & deploy », « Deploy Previews » : désactive-les si tu ne t'en sers pas.
