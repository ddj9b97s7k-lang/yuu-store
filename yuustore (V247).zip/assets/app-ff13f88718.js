
/* ================= utilitaires ================= */
function $(i){return document.getElementById(i)}
function esc(x){return String(x==null?'':x).replace(/[&<>"']/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})}
function safeUrl(u){u=String(u||'').trim();if(!u)return '#';if(/^[^\s@\/:]+@[^\s@\/:]+\.[a-z]{2,}$/i.test(u))return 'mailto:'+u;return /^(https?:\/\/|mailto:|#|\/)/i.test(u)?u:'https://'+u}
var LOCAL={},GHA=null;function isSA(){return !window.claude}
function hdec(){var h=location.hash.slice(1);try{return decodeURIComponent(h)}catch(e){return h}}
function safeImg(u){u=LOCAL[u]||u;return /^[\w\-\/.:%?=&+~@]+$/.test(u||'')?u:''}
function gp(o,p){return p.split('.').reduce(function(a,k){return a==null?a:a[k]},o)}
function sp(o,p,v){var k=p.split('.'),l=k.pop();k.reduce(function(a,x){return a[x]},o)[l]=v}
function vis(){return S.discs.filter(function(d){return d.myt?false:d.mys?MYSON:(!d.egg||(S.eg&&EGGON))})}
function curDisc(){var v=vis();if(ACT>=v.length)ACT=0;return v[ACT]||S.discs[0]}
function tFxSvg(){var sv=document.getElementById('tfxs');if(sv)return sv;sv=document.createElementNS('http://www.w3.org/2000/svg','svg');sv.id='tfxs';sv.setAttribute('width','0');sv.setAttribute('height','0');sv.setAttribute('aria-hidden','true');sv.style.cssText='position:absolute;width:0;height:0;pointer-events:none';
 sv.innerHTML='<filter id="tfx" x="-5%" y="-5%" width="110%" height="110%" color-interpolation-filters="sRGB"><feTurbulence type="fractalNoise" baseFrequency=".05" numOctaves="3" seed="7" result="n"/><feDiffuseLighting in="n" surfaceScale="4" diffuseConstant="1.1" lighting-color="#fff" result="l"><feDistantLight azimuth="225" elevation="50"/></feDiffuseLighting><feComponentTransfer in="l" result="l2"><feFuncR type="linear" slope="1.5"/><feFuncG type="linear" slope="1.5"/><feFuncB type="linear" slope="1.5"/></feComponentTransfer><feBlend in="SourceGraphic" in2="l2" mode="multiply" result="m"/><feComposite in="m" in2="SourceGraphic" operator="in"/></filter><filter id="tgn" x="0" y="0" width="100%" height="100%" color-interpolation-filters="sRGB"><feTurbulence type="fractalNoise" baseFrequency=".9" numOctaves="1" seed="3" result="n"/><feColorMatrix in="n" type="matrix" values=".33 .33 .33 0 0 .33 .33 .33 0 0 .33 .33 .33 0 0 0 0 0 0 1" result="g"/><feComposite in="SourceGraphic" in2="g" operator="arithmetic" k1="0" k2="1" k3=".4" k4="-.2" result="a"/><feComposite in="a" in2="SourceGraphic" operator="in"/></filter>';
 var c=sv.querySelector('#tfx').cloneNode(true);c.id='tfx2';sv.appendChild(c);document.body.appendChild(sv);return sv}
function tGrain(d){var h=document.querySelector('#hero h1'),lg=document.querySelector('header b a'),T=S.tlk||{},lk=!!T.on,R=document.documentElement;if(!h)return;
 var a=typeof d.tgr==='number'?d.tgr:(+S.tgr||0),els=[h].concat(lk&&lg?[lg]:[]);
 R.classList.toggle('tlk',lk);R.classList.toggle('tlc',T.col!==false);if(lg&&!lk){lg.style.webkitMaskImage=lg.style.maskImage=lg.style.filter=''}
 if(!(a>0)&&!S.tlk.rock)h.style.filter='';
 var u='',msz='',gf='';
 if(a>0){var sv0=tFxSvg(),sz=Math.max(.5,+S.tgs||1.5),q=Math.min(1,a),gn=sv0.querySelector('#tgn');gn.querySelector('feTurbulence').setAttribute('baseFrequency',(1.3/sz).toFixed(3));var ar=gn.querySelector('feComposite');ar.setAttribute('k3',(q*1.1).toFixed(3));ar.setAttribute('k4',(-q*.55).toFixed(3));gf=' url(#tgn)'}
 var rk=!!T.rock;
 if(rk){var sv=tFxSvg(),amt=Math.max(0,Math.min(1,+T.amt||0)),la=+T.la||0,f=sv.querySelector('feTurbulence'),dl=sv.querySelector('feDiffuseLighting'),ds=sv.querySelector('feDistantLight');
  f.setAttribute('baseFrequency',(.035+amt*.05).toFixed(3));dl.setAttribute('surfaceScale',(1+amt*9).toFixed(1));ds.setAttribute('azimuth',String(Math.round((360-la)%360)));var c2=sv.querySelector('#tfx2');c2.querySelector('feTurbulence').setAttribute('baseFrequency',((.035+amt*.05)*3.2).toFixed(3));c2.querySelector('feDiffuseLighting').setAttribute('surfaceScale',(.6+amt*2.4).toFixed(1));c2.querySelector('feDistantLight').setAttribute('azimuth',String(Math.round((360-la)%360)))}
 els.forEach(function(e){e.style.webkitMaskImage=e.style.maskImage='';e.style.filter=((rk?(e===h?'url(#tfx)':'url(#tfx2)'):'')+gf).trim()});
 if(lk){var la2=(+T.la||0)*Math.PI/180,x=Math.cos(la2),y=-Math.sin(la2);R.style.setProperty('--tsh',(x*.025).toFixed(3)+'em '+(y*.025).toFixed(3)+'em 0 rgba(255,255,255,.32),'+(-x*.04).toFixed(3)+'em '+(-y*.04).toFixed(3)+'em .02em rgba(0,0,0,.38)')}else R.style.removeProperty('--tsh')}
function heroUpd(){var d=curDisc();try{tGrain(d)}catch(e){}var sp=document.querySelector('#hero h1 span');if(!sp)return;sp.dataset.p='discs.'+S.discs.indexOf(d)+'.t';if(sp!==document.activeElement)sp.textContent=d.t;
 $('hero').dataset.tm=tmode(d);$('hero').dataset.tf=tfront(d);var fb=$('fb'),im=safeImg(d.img);fb.className='fb'+(im?' img':'');fb.style.backgroundImage=im?"url('"+im+"')":''}
var dsig='';
function dswSel(){var el=$('dsw'),v=vis();if(!el)return;var k=el.querySelector('i');if(k){k.style.width='calc((100% - 8px)/'+v.length+')';k.style.transform='translateX('+ACT*100+'%)'}
 el.querySelectorAll('button').forEach(function(b){b.setAttribute('aria-checked',+b.dataset.j===ACT?'true':'false')})}
function dswSync(){var el=$('dsw'),v=vis(),sig=v.map(function(d){return d.n}).join('|');if(!el)return;if(ACT>=v.length)ACT=0;
 if(sig!==dsig){dsig=sig;el.hidden=v.length<2;el.innerHTML='';el.append(mk('i'));
  v.forEach(function(d,j){var b=mk('button',{type:'button',textContent:d.n||('Disque '+(j+1))});b.setAttribute('role','radio');b.dataset.j=j;el.append(b)})}
 dswSel()}
function dswBuild(){dsig='';dswSync()}
function pick(j){var v=vis();if(j<0||j>=v.length||j===ACT)return;ACT=j;if(window.SND)SND.sync();dswSel();heroUpd();bgr();if(window.FXm)FXm.apply();if(window.__gl){__gl.cd();__gl.front(1700)}if(window.SND)SND.play('switch')}
function toast(x){var e=$('toast');if(!e){e=mk('div',{id:'toast'});document.body.append(e)}e.textContent=x;e.classList.add('on');setTimeout(function(){e.classList.remove('on')},2800)}
function unlockEgg(){if(!S.eg||EGGON)return;var j=-1;S.discs.forEach(function(d,k){if(d.egg&&j<0)j=k});if(j<0)return;
 EGGON=true;dsig='';dswSync();ACT=vis().indexOf(S.discs[j]);dswSel();heroUpd();bgr();if(window.FXm)FXm.apply();if(window.__gl){__gl.cd();__gl.front(2200)}toast('✦ Disque secret débloqué');if(window.SND)SND.play('egg')}
(function(){var el=$('dsw'),dn=false;
 function at(e){var r=el.getBoundingClientRect(),n=vis().length,x=(e.clientX-r.left-4)/Math.max(1,r.width-8);return Math.max(0,Math.min(n-1,Math.floor(x*n)))}
 el.addEventListener('pointerdown',function(e){dn=true;try{el.setPointerCapture(e.pointerId)}catch(x){}pick(at(e))});
 el.addEventListener('pointermove',function(e){if(dn)pick(at(e))});
 addEventListener('pointerup',function(){dn=false});
 el.addEventListener('click',function(e){var b=e.target.closest('button');if(b)pick(+b.dataset.j)});
 el.addEventListener('keydown',function(e){if(e.key==='ArrowRight')pick(ACT+1);else if(e.key==='ArrowLeft')pick(ACT-1)});
 var buf='';document.addEventListener('keydown',function(e){var tg=e.target;if(tg&&(tg.isContentEditable||/^(INPUT|TEXTAREA|SELECT)$/.test(tg.tagName)))return;
  if(e.key&&e.key.length===1){buf=(buf+e.key.toLowerCase()).slice(-7);if(buf.slice(-5)==='yukyu'){buf='';unlockEgg()}else if(buf.slice(-6)==='glitch'){buf='';setBroken(true)}else if(buf.indexOf('repar')>=0){buf='';repairSeq()}}});
})();
function nz(src,dst){for(var k in src){var v=src[k];if(typeof v==='number'&&isFinite(v))dst[k]=v}return dst}
function dcd(d){var o=nz(S.cd,{});if(d&&d.cd&&typeof d.cd==='object')nz(d.cd,o);return o}
function dti(d){var o=nz(S.ti,{});if(d&&d.ti&&typeof d.ti==='object')nz(d.ti,o);return o}
function tfront(d){d=d||curDisc();return d.tf||S.tfront||'img'}
function titleImg(d){d=d||curDisc();return d.timg||S.timg}
function tmode(d){d=d||curDisc();var u=safeImg(titleImg(d)),m=d.tm||S.tmode;return u&&m==='image'?'image':u&&m==='both'?'both':'text'}
function lum(x){var n=parseInt(String(x).slice(1),16);return(.299*(n>>16&255)+.587*(n>>8&255)+.114*(n&255))/255}
function mk(t,a,c){var e=document.createElement(t);for(var k in a)e[k]=a[k];(c||[]).forEach(function(x){if(x!=null&&x!==false&&x!=='')e.append(x)});return e}
function merge(d,o){for(var k in d){if(o[k]==null)o[k]=JSON.parse(JSON.stringify(d[k]));else if(d[k]&&typeof d[k]==='object'&&!Array.isArray(d[k]))merge(d[k],o[k])}return o}

/* ================= état du site (tout ce qui est modifiable) ================= */
var PJSIG='',PJOPEN={},AUD=null,PJCUR='',CLSIG='',BRK=false,brT=null;
var S=JSON.parse($('state').textContent),art=null,asg=null,EDIT=false,TAB='txt',OPEN=null,DRAG=null;
var TXD={tab:'Boutique',nav:'Boutique',hint:'Glisse pour faire tourner le disque',shopH:'Boutique',stepsH:'Comment commander',
 steps:['Choisis ton article et clique sur « Commander ».','Tu paies sur la boutique sécurisée, avec les moyens de paiement qu’elle propose.','Tu reçois un e-mail de confirmation de commande.','Ta commande est préparée puis expédiée.'],
 pjH:'Écouter',pjLead:'Lance les projets sur tes plateformes préférées.',pjGo:'▶ Lancer',pjSoon:'Bientôt',pjHere:'▶ Écouter ici',pjHide:'Fermer le lecteur',pjOn:'Écouter sur',sndCr:'Son d’ambiance : nappe synthétisée en direct sur ce site.',brkM:'⚠ QUELQU’UN EST ENTRÉ',repB:'↺ Réparer le site',gone:'Il est parti.',sndLbl:'Son d’ambiance :',cartAdd:'Ajouter au panier',cartCodePh:'Code promo',cartCodeBtn:'Appliquer',cartCodeOk:'Code appliqué : livraison offerte',cartCodeBad:'Ce code n’est pas valable.',cartCodeRm:'Retirer le code',cartH:'Mon panier',cartEmpty:'Ton panier est vide.',cartPay:'Passer au paiement',cartCont:'Continuer mes achats',cartTot:'Total des produits',cartShipNote:'Frais de port et taxes calculés au paiement.',cartFreeMsg:'Plus que {x} € pour la livraison offerte',cartFreeOk:'Livraison offerte 🎉',cartAdded:'Ajouté au panier',cartErr:'Le paiement du panier est indisponible pour le moment. Réessaie dans quelques minutes.',sndHint:'🔊 Touche l’écran pour lancer le son',thanks:'Merci ! Ta commande est confirmée, tu vas recevoir un e-mail de confirmation.',moreH:'Autres produits',feat:'À la une',clH:'Clip',clLead:'Regarde le clip.',clSoon:'Le clip arrive bientôt.',clExt:'Regarder le clip',brk:'⚠ SIGNAL PERDU',rep:'↺ Réparer le site',flp:'Retourner le disque',ctFail:'Ce site ne peut pas envoyer le message tout seul depuis cette page : il n’est donc pas encore parti. Envoie-le à',ctReady:'Ton message est prêt : ouvre ta messagerie ou copie-le, puis envoie-le à',ctOpen:'Ouvrir ma messagerie',ctCopy:'Copier le message',ctCopied:'Copié ✓',
 ctH:'Nous contacter',ctLead:'Une question, une commande, une collaboration ? Écris-nous.',ctName:'Ton nom',ctMail:'Ton e-mail',ctMsg:'Ton message',ctBtn:'Envoyer',ctOk:'Merci, message envoyé !',ctMt:'Ton application mail s’ouvre pour finaliser l’envoi.',
 nlH:'Newsletter',nlLead:'Les sorties et les éditions limitées, avant tout le monde.',nlPh:'ton@email.com',nlBtn:'Je m’inscris',nlOk:'Inscrit·e, merci !',
 note:'Les frais de port et les délais sont affichés avant le paiement.',aboutH:'À propos',view:'Voir',back:'← Retour à la boutique',buy:'Commander',cur:'€',
 links:[{t:'Instagram',u:'#'},{t:'Spotify',u:'#'},{t:'Contact',u:'#'}]};
S.tx=merge(TXD,S.tx||{});if(S.tx.foot==null)S.tx.foot='© '+S.name;
S.cd=merge({img:'',tint:'#e8ecf8',holo:.3,glare:1,la:.8,grain:.3,relief:.3,edge:.3,cen:.5,hole:.07,fit:.94},S.cd||{});if(S.cd.edge===.5)S.cd.edge=.3;
S.th=S.th||{};S.bgs=S.bgs||[];if(S.bgo==null)S.bgo=.65;if(S.spd==null)S.spd=1;if(!S.tmode)S.tmode='text';S.tlk=merge({on:false,col:true,rock:false,amt:.6,la:315},S.tlk||{});if(S.tgr==null)S.tgr=0;if(S.tgs==null)S.tgs=1.5;if(S.timg==null)S.timg='';if(S.tsz==null)S.tsz=.7;if(S.ty==null)S.ty=0;
S.bl=merge({on:false,w:2,c:''},S.bl||{});if(S.eg==null)S.eg=true;S.zm=merge({on:true,max:2.5},S.zm||{});if(S.trk==null)S.trk=.7;S.ti=merge({holo:S.cd.holo,glare:S.cd.glare,la:S.cd.la,grain:S.cd.grain,rock:S.trk},S.ti||{});
if(!S.discs||!S.discs.length)S.discs=[{k:'setsuna',n:'SETSUNA II',t:S.title||'SETSUNA II',img:'',tint:'#9fb4ea'},{k:'gry',n:'GRY',t:'GRY',img:'',tint:'#eab0d2'},{k:'yukyu',n:'YUKYU',t:'YUKYU',img:S.cd.img||'',tint:S.cd.tint,egg:true}];
S.discs.forEach(function(d){['n','t','img'].forEach(function(k){if(d[k]==null)d[k]=''});if(!d.tint)d.tint=S.cd.tint});
var OWN=false,MT_OK=!!(S.mt&&S.mt.srv==='ok'),MT_PRE=false,SNDON=false;
S.fx=merge({on:true,amt:.4,grain:.3,sheen:.5,vig:.35,mode:'iris',spd:1},S.fx||{});if(['iris','pellicule','rayons','brume','cubique','vhs','casse','soleil','aurore','pluie','neon','braise','eau'].indexOf(S.fx.mode)<0&&String(S.fx.mode).indexOf('c:')!==0)S.fx.mode='iris';
S.cart=merge({on:true,direct:true,code:'',rate:'',ship:'0',free:'0',countries:'FR,BE,DE,ES,IT,NL,LU,PT,CH,AT,IE,GB'},S.cart||{});
S.eg3=merge({on:true,sec:60,snd:true},S.eg3||{});S.acct=merge({on:false,url:'',lbl:'Mon compte',save:true},S.acct||{});S.eg7=merge({on:true,img:'',cap:'Miaou.',ctx:'Livraison offerte avec le code'},S.eg7||{});S.eg6=merge({on:true,tk:'Écharpe ramassée. Fais-la glisser jusqu’à yuu, tout en haut de la page.',ok:'Elle lui va bien. Un nouveau produit est apparu dans la boutique.'},S.eg6||{});S.ssn=merge({on:true,mode:'auto',amt:.6},S.ssn||{});S.pong=merge({lives:3,goals:5,msg:'Tu as battu yuu.',drop:{},ahabah:'1.5',noir:'0.5',fel:'2000',ecl:'2000',eev:'200',taku:'200',mon:true,mv:.35,mus:{}},S.pong||{});if(String(S.pong.ahabah)==='1')S.pong.ahabah='1.5';delete S.pong.gold;if(S.pong.mus&&S.pong.mus.or){if(!S.pong.mus.noir)S.pong.mus.noir=S.pong.mus.or;delete S.pong.mus.or}(function(d,o,n){if(d&&Object.keys(o).every(function(k){return d[k]&&String(d[k].w)===o[k]}))Object.keys(n).forEach(function(k){d[k].w=n[k]})})(S.pong.drop,{setsuna:'42',gry:'42',yukyu:'13',mystere:'3'},{setsuna:'40',gry:'40',yukyu:'13',mystere:'5'});if(S.pong.msg==='Tu as battu l\'éternité.')S.pong.msg='Tu as battu yuu.';S.eg4=merge({on:true,mode:'game',msg:'',code:'DDDG',date:'2027-01-01T00:00',lbl:'LE TROISIÈME PROJET',pre:'dans',end:'C’est maintenant.'},S.eg4||{});S.eg5=merge({on:true,go:true,chip:false,l1:'FACE CACHÉE',l3:'N° 0003 / 0100',host:''},S.eg5||{});
if(!S.products.some(function(p){return p.hid}))S.products.push({s:'face-cachee',n:'FACE CACHÉE',d:'Édition secrète, réservée à ceux qui ont retourné le disque.',l:'Tu as trouvé la face cachée du disque. Cette édition n’est visible nulle part sur le site : seul le lien gravé y mène.',p:'',h:300,u:'',img:'',det:['Édition secrète','Numérotée'],x:{t:'',l:[]},imgs:[],pay:'',hid:true});
if(!S.products.some(function(p){return p.esc}))S.products.push({s:'echarpe',n:'ÉCHARPE',d:'Une écharpe noire, trouvée puis posée sur yuu.',l:'Tu as retrouvé l’écharpe et tu l’as posée sur yuu. Cette pièce n’apparaît dans la boutique que pour ceux qui l’ont fait.',p:'',h:250,u:'',img:'',det:['Édition secrète','Noire'],x:{t:'',l:[]},imgs:[],pay:'',esc:true});
if(!S.discs.some(function(d){return d.mys}))S.discs.push({k:'mystere',n:'?',t:'השלישי יהיה האחרון',img:'',tint:'#26070d',bgc:'#14030a',mys:true,cd:{holo:.3,glare:1.4,relief:.28,grain:.2}});
(function(){var m=S.discs.filter(function(d){return d.mys})[0]||{};[['ahabah','AHABAH (disque d’or)','#e2b33c'],['noir','DISQUE NOIR','#101014']].forEach(function(x){var e=S.discs.filter(function(d){return d.k===x[0]})[0];if(!e)S.discs.push({k:x[0],n:x[1],t:'',img:'',tint:x[2],myt:true,cd:JSON.parse(JSON.stringify(m.cd||{}))});else e.myt=true})})();
S.eg2=merge({on:true,txt:false,hid:'Le troisième projet finira l’histoire.',words:['ILS TE VOIENT','TU N’AURAIS PAS DÛ','NE PARS PAS','IL EST DERRIÈRE TOI','ÇA NE S’ARRÊTERA PAS','REGARDE-MOI','TROP TARD']},S.eg2||{});S.clip=merge({url:'',poster:'',ext:'',extn:'',hide:false,w:36},S.clip||{});S.pc=merge({style:'card',shape:'round',hub:true,tilt:true},S.pc||{});if(!S.tfront)S.tfront='img';
S.rot=merge({free:true,flip:true},S.rot||{});
S.snd=merge({show:true,def:false,vol:.35,th:'cristal',amb:false,hov:true,pitch:0,len:1,rev:.4,pk:'nappe',pn:0,pb:.5,pm:.5,pv:.07,pfn:''},S.snd||{});if(!S.snd.pfn)S.snd.pfn=S.snd.pf?'Ma nappe':'Nappe douce';
S.fx.presets=Array.isArray(S.fx.presets)?S.fx.presets:[];S.fx.custom=Array.isArray(S.fx.custom)?S.fx.custom:[];
S.snd.files=(S.snd.files&&typeof S.snd.files==='object')?S.snd.files:{};if(S.snd.pf==null)S.snd.pf='';if(S.snd.pfv==null)S.snd.pfv=.5;
var HEB3='השלישי יהיה האחרון';if(S.eg2.threat==null||/^(JE REVIENDRAI\.?|זה הסוף|)$/.test(S.eg2.threat))S.eg2.threat=HEB3;
if(!Array.isArray(S.clip.list)){S.clip.list=[];var _cu=S.clip.url||'',_ce=S.clip.ext||'',_cx=/youtu|vimeo|dailymotion|spotify/i.test(_cu);
 if(_cu||_ce)S.clip.list.push({s:'clip-1',n:'',u:_cx?'':_cu,p:S.clip.poster||'',x:_ce||(_cx?_cu:''),e:false})}
S.ct=merge({to:'',mode:'direct'},S.ct||{});if(!S.ct.to&&S.ct.tx){try{S.ct.to=decodeURIComponent(escape(atob(S.ct.tx))).split('').reverse().join('')}catch(e){}}delete S.ct.tx;
if(!S.pj)S.pj={list:[{s:'pj1',n:'SETSUNA II',d:'Le projet, en écoute.',img:'',h:260,l:[{t:'Spotify',u:''},{t:'Apple Music',u:''},{t:'YouTube',u:''}]},{s:'pj2',n:'GRY',d:'Le deuxième projet.',img:'',h:180,l:[{t:'Spotify',u:''},{t:'Apple Music',u:''},{t:'YouTube',u:''}]}]};
S.mt=merge({on:false,h:'',s:'',t:'Ouverture bientôt',d:'Le site n’est pas encore ouvert. Laisse ton e-mail pour être prévenu·e dès l’ouverture.',mail:true,ph:'ton@email.com',mb:'Me prévenir',pl:'Accès équipe',pb:'Entrer',bad:'Mot de passe incorrect'},S.mt||{});
S.tx.links.forEach(function(l){if(l.t==='Contact'&&(!l.u||l.u==='#'||/^[^\s@\/:]+@[^\s@\/:]+\.[a-z]{2,}$/i.test(l.u)))l.u='#contact'});if(!S.tx.links.some(function(l){return l.u==='#newsletter'}))S.tx.links.push({t:'Newsletter',u:'#newsletter'});
try{var _s=localStorage.getItem('yuu-snd');SNDON=_s==null?!!S.snd.def:_s==='1'}catch(e){SNDON=!!S.snd.def}
try{localStorage.removeItem('yuu-mt')}catch(e){}
var ACT=0,EGGON=false,MYSON=false,ENGON=false,ESCON=false;try{sessionStorage.removeItem('yuu-mys');sessionStorage.removeItem('yuu-eng')}catch(e){}
try{localStorage.removeItem('yuu-egg')}catch(e){}
S.products.forEach(function(p){if(p.big==null)p.big=false;p.det=p.det||[];['n','d','l','p','u','img','pay'].forEach(function(k){if(p[k]==null)p[k]=''});if(!Array.isArray(p.imgs))p.imgs=[];if(p.img){if(p.imgs.indexOf(p.img)<0)p.imgs.unshift(p.img);p.img=''}p.imgs=p.imgs.filter(Boolean);if(p.h==null)p.h=200});

/* ================= affichage du site ================= */
function grad(h){return 'conic-gradient(from 30deg,hsl('+h+' 90% 78%),hsl('+(+h+80)+' 90% 82%),hsl('+(+h+160)+' 90% 78%),hsl('+(+h+240)+' 90% 82%),hsl('+h+' 90% 78%))'}
function bgj(p,j){var u=safeImg((p.imgs||[])[j||0]);return u?"background:url('"+u+"') center/cover":'background:'+grad(p.h)}
function bg(p){var u=safeImg((p.imgs||[])[0]);return u?"background:url('"+u+"') center/cover":'background:'+grad(p.h)}
function priceHTML(p,b){if(!String(p.p||'').trim()&&!OWN)return '';return '<span class="price"><span data-p="'+b+'p">'+esc(p.p)+'</span> <span data-p="tx.cur">'+esc(S.tx.cur)+'</span></span>'}
function stepsHTML(){return S.tx.steps.map(function(x,j){return '<li data-p="tx.steps.'+j+'">'+esc(x)+'</li>'}).join('')}
function card(p,i,mini){var b='products.'+i+'.',big=!!p.big&&!mini;
 var tx='<h3 data-p="'+b+'n">'+esc(p.n)+'</h3><p data-ml data-p="'+b+'d">'+esc(p.d)+'</p>'
  +'<div class="row">'+priceHTML(p,b)+'<a class="btn" href="#'+esc(p.s)+'" data-p="tx.view">'+esc(S.tx.view)+'</a></div>';
 return '<article class="card'+(big?' big':'')+(mini?' mini':'')+'"><a href="#'+esc(p.s)+'" class="sw" data-pi="'+i+'" style="'+bg(p)+'" aria-label="'+esc(p.n)+'"></a>'+(big?'<div class="txt"><span class="bdg" data-p="tx.feat">'+esc(S.tx.feat)+'</span>'+tx+'</div>':tx)+'</article>'}
function cardsHTML(excl,mini){var ix=S.products.map(function(p,i){return i});ix.sort(function(a,b){return (S.products[b].big?1:0)-(S.products[a].big?1:0)||a-b});
 return ix.filter(function(i){return S.products[i].s!==excl&&!S.products[i].hid&&!(S.products[i].esc&&S.eg6.on&&!ESCON)}).map(function(i){return card(S.products[i],i,mini)}).join('')}
function gridCls(){return 'grid'+(S.pc.style==='float'?' fl'+(S.pc.shape==='round'?' rd':'')+(S.pc.hub?' hb':''):'')}
function moreHTML(cur){var L=cardsHTML(cur,true);return L.trim()?'<section class="more"><h2 class="mini" data-p="tx.moreH">'+esc(S.tx.moreH)+'</h2><div class="'+gridCls()+'">'+L+'</div></section>':''}
function xbox(p,i){var x=p.x;if(!x||!x.l||!x.l.length)return '';var b='products.'+i+'.x.';
 var l=x.l.map(function(y,j){return S.products.some(function(q){return q.s===y.s})?'<a class="btn alt" href="#'+esc(y.s)+'" data-p="'+b+'l.'+j+'.b">'+esc(y.b)+'</a>':''}).join(' ');
 return l.trim()?'<div class="xb"><p data-p="'+b+'t">'+esc(x.t)+'</p>'+l+'</div>':''}
var GI=0,GP='';
function pageHTML(p,i){var b='products.'+i+'.';if(GP!==p.s){GP=p.s;GI=0}if(GI>=(p.imgs||[]).length)GI=0;
 return '<a class="back" href="#boutique" data-p="tx.back">'+esc(S.tx.back)+'</a><div class="pp"><div class="gal"><div class="sw big" id="gm" data-pi="'+i+'" style="'+bgj(p,GI)+'"></div>'+((p.imgs||[]).length>1?'<div class="thumbs">'+p.imgs.map(function(u,j){return '<button type="button" class="th'+(j===GI?' on':'')+'" data-gi="'+j+'" style="'+bgj(p,j)+'" aria-label="Photo '+(j+1)+'"></button>'}).join('')+'</div>':'')+'</div><div>'
  +'<h1 class="pt" data-p="'+b+'n">'+esc(p.n)+'</h1>'+priceHTML(p,b)+'<p class="ml" data-ml data-p="'+b+'l">'+esc(p.l)+'</p>'
  +'<ul class="det">'+p.det.map(function(x,j){return '<li data-p="'+b+'det.'+j+'">'+esc(x)+'</li>'}).join('')+'</ul>'
  +'<div class="buy">'+(S.cart.on?'<button class="btn big" type="button" data-add="'+esc(p.s)+'" data-p="tx.cartAdd">'+esc(S.tx.cartAdd)+'</button>':'')+((!S.cart.on||S.cart.direct!==false)?'<a class="btn big'+(S.cart.on?' alt':'')+'" href="'+esc(safeUrl(p.pay||p.u||S.shop))+'" target="_blank" rel="noopener" data-p="tx.buy">'+esc(S.tx.buy)+'</a>':'')+'</div>'
  +'<p class="note" data-p="tx.note">'+esc(S.tx.note)+'</p>'+xbox(p,i)
  +'<h2 class="mini" data-p="tx.stepsH">'+esc(S.tx.stepsH)+'</h2><ol class="steps">'+stepsHTML()+'</ol></div></div>'+moreHTML(p.s)}
function linkHTML(l,j){var u=safeUrl(l.u);return '<a href="'+esc(u)+'"'+(/^https?:/i.test(u)?' target="_blank" rel="noopener"':'')+' data-p="tx.links.'+j+'.t">'+esc(l.t)+'</a>'}
function docTitle(){try{var rb=document.querySelector('meta[name=robots]');if(!rb){rb=document.createElement('meta');rb.name='robots';document.head.appendChild(rb)}var hq=S.products.filter(function(x){return x.s===hdec()})[0];rb.content=hq&&(hq.hid||(hq.esc&&!ESCON))?'noindex,nofollow':'index,follow'}catch(e){}var h=hdec(),p=S.products.filter(function(x){return x.s===h})[0];document.title=p?p.n+' – '+S.name:S.name+' – '+S.tx.tab}
function route(){
 var h=hdec(),i=-1;S.products.forEach(function(p,k){if(p.s===h)i=k});
 if(h==='merci'){CART=[];cSave();setTimeout(function(){try{toast(S.tx.thanks)}catch(e){}},500)}
 if(h==='panier')setTimeout(function(){cartOpen(true)},80);
 var P=$('prod');$('hero').hidden=i>=0;$('home').hidden=i>=0;P.hidden=i<0;
 if(i>=0)P.innerHTML=pageHTML(S.products[i],i);
 docTitle();
 if(h==='contact'||h==='newsletter')setTimeout(function(){var e=$(h);if(e)e.scrollIntoView({behavior:'smooth',block:'start'})},60);
}
var bgKey='',bgT=null,bgI=0;
var bgFT=null;
function bgColor(){var d=curDisc(),o=(d&&d.th)||{},R=document.documentElement.style,th={};
 Object.keys(S.th).forEach(function(k){th[k]=S.th[k]});Object.keys(o).forEach(function(k){if(o[k])th[k]=o[k]});
 if(d&&d.bgc)th.bg=d.bgc;
 var ac=o.accent||S.accent;
 if(window.GOLDON){var gd=(S.discs||[]).filter(function(z){return z.k==='ahabah'&&z.myt})[0]||{},go=gd.th||{};th={bg:gd.bgc||go.bg||'#0f0a02',ink:go.ink||'#FFF1C9',muted:go.muted||'#C8A75A',card:go.card||'#211705',line:go.line||'#6b5216',tcol:go.tcol||'#F7D774',onaccent:go.onaccent||'#1a1203'};ac=go.accent||'#F2C14E';o={}}R.setProperty('--accent',ac);R.setProperty('--onaccent',th.onaccent||(lum(ac)>.6?'#16132E':'#ffffff'));
 var dk=th.bg?lum(th.bg)<.5:false,DF=dk?{ink:'#EDEAFB',muted:'#A29EC9',card:'#211D42',line:'#37316A'}:{ink:'#1B1740',muted:'#5B5780',card:'#F5F3FB',line:'#C9C3E3'};
 ['bg','ink','muted','card','line'].forEach(function(k){var v=th[k]||(k==='bg'?'':DF[k]);if(v)R.setProperty('--'+k,v);else R.removeProperty('--'+k)});
 if(th.tcol)R.setProperty('--tcol',th.tcol);else R.removeProperty('--tcol');
 R.setProperty('--bc',S.bl.c||ac);
 clearTimeout(tcT);tcT=setTimeout(tcSync,0)}
function goldSite(){if(window.GOLDON)return;window.GOLDON=1;var H=document.documentElement;H.classList.add('goldin','gold');try{bgColor()}catch(e){}try{FXm.force('soleil')}catch(e){}try{if(window.SND)SND.play('egg')}catch(e){}setTimeout(function(){H.classList.remove('goldin')},1400)}
var tcT=0;setInterval(function(){if(!document.hidden)tcSync()},2000);function tcSync(){try{var c=getComputedStyle(document.documentElement).getPropertyValue('--bg').trim()||'#000000',m=document.querySelector('meta[name="theme-color"]');if(m)m.setAttribute('content',c);document.documentElement.style.colorScheme=/^#[0-9a-f]{6}$/i.test(c)&&lum(c)>.5?'light':'dark'}catch(e){}}
function bgOwn(){var d=curDisc();return d&&Array.isArray(d.bgs)&&d.bgs.length?d:null}
var bgSeq=0;
function bgr(){
 try{bgColor()}catch(e){}
 var o=bgOwn(),k=(o?o.bgs:S.bgs).map(safeImg).filter(Boolean),L=$('bgl'),key=k.join('|'),op=o&&typeof o.bgo==='number'?o.bgo:S.bgo,calmM=matchMedia('(prefers-reduced-motion:reduce)').matches,co=matchMedia('(pointer:coarse)').matches;
 function ov(){var v=$('bgv');if(!v){v=document.createElement('div');v.id='bgv';L.append(v)}v.style.opacity=k.length?1-op:0}
 if(key===bgKey&&$('bgv')){ov();return}
 bgKey=key;var sq=++bgSeq;clearInterval(bgT);bgI=0;
 var old=Array.prototype.slice.call(L.querySelectorAll('.bgw')),done=false;
 function swap(){
  if(done||sq!==bgSeq)return;done=true;var w=null;
  if(k.length){w=document.createElement('div');w.className='bgw';
   w.innerHTML=k.map(function(u,i){return '<div class="bgi" style="background-image:url(\''+u+'\');opacity:'+(i?0:1)+'"></div>'}).join('');
   if(!calmM){w.style.opacity=0;w.style.transform='scale(1.16)';if(!co)w.style.filter='blur(18px) saturate(1.4) brightness(1.15)'}
   L.insertBefore(w,$('bgv')||null)}
  ov();
  if(w&&!calmM){void w.offsetWidth;w.style.opacity=1;w.style.transform='none';w.style.filter='none'}
  old.forEach(function(x){if(calmM){x.remove();return}x.style.transition='opacity 1.1s ease,transform 1.6s ease,filter 1.1s ease';x.style.opacity=0;x.style.transform='scale(.94)';if(!co)x.style.filter='blur(10px)';setTimeout(function(){if(x.parentNode)x.remove()},1700)});
  if(w&&k.length>1&&!calmM)bgT=setInterval(function(){var im=w.querySelectorAll('.bgi');im[bgI].style.opacity=0;bgI=(bgI+1)%im.length;im[bgI].style.opacity=1},6000)}
 if(!k.length||calmM){swap();return}
 var im0=new Image();im0.src=k[0];
 if(im0.decode)im0.decode().then(swap,swap);else im0.onload=im0.onerror=swap;
 setTimeout(swap,1800)}
function applyEdit(){
 document.body.classList.toggle('editing',EDIT);
 document.querySelectorAll('[data-p]').forEach(function(e){
  if(!EDIT){e.removeAttribute('contenteditable');return}
  try{e.contentEditable='plaintext-only'}catch(x){}
  if(e.contentEditable!=='plaintext-only')e.contentEditable='true';
  e.spellcheck=false;
 });
}
function render(){
 var R=document.documentElement.style,th=S.th;
 R.setProperty('--ts',S.ts);R.setProperty('--gap',S.gap);R.setProperty('--accent',S.accent);
 R.setProperty('--onaccent',th.onaccent||(lum(S.accent)>.6?'#16132E':'#ffffff'));
 var dk=th.bg?lum(th.bg)<.5:false,DF=dk?{ink:'#EDEAFB',muted:'#A29EC9',card:'#211D42',line:'#37316A'}:{ink:'#1B1740',muted:'#5B5780',card:'#F5F3FB',line:'#C9C3E3'};
 ['bg','ink','muted','card','line'].forEach(function(k){var v=th[k]||(k==='bg'?'':DF[k]);if(v)R.setProperty('--'+k,v);else R.removeProperty('--'+k)});
try{bgColor()}catch(e){}
 R.setProperty('--bw',S.bl.on?S.bl.w+'px':'0px');R.setProperty('--bc',S.bl.c||S.accent);
 if(th.tcol)R.setProperty('--tcol',th.tcol);else R.removeProperty('--tcol');
 heroUpd();
 document.querySelectorAll('[data-s]').forEach(function(e){if(e!==document.activeElement)e.textContent=gp(S,e.dataset.p)});
 $('st').innerHTML=stepsHTML();
 $('grid').className=gridCls();$('grid').innerHTML=cardsHTML();
 $('fl').innerHTML=S.tx.links.map(linkHTML).join('');
 dswSync();
 $('hero').dataset.tm=tmode();bgr();route();applyEdit();
 pjr();clr();fillTx();if(window.FXm){FXm.apply();SND.ui();mtRender()}
 if(window.__gl){__gl.size();__gl.cd()}
}
addEventListener('hashchange',function(){
 route();applyEdit();var h=location.hash.slice(1);
 if(['boutique','ecouter','clip','contact','newsletter'].indexOf(h)>=0){var e=$(h);if(e&&!$('home').hidden)e.scrollIntoView()}else scrollTo(0,0);
 if(window.__gl)__gl.size();
});
document.addEventListener('click',function(e){
 var a=e.target.closest&&e.target.closest('.card a[href^="#"]');if(!a||EDIT||e.defaultPrevented||e.button||e.metaKey||e.ctrlKey||e.shiftKey)return;
 if(OWN&&a.hasAttribute('data-p'))return;
 var h=a.getAttribute('href').slice(1),ok=S.products.some(function(p){return p.s===h});if(!ok)return;
 var calm=matchMedia('(prefers-reduced-motion:reduce)').matches,card=a.closest('.card'),sw=card.querySelector('.sw'),onProd=!$('prod').hidden;
 if(calm)return;
 e.preventDefault();e.stopImmediatePropagation();
 function go(){location.hash=h;route();applyEdit();scrollTo(0,0)}
 if(card.classList.contains('pop2'))return;card.classList.add('pop2');if(window.SND)SND.play('switch');setTimeout(function(){card.classList.remove('pop2');
 if(document.startViewTransition){if(!onProd&&sw)sw.style.viewTransitionName='prodimg';
  try{var vt=document.startViewTransition(go);vt.finished.then(function(){if(sw)sw.style.viewTransitionName=''},function(){if(sw)sw.style.viewTransitionName=''})}catch(x){if(sw)sw.style.viewTransitionName='';go()}}
 else go()},230)},true);
document.addEventListener('click',function(e){var a=e.target.closest&&e.target.closest('a[href="#top"]');if(!a||EDIT)return;e.preventDefault();if(location.hash!=='#top')location.hash='top';else{route();scrollTo(0,0)}});
render();
(function(){var g=$('grid');
 g.addEventListener('pointermove',function(e){if(e.pointerType==='touch'||!S.pc.tilt||S.pc.style!=='float')return;var c=e.target.closest&&e.target.closest('.card');if(!c)return;var s=c.querySelector('.sw'),r=s.getBoundingClientRect(),x=(e.clientX-r.left)/r.width-.5,y=(e.clientY-r.top)/r.height-.5;s.style.setProperty('--ry',(x*28)+'deg');s.style.setProperty('--rx',(-y*28)+'deg')});
 g.addEventListener('pointerout',function(e){var c=e.target.closest&&e.target.closest('.card');if(c&&!c.contains(e.relatedTarget)){var s=c.querySelector('.sw');s.style.setProperty('--rx','0deg');s.style.setProperty('--ry','0deg')}})})();

/* ================= disque 3D ================= */
(function(){
 var c=$('c'),R;
 var coarse=matchMedia('(pointer:coarse)').matches;
 if(typeof THREE==='undefined'){document.body.classList.add('nogl');return}
 try{R=new THREE.WebGLRenderer({canvas:c,alpha:true,antialias:true,powerPreference:'high-performance'})}catch(e){document.body.classList.add('nogl');return}
 var VS=[
 'varying vec3 vP;varying vec3 vN;varying vec2 vp;varying vec3 ex;varying vec3 ey;',
 'void main(){vp=position.xy;vec4 mv=modelViewMatrix*vec4(position,1.0);vP=mv.xyz;vN=normalize(normalMatrix*normal);',
 'mat3 mm=mat3(modelViewMatrix);ex=normalize(mm[0]);ey=normalize(mm[1]);gl_Position=projectionMatrix*mv;}'].join('\n');
 var FS=[
 'varying vec3 vP;varying vec3 vN;varying vec2 vp;varying vec3 ex;varying vec3 ey;',
 'uniform float ti,hasTex,holo,glare,la,grain,relief,logo,te,rock,sw,tr,edge,cen,fit,hole,sy;uniform vec3 tint;uniform vec2 ru,tpx;uniform sampler2D tex;uniform sampler2D gro;uniform sampler2D rk;uniform sampler2D eng;uniform float engA;',
 'vec3 hue(float h){return clamp(abs(mod(h*6.+vec3(0.,4.,2.),6.)-3.)-1.,0.,1.);}',
 'vec3 spec(float lam){float k=clamp((lam-400.)/300.,0.,1.);float w=smoothstep(380.,450.,lam)*(1.-smoothstep(650.,740.,lam));return hue(.8*(1.-k))*w;}',
 'vec3 scr(vec3 a,vec3 b){return 1.-(1.-a)*(1.-b);}',
 'float hash(vec2 p){return fract(sin(dot(p,vec2(12.9898,78.233)))*43758.5453);}',
 'float gs(float x,float c,float w){float t=(x-c)/w;return exp(-t*t);}',
 'vec3 dif(vec3 L,vec3 V,vec3 er){float s=abs(dot(L+V,er));return spec(1100.*s)+spec(550.*s)*.6+spec(367.*s)*.35;}',
 'float lobe(vec3 H,vec3 N,vec3 er){vec3 hv=H-N*dot(H,N);float hl=length(hv);vec3 hp=hv/max(hl,1e-3);',
 ' return pow(abs(dot(er,hp)),5.)*smoothstep(.02,.35,hl)*(1.-smoothstep(.55,.95,hl));}',
 'float alobe(vec3 H,vec3 N,vec3 er){vec3 hv=H-N*dot(H,N);float hl=length(hv);vec3 hp=hv/max(hl,1e-3);return pow(abs(dot(er,hp)),3.)*(.55+.45*smoothstep(.02,.4,hl));}',
 'void main(){',
 ' vec2 q=vp*ru*2.;float rr=length(q);float r=length(vp);float aa=max(fwidth(r),1e-4);',
 ' vec2 ruv=vp*ru+.5;vec2 tuv=vp*.5+.5;float lg1=1.-logo;',
 /* zone de donnees d'un vrai CD : de 23 mm a 58 mm du centre (sur 60) ; le bord exterieur et le moyeu n'ont ni relief ni diffraction */
 ' float dm=mix(smoothstep(hole+.235,hole+.305,r)*(1.-smoothstep(.972,.985,r)),1.,logo);',
 ' vec3 V=normalize(-vP);vec3 N=normalize(vN);if(dot(N,V)<0.)N=-N;',
 ' vec2 u=q/max(rr,1e-4);vec3 er=u.x*ex+u.y*ey;',
 ' vec3 base=tint;float alpha;',
 ' if(logo>.5){vec4 tx=texture2D(tex,tuv);base=tx.rgb;alpha=tx.a*hasTex;}',
 ' else{alpha=smoothstep(hole-aa,hole+aa,r)*(1.-smoothstep(1.-aa*1.5,1.,r));float hk=1.-smoothstep(hole+.003,hole+.014,r);alpha*=mix(1.,.15,hk);',
 '  float fe=1.-(1.-fit)*.2;vec2 sv=vp;float sl=length(sv);if(sl>fe)sv*=fe/sl;vec2 uv=vec2(gl_FrontFacing?sv.x:-sv.x,sv.y)*.5+.5;if(hasTex>.5){base=texture2D(tex,uv).rgb;base=mix(base,vec3(.93,.95,.98),smoothstep(fe,fe+.004,sl));alpha*=mix(1.,.15,smoothstep(fe,fe+.004,sl));}}',
 /* relief : contours type empreinte sur le disque, roche granuleuse sur l'image du titre */
 ' float h0;float hx;float hy;float rl=relief;float rs=relief;',
 ' if(logo>.5){vec2 rq=tuv*1.7;h0=texture2D(rk,rq).r;hx=texture2D(rk,rq+vec2(tr*2.,0.)).r;hy=texture2D(rk,rq+vec2(0.,tr*2.)).r;rl=rock*5.;rs=rock*1.2;}',
 ' else{h0=texture2D(gro,ruv).r;hx=texture2D(gro,ruv+vec2(te,0.)).r;hy=texture2D(gro,ruv+vec2(0.,te)).r;}',
 ' float g=h0-.5;',
 ' vec3 Nb=normalize(N-rl*1.8*((hx-h0)*ex+(hy-h0)*ey)*dm);',
 ' if(logo<.5){float tk=cos(r*380.)*(1.-smoothstep(.25,.8,fwidth(r)*380.));Nb=normalize(Nb+er*tk*.065*dm*(.4+relief));}',
 ' if(logo>.5){vec2 tp=tpx*9.;float aR=texture2D(tex,tuv+vec2(tp.x,0.)).a;float aL=texture2D(tex,tuv-vec2(tp.x,0.)).a;float aU=texture2D(tex,tuv+vec2(0.,tp.y)).a;float aD=texture2D(tex,tuv-vec2(0.,tp.y)).a;',
 '  Nb=normalize(Nb-rock*2.4*((aR-aL)*ex+(aU-aD)*ey));}',
 ' float a1=la+sw*logo+.45*sin(ti*.31)+.2*sin(ti*.13+1.);',
 ' vec3 P1=vec3(cos(a1)*4.2,sin(a1)*4.2+sy,-4.4+3.2+.6*sin(ti*.23));',
 ' float a2=la+sw*logo+3.1416+.6*sin(ti*.19+2.);',
 ' vec3 P2=vec3(cos(a2)*4.8,sin(a2)*4.8+sy,-4.4+2.6);',
 ' vec3 L1=normalize(P1-vP);vec3 L2=normalize(P2-vP);',
 ' vec3 H1=normalize(L1+V);vec3 H2=normalize(L2+V);',
 ' vec3 warm=vec3(1.,.975,.93);vec3 cool=vec3(.93,.96,1.);',
 ' float lb1=lobe(H1,Nb,er);float lb2=lobe(H2,Nb,er);',
 ' float nh1=max(dot(Nb,H1),0.);float nh2=max(dot(Nb,H2),0.);',
 ' float flash=pow(nh1,160.)*.8+pow(nh1,18.)*.14+pow(nh2,60.)*.22;',
 ' vec3 rb=dif(L1,V,er)*.9+dif(L2,V,er)*.45;',
 ' float nv=dot(N,V);',
 ' vec3 foil=hue(fract(rr*1.1+nv*1.6+g*.12*rs+ti*.01));foil=mix(vec3(dot(foil,vec3(.333))),foil,.45);',
 ' vec3 col=base*(1.+g*.09*rs*lg1*dm);',
 /* roche : creux sombres, aretes claires, ombrage selon la lumiere */
 ' if(logo>.5){float lam=dot(Nb,L1)*.5+.5;col*=mix(1.,(.38+1.3*h0)*(.55+.9*lam),rock*.9);}',
 /* zones irisees : l'intensite reste pleine, seule la surface couverte change avec le curseur (pas de simple transparence) */
 ' float fm=clamp(.28+.9*lb1+.55*lb2+.9*g*rs+.22*sin(rr*7.+nv*3.+ti*.12),0.,1.);',
 ' float hv=clamp(holo,0.,1.);float cov=smoothstep(1.-hv*1.5,1.-hv*1.5+.4,fm)*smoothstep(0.,.06,hv);',
 ' col=mix(col,col*(.72+.62*foil),cov*.42*dm);',
 ' col=scr(col,rb*.62*cov*dm*(1.+g*.8*rs));',
 ' col=scr(col,foil*.16*cov*dm);',
 ' vec3 white=warm*lb1*.42+cool*lb2*.2+warm*flash;',
 ' col=scr(col,white*glare*(1.+g*.6*rs));',
 /* paillettes : la part de grains qui scintillent change avec le curseur, chaque grain garde sa pleine brillance */
 ' vec2 gp=ruv*340.;vec2 gid=floor(gp);vec2 gf=fract(gp)-.5;',
 ' float g1=hash(gid);float g2=hash(gid+vec2(3.1,7.7));float g3=hash(gid+vec2(11.3,5.9));float g4=hash(gid+vec2(17.7,2.3));',
 ' float dotm=smoothstep(.36,.14,length(gf-(vec2(g1,g2)-.5)*.4));',
 ' float gaa=1.-smoothstep(.5,1.3,max(fwidth(gp.x),fwidth(gp.y)));',
 ' float on=step(g4,clamp((grain+logo*rock*.3)*1.3,0.,1.));',
 ' vec3 gn=normalize(Nb+(ex*(g1-.5)+ey*(g2-.5)));',
 ' float spk=pow(max(dot(gn,H1),0.),70.)+.5*pow(max(dot(gn,H2),0.),70.);',
 ' col=scr(col,mix(vec3(1.),hue(g3),.5)*spk*dotm*gaa*dm*on*1.2);',
' if(logo<.5){float fe0=1.-(1.-fit)*.2;float rimK=smoothstep(fe0,fe0+.004,r)+(1.-smoothstep(hole+.003,hole+.014,r));col=mix(col,vec3(.93,.95,.98),clamp(rimK,0.,1.)*.6);col=scr(col,(rb*.5+foil*.2)*clamp(rimK,0.,1.)*(.5+.5*lb1+flash));float cz=smoothstep(hole,hole+.025,r)*(1.-smoothstep(hole+.23,hole+.26,r));float gw=1.-smoothstep(hole,hole+.085,r);',
 '  col=mix(col,col*.8+vec3(.03,.05,.08),cz*cen*.55);',
 '  col=scr(col,vec3(.9,.95,1.)*gw*cen*(.18+.5*lb1+flash));',
 '  col=scr(col,vec3(.82,.91,1.)*(gs(r,hole+.09,.004)+gs(r,hole+.243,.004))*cen*(.2+lb1+.5*flash));',
 '  float rm=smoothstep(.978,.992,r);col=mix(col,mix(col,vec3(.80,.90,.96),.5),rm*edge*.7);',
 '  col=scr(col,vec3(.85,.93,1.)*gs(r,.994,.0035)*edge*(.25+lb1+lb2+flash*.8));}',
 /* dos : face argentée d'un vrai CD (miroir aluminium, bandes d'arc-en-ciel, moyeu en plastique clair, bord fin) */
 ' if(logo<.5&&!gl_FrontFacing){float dz=smoothstep(hole+.22,hole+.27,r)*(1.-smoothstep(.962,.978,r));',
 '  float an=alobe(H1,N,er)*.9+alobe(H2,N,er)*.45;vec3 sil=vec3(.47,.49,.52)*(.72+.45*an)+vec3(.03)*sin(rr*3.+ti*.05);',
 '  vec3 hub=mix(vec3(.58,.62,.66),vec3(.72,.75,.79),.5+.5*N.x*.6)*(.92+.08*lobe(H1,N,er));',
 '  vec3 bc=mix(hub,sil,dz);float nb1=max(dot(N,H1),0.),nb2=max(dot(N,H2),0.),fls=pow(nb1,160.)*.8+pow(nb1,18.)*.14+pow(nb2,60.)*.22;',
 '  bc=scr(bc,rb*(.38+.4*an)*dz*.85);',
 '  float hr=smoothstep(hole-.004,hole+.012,r);bc*=mix(.55,1.,hr);',
 '  bc=mix(bc,bc*.78,gs(r,hole+.235,.006)*.8);bc=scr(bc,vec3(.95,.98,1.)*gs(r,hole+.245,.004)*.45);',
 '  bc=mix(bc,bc*.8,gs(r,hole+.09,.005)*.6);bc=scr(bc,vec3(.95,.98,1.)*gs(r,hole+.1,.004)*.4);',
 '  float rmB=smoothstep(.972,.985,r);bc=mix(bc,vec3(.60,.62,.65),rmB);bc=mix(bc,vec3(.40,.41,.44),smoothstep(.991,.998,r)*.9);',
 '  bc=scr(bc,warm*fls*glare*.55);bc=scr(bc,warm*lobe(H1,N,er)*.12*glare);',
 '  if(engA>.001){vec2 eu=vec2(.5-vp.x*.5,vp.y*.5+.5);float a0=texture2D(eng,eu).r,a1=texture2D(eng,eu+vec2(-.0022,.0022)).r;bc=mix(bc,bc*.66,a0*engA*dz);bc=scr(bc,vec3(.92,.96,1.)*max(a1-a0,0.)*.6*engA*dz);}',
 '  col=bc;}',
 ' col+=(hash(gl_FragCoord.xy+ti)-.5)/255.;',
 ' gl_FragColor=vec4(clamp(col,0.,1.),alpha);',
 '}'].join('\n');
 var aniso=R.capabilities.getMaxAnisotropy();
 try{var dbg=R.getContext().getExtension('WEBGL_debug_renderer_info'),rnm=dbg?String(R.getContext().getParameter(dbg.UNMASKED_RENDERER_WEBGL)):'';if(/swiftshader|llvmpipe|software|basic render/i.test(rnm)){window.__SOFTGL=1;document.documentElement.classList.add('lite')}}catch(e){}
 function mkTex(cv){var t=new THREE.CanvasTexture(cv);t.minFilter=THREE.LinearMipmapLinearFilter;t.magFilter=THREE.LinearFilter;t.anisotropy=aniso;return t}
 function flatTex(){var cv=document.createElement('canvas');cv.width=cv.height=4;var g=cv.getContext('2d');g.fillStyle='#808080';g.fillRect(0,0,4,4);var t=mkTex(cv);t.wrapS=t.wrapT=THREE.RepeatWrapping;return t}
 function mkRelief(n){
  var cv=document.createElement('canvas');cv.width=cv.height=n;var g=cv.getContext('2d'),im=g.createImageData(n,n),D=im.data;
  var s=11;function rnd(){s=(s*16807)%2147483647;return s/2147483647}
  var K=26,cx=[],cy=[],ca=[],cb=[],cr=[],co=[],i,x,y;
  for(i=0;i<K;i++){var th=rnd()*6.2832;cx.push(rnd()*n);cy.push(rnd()*n);ca.push(Math.cos(th));cb.push(Math.sin(th));cr.push(.75+rnd()*.5);co.push(rnd()*n*.04)}
  var P=n/170,k2=6.2832/n;
  for(y=0;y<n;y++)for(x=0;x<n;x++){
   var wx=x+n*.009*Math.sin(k2*(y*5)+1.3)+n*.005*Math.sin(k2*(y*13+x*5)),wy=y+n*.009*Math.sin(k2*(x*4)+.4)+n*.005*Math.sin(k2*(x*11-y*6));
   var best=1e9;
   for(i=0;i<K;i++){var dx=wx-cx[i],dy=wy-cy[i];dx-=n*Math.round(dx/n);dy-=n*Math.round(dy/n);
    var u=dx*ca[i]+dy*cb[i],v=(dy*ca[i]-dx*cb[i])*cr[i],dd=Math.sqrt(u*u+v*v)+co[i];if(dd<best)best=dd}
   var hv=Math.round((.5+.5*Math.cos(best/P*6.2832))*255),o=(y*n+x)*4;D[o]=D[o+1]=D[o+2]=hv;D[o+3]=255}
  g.putImageData(im,0,0);return cv;
 }
 /* roche : bruit fractal repetable, octaves en aretes (ridged) + grain fin */
 function mkRock(n){
  var cv=document.createElement('canvas');cv.width=cv.height=n;var g=cv.getContext('2d'),im=g.createImageData(n,n),D=im.data;
  var s=29;function rnd(){s=(s*16807)%2147483647;return s/2147483647}
  var oc=[[3,1,1],[6,.8,1],[12,.55,1],[24,.4,1],[48,.3,0],[96,.22,0],[192,.16,0]],L=oc.map(function(o){var a=new Float32Array(o[0]*o[0]);for(var i=0;i<a.length;i++)a[i]=rnd();return a}),tot=0;
  oc.forEach(function(o){tot+=o[1]});
  function sm(k,x,y){var p=oc[k][0],fx=((x/n*p)%p+p)%p,fy=((y/n*p)%p+p)%p,ix=Math.floor(fx),iy=Math.floor(fy),tx=fx-ix,ty=fy-iy;
   tx=tx*tx*tx*(tx*(tx*6-15)+10);ty=ty*ty*ty*(ty*(ty*6-15)+10);var x0=ix%p,y0=iy%p,x1=(ix+1)%p,y1=(iy+1)%p,a=L[k];
   return (a[y0*p+x0]*(1-tx)+a[y0*p+x1]*tx)*(1-ty)+(a[y1*p+x0]*(1-tx)+a[y1*p+x1]*tx)*ty}
  for(var y=0;y<n;y++)for(var x=0;x<n;x++){
   var wx=x+n*.07*(sm(0,x+17,y+5)-.5),wy=y+n*.07*(sm(0,x+3,y+41)-.5),v=0;
   for(var k=0;k<oc.length;k++){var nv=sm(k,wx,wy);if(oc[k][2])nv=1-Math.abs(2*nv-1);v+=oc[k][1]*nv}
   var h=v/tot;h=Math.max(0,Math.min(1,(h-.5)*2.1+.5));var o=(y*n+x)*4;D[o]=D[o+1]=D[o+2]=Math.round(h*255);D[o+3]=255}
  g.putImageData(im,0,0);return cv;
 }
 var U={ti:{value:0},tex:{value:null},gro:{value:flatTex()},rk:{value:flatTex()},hasTex:{value:0},holo:{value:.3},glare:{value:1},la:{value:.8},grain:{value:.35},relief:{value:.35},logo:{value:0},te:{value:.25},tr:{value:.004},rock:{value:0},edge:{value:.3},cen:{value:.5},fit:{value:.94},hole:{value:.07},sy:{value:0},sw:{value:0},eng:{value:flatTex()},engA:{value:0},tpx:{value:new THREE.Vector2(.001,.001)},ru:{value:new THREE.Vector2(.5,.5)},tint:{value:new THREE.Color('#e8ecf8')}};
 var UL={eng:U.eng,engA:U.engA,ti:U.ti,tex:{value:null},gro:U.gro,rk:U.rk,hasTex:{value:0},holo:{value:.3},glare:{value:1},la:{value:.8},grain:{value:.3},relief:U.relief,logo:{value:1},te:U.te,tr:U.tr,rock:{value:.7},edge:{value:0},cen:{value:0},fit:{value:1},hole:{value:.07},sy:{value:0},sw:U.sw,tpx:{value:new THREE.Vector2(.001,.001)},ru:{value:new THREE.Vector2(.5,.5)},tint:U.tint};
 var m=new THREE.ShaderMaterial({side:THREE.DoubleSide,transparent:true,uniforms:U,vertexShader:VS,fragmentShader:FS});
 var mL=new THREE.ShaderMaterial({side:THREE.DoubleSide,transparent:true,depthTest:false,depthWrite:false,uniforms:UL,vertexShader:VS,fragmentShader:FS});
 m.extensions.derivatives=true;mL.extensions.derivatives=true;
 var Sc=new THREE.Scene(),C=new THREE.PerspectiveCamera(35,1,.1,50);C.position.z=4.4;
 var d=new THREE.Mesh(new THREE.CircleGeometry(1,coarse?160:256),m),lg=new THREE.Mesh(new THREE.PlaneGeometry(2,2),mL);
 lg.renderOrder=0;d.renderOrder=1;lg.visible=false;Sc.add(lg);Sc.add(d);
 try{var wl=new THREE.Mesh((function(){var g=new THREE.CylinderGeometry(1,1,.003,coarse?96:192,1,true);g.rotateX(Math.PI/2);return g})(),new THREE.ShaderMaterial({uniforms:{tint:U.tint},
  vertexShader:'varying vec3 vP;varying vec3 vN;void main(){vec4 mv=modelViewMatrix*vec4(position,1.);vP=mv.xyz;vN=normalize(normalMatrix*normal);gl_Position=projectionMatrix*mv;}',
  fragmentShader:'varying vec3 vP;varying vec3 vN;uniform vec3 tint;void main(){vec3 V=normalize(-vP),N=normalize(vN);if(dot(N,V)<0.)N=-N;float f=pow(1.-abs(dot(N,V)),2.);float s=pow(max(dot(N,normalize(normalize(vec3(2.,3.,2.))+V)),0.),24.);vec3 c=mix(vec3(.80,.85,.92),vec3(.97,.99,1.),.5+.5*N.x)+vec3(.25)*s;gl_FragColor=vec4(c,.06+.12*f+.35*s);}',transparent:true,depthWrite:false}));d.add(wl)}catch(e){}
 setTimeout(function(){var n=1024,t=mkTex(mkRelief(n));t.wrapS=t.wrapT=THREE.RepeatWrapping;U.gro.value=t;U.te.value=1/n;
  /* version haute définition calculée en arrière-plan (même motif, 2x plus fin) puis remplacée sans à-coup */
  try{var N=Math.min(coarse?1536:2048,R.capabilities.maxTextureSize),src='onmessage=function(e){var n=e.data,D=new Uint8ClampedArray(n*n*4),s=11;function rnd(){s=(s*16807)%2147483647;return s/2147483647}var K=26,cx=[],cy=[],ca=[],cb=[],cr=[],co=[],i,x,y;for(i=0;i<K;i++){var th=rnd()*6.2832;cx.push(rnd()*n);cy.push(rnd()*n);ca.push(Math.cos(th));cb.push(Math.sin(th));cr.push(.75+rnd()*.5);co.push(rnd()*n*.04)}var P=n/170,k2=6.2832/n;for(y=0;y<n;y++)for(x=0;x<n;x++){var wx=x+n*.009*Math.sin(k2*(y*5)+1.3)+n*.005*Math.sin(k2*(y*13+x*5)),wy=y+n*.009*Math.sin(k2*(x*4)+.4)+n*.005*Math.sin(k2*(x*11-y*6));var best=1e9;for(i=0;i<K;i++){var dx=wx-cx[i],dy=wy-cy[i];dx-=n*Math.round(dx/n);dy-=n*Math.round(dy/n);var u=dx*ca[i]+dy*cb[i],v=(dy*ca[i]-dx*cb[i])*cr[i],dd=Math.sqrt(u*u+v*v)+co[i];if(dd<best)best=dd}var hv=Math.round((.5+.5*Math.cos(best/P*6.2832))*255),o=(y*n+x)*4;D[o]=D[o+1]=D[o+2]=hv;D[o+3]=255}postMessage(D,[D.buffer])}';
   if(N>n&&window.Worker){var w=new Worker(URL.createObjectURL(new Blob([src],{type:'text/javascript'})));
    w.onmessage=function(e){try{var cv=document.createElement('canvas');cv.width=cv.height=N;var g=cv.getContext('2d'),im=g.createImageData(N,N);im.data.set(e.data);g.putImageData(im,0,0);var t2=mkTex(cv);t2.wrapS=t2.wrapT=THREE.RepeatWrapping;var o=U.gro.value;U.gro.value=t2;if(o&&o.dispose)o.dispose()}catch(x){}w.terminate()};
    w.onerror=function(){try{w.terminate()}catch(x){}};w.postMessage(N)}}catch(x){}},80);
 var rockDone=false;
 function ensureRock(){if(rockDone)return;rockDone=true;setTimeout(function(){var n=512,t=mkTex(mkRock(n));t.wrapS=t.wrapT=THREE.RepeatWrapping;U.rk.value=t;U.tr.value=1/n},30)}
 var ZM=1,ZT=1,DS=1,GS=1,ry=0,rx=0,vy=.006,vx=0,fl=0,spin=0,drag=false,lx=0,ly=0,last=scrollY,t0=performance.now(),sdy=0,seenTex=false,hold=0,tz=performance.now(),shownCv=false,rv=performance.now();c.style.opacity=0;c.style.transition='opacity .5s ease';function showCv(){if(!shownCv){shownCv=true;c.style.opacity=1}}
 var calm=matchMedia('(prefers-reduced-motion:reduce)').matches;
 var sx=0,sy2=0,st=0,taps=[],lt=0;
 var gb=$('grab');gb.addEventListener('wheel',function(e){if(!S.zm||S.zm.on===false)return;e.preventDefault();var mx=Math.max(1.2,Math.min(4,+S.zm.max||2.5));ZT=Math.max(.6,Math.min(mx,ZT*Math.exp(-e.deltaY*(e.deltaMode===1?.05:.0016))))},{passive:false});gb.addEventListener('dblclick',function(){ZT=1});var pts={},pz=null;function pdist(){var k=Object.keys(pts);if(k.length<2)return 0;var a=pts[k[0]],b=pts[k[1]];return Math.hypot(a.x-b.x,a.y-b.y)}function zmx(){return Math.max(1.2,Math.min(4,+S.zm.max||2.5))}
 function pend(e){delete pts[e.pointerId];if(pz&&Object.keys(pts).length<2){pz=null;window.PZA=false;window.PZT=Date.now();if(ZT>.88&&ZT<1.12)ZT=1}}
 gb.addEventListener('gesturestart',function(e){e.preventDefault()},{passive:false});gb.addEventListener('lostpointercapture',pend);addEventListener('pointerup',pend);
 gb.addEventListener('pointerdown',function(e){if(e.isPrimary){pts={};pz=null;window.PZA=false}pts[e.pointerId]={x:e.clientX,y:e.clientY};if(Object.keys(pts).length>=2){if(S.zm&&S.zm.on!==false){pz={d:pdist()||1,z:ZT};window.PZA=true;window.PZT=Date.now()}drag=false;window.DRG=false;try{gb.setPointerCapture(e.pointerId)}catch(x){}return}hold=0;drag=true;window.DRG=true;lt=performance.now();lx=sx=e.clientX;ly=sy2=e.clientY;st=performance.now();try{gb.setPointerCapture(e.pointerId)}catch(x){}});gb.addEventListener('pointercancel',function(e){pend(e);drag=false;window.DRG=false});
 addEventListener('pointerup',function(){drag=false;window.DRG=false});
 gb.addEventListener('pointerup',function(e){if(window.PZA||Date.now()-(window.PZT||0)<500)return;
  var n=performance.now();if(Math.hypot(e.clientX-sx,e.clientY-sy2)<9&&n-st<400){
   taps.push(n);taps=taps.filter(function(t){return n-t<3500});if(window.SND)SND.play('tap',taps.length);if(taps.length>=5){taps=[];if(window.unlockEgg)unlockEgg()}}});
 gb.addEventListener('pointermove',function(e){var q=pts[e.pointerId];if(q){q.x=e.clientX;q.y=e.clientY}if(pz){ZT=Math.max(.6,Math.min(zmx(),pz.z*pdist()/pz.d));window.PZT=Date.now();return}if(!drag)return;var n=performance.now(),k=Math.max(.5,Math.min(4,(n-lt)/16.7));lt=n;var dx=e.clientX-lx,dy=e.clientY-ly;ry+=dx*.012;vy=Math.max(-.6,Math.min(.6,vy*.45+(dx*.012/k)*.55));if(S.rot.free){rx+=dy*.01;vx=Math.max(-.6,Math.min(.6,vx*.45+(dy*.01/k)*.55))}else rx=Math.max(-1.2,Math.min(1.2,rx+dy*.006));lx=e.clientX;ly=e.clientY});
 function flip(){fl+=Math.PI}
 
 var lgAsp=1,lw=0,lh=0,lpr=0,QS=window.__SOFTGL?.5:navigator.brave?.86:1;
 function size(){var w=c.clientWidth,h=c.clientHeight;if(!w||!h)return;
  var pr=Math.min(Math.max(devicePixelRatio||1,2),coarse?2.5:3)*QS;
  if(w!==lw||h!==lh||pr!==lpr){lw=w;lh=h;lpr=pr;R.setPixelRatio(pr);R.setSize(w,h,false);C.aspect=w/h;C.updateProjectionMatrix()}
  var vh=2*4.4*Math.tan(17.5*Math.PI/180),vw=vh*w/h;
  var fm=Math.max(.25,Math.min(.5,+S.dmob||.4)),ds=Math.min(S.disc,(w<700?fm:.46)*vw,.49*vh);DS=ds;d.scale.setScalar(ds*ZM);GS=2*ds/vh*h*1.06;var gq=$('grab');gq.style.width=gq.style.height=Math.round(GS*ZM)+'px';gq.style.top=(h/2)+'px';
  var W=S.tsz*vw,H=W/lgAsp;if(H>.9*vh){H=.9*vh;W=H*lgAsp}
  lg.scale.set(W/2,H/2,1);lg.position.y=S.ty*vh/2;UL.ru.value.set(W/(4*ds),H/(4*ds));
 }
 var cur='',lgSrc='',tl=new THREE.TextureLoader(),cache={},order=[];
 function keep(src,t){cache[src]=t;order.push(src);while(order.length>2){var o=order.shift();if(o!==cur&&cache[o]){if(cache[o].dispose)cache[o].dispose();delete cache[o]}else if(o===cur)order.push(o)}}
 var lcache={},lorder=[];
 function lset(e){UL.tex.value=e.t;UL.tpx.value.set(e.px,e.py);UL.hasTex.value=1;lgAsp=e.asp;size()}
 function cd(){if(ENGON&&!engB)engrave(true);engSync();if(seenTex)hold=performance.now()+900;var dk=window.DSHG||curDisc(),k=dcd(dk),ti=dti(curDisc());
  U.holo.value=k.holo;U.glare.value=k.glare;U.la.value=k.la;U.grain.value=k.grain;U.relief.value=k.relief;U.edge.value=k.edge;U.cen.value=k.cen;U.fit.value=k.fit;U.hole.value=k.hole;U.tint.value.set(dk.tint||S.cd.tint);
  UL.holo.value=ti.holo;UL.glare.value=ti.glare;UL.la.value=ti.la;UL.grain.value=ti.grain;UL.rock.value=ti.rock;
  var src=safeImg(dk.img);
  if(src!==cur){cur=src;
   if(!src){U.hasTex.value=0;seenTex=true;showCv()}
   else if(cache[src]){U.tex.value=cache[src];U.hasTex.value=1}
   else tl.load(src,function(tx){
    var im=tx.image,ms=Math.min(im.width,im.height),cap=Math.min(4096,R.capabilities.maxTextureSize,coarse?2048:4096);
    var sz=Math.max(256,Math.min(cap,Math.pow(2,Math.ceil(Math.log(ms)/Math.LN2))));
    var cv=document.createElement('canvas');cv.width=cv.height=sz;var g=cv.getContext('2d');g.imageSmoothingEnabled=true;g.imageSmoothingQuality='high';
    g.drawImage(im,(im.width-ms)/2,(im.height-ms)/2,ms,ms,0,0,sz,sz);
    var t=mkTex(cv);keep(src,t);if(src===cur){U.tex.value=t;U.hasTex.value=1}if(tx.dispose)tx.dispose();
   },undefined,function(){if(src===cur)U.hasTex.value=0});
  }
  var ls=tmode()==='text'?'':safeImg(titleImg());
  if(ls!==lgSrc){lgSrc=ls;
   if(!ls)UL.hasTex.value=0;
   else if(lcache[ls])lset(lcache[ls]);
   else{UL.hasTex.value=0;tl.load(ls,function(tx){
    var im=tx.image;function p2(v){return Math.min(2048,Math.pow(2,Math.ceil(Math.log(v)/Math.LN2)))}
    var cv=document.createElement('canvas');cv.width=p2(im.width);cv.height=p2(im.height);var g=cv.getContext('2d');g.imageSmoothingQuality='high';g.drawImage(im,0,0,cv.width,cv.height);
    var e={t:mkTex(cv),px:1/cv.width,py:1/cv.height,asp:im.width/im.height};lcache[ls]=e;lorder.push(ls);
    while(lorder.length>2){var o=lorder.shift();if(o!==lgSrc&&lcache[o]){if(lcache[o].t.dispose)lcache[o].t.dispose();delete lcache[o]}else lorder.push(o)}
    if(tx.dispose)tx.dispose();ensureRock();if(ls===lgSrc)lset(e);
   },undefined,function(){if(ls===lgSrc)UL.hasTex.value=0})}
  }
 }
 var revealing=false,engT=0,engB=false;
 function engrave(on){if(on){var cv=document.createElement('canvas');cv.width=cv.height=1024;var g=cv.getContext('2d');g.fillStyle='#000';g.fillRect(0,0,1024,1024);g.fillStyle='#fff';g.textAlign='center';g.textBaseline='middle';
   function arc(t,r,top,px){t=String(t||'').toUpperCase();if(!t)return;g.font='700 '+px+'px ui-monospace,Menlo,Consolas,monospace';var sp=px*.62,tot=sp*t.length,a0=top?(-Math.PI/2-tot/r/2):(Math.PI/2+tot/r/2);for(var i=0;i<t.length;i++){var a=top?a0+(i+.5)*sp/r:a0-(i+.5)*sp/r;g.save();g.translate(512+Math.cos(a)*r,512+Math.sin(a)*r);g.rotate(top?a+Math.PI/2:a-Math.PI/2);g.fillText(t[i],0,0);g.restore()}}
   var lk=engLink();arc(S.eg5.l1,456,true,20);arc(lk,456,false,lk.length>20?18:21);arc(S.eg5.l3,430,false,15)
   var t=mkTex(cv);U.eng.value=t;engB=true}engSync()}
 function engSync(){engT=(ENGON&&curDisc().egg)?1:0}
 /* photos du disque par le même moteur 3D (mini-jeu) : une image fixe par disque + une animation de rotation */
 var gcache={};function shotsFree(){for(var k in gcache){try{gcache[k].dispose()}catch(e){}}gcache={}}
 function shotTex(dk){return new Promise(function(res){var src=safeImg(dk&&dk.img);if(!src){res(null);return}if(cache[src]){res({t:cache[src],own:false});return}if(gcache[src]){res({t:gcache[src],own:false});return}
  tl.load(src,function(tx){try{var im=tx.image,ms=Math.min(im.width,im.height),sz=Math.max(256,Math.min(2048,R.capabilities.maxTextureSize,Math.pow(2,Math.ceil(Math.log(ms)/Math.LN2))));var cv=document.createElement('canvas');cv.width=cv.height=sz;var g=cv.getContext('2d');g.imageSmoothingEnabled=true;g.imageSmoothingQuality='high';g.drawImage(im,(im.width-ms)/2,(im.height-ms)/2,ms,ms,0,0,sz,sz);var t=mkTex(cv);if(tx.dispose)tx.dispose();gcache[src]=t;res({t:t,own:false})}catch(e){res(null)}},undefined,function(){res(null)})})}
 function shots(list,o){o=o||{};var big=o.still||0,fr=o.frames||0,fs=o.fsize||192;list=(list||[]).filter(Boolean);
  return Promise.all(list.map(shotTex)).then(function(tx){
   var sv={tex:U.tex.value,has:U.hasTex.value,holo:U.holo.value,glare:U.glare.value,la:U.la.value,grain:U.grain.value,relief:U.relief.value,edge:U.edge.value,cen:U.cen.value,fit:U.fit.value,hole:U.hole.value,tint:U.tint.value.clone(),engA:U.engA.value,sy:U.sy.value,sw:U.sw.value,sc:d.scale.x,rot:d.rotation.clone(),lgv:lg.visible,asp:C.aspect,cc:R.getClearColor(new THREE.Color()).clone(),ca:R.getClearAlpha(),rt:R.getRenderTarget()};
   var out={},rts={};
   function rtg(n){if(!rts[n])rts[n]=new THREE.WebGLRenderTarget(n,n,{minFilter:THREE.LinearFilter,magFilter:THREE.LinearFilter,format:THREE.RGBAFormat});return rts[n]}
   function snap(n,os,a){var T=rtg(n);d.rotation.set(o.flat?0:.14,o.flat?0:-.09,a);R.setRenderTarget(T);R.setClearColor(0x000000,0);R.clear();R.render(Sc,C);var px=new Uint8Array(n*n*4);R.readRenderTargetPixels(T,0,0,n,n,px);
    var cv=document.createElement('canvas');cv.width=cv.height=n;var g=cv.getContext('2d'),im=g.createImageData(n,n),D=im.data;
    for(var y=0;y<n;y++){var sr=(n-1-y)*n*4,dr=y*n*4;for(var x=0;x<n*4;x+=4){var al=px[sr+x+3];if(al){var k=255/al;D[dr+x]=Math.min(255,px[sr+x]*k);D[dr+x+1]=Math.min(255,px[sr+x+1]*k);D[dr+x+2]=Math.min(255,px[sr+x+2]*k);D[dr+x+3]=al}}}
    g.putImageData(im,0,0);var c2=cv;if(os!==n){c2=document.createElement('canvas');c2.width=c2.height=os;var g2=c2.getContext('2d');g2.imageSmoothingEnabled=true;g2.imageSmoothingQuality='high';g2.drawImage(cv,0,0,os,os)}c2._f=.94;return c2}
   try{
    lg.visible=false;C.aspect=1;C.updateProjectionMatrix();U.engA.value=0;U.sy.value=0;U.sw.value=0;
    d.scale.setScalar(4.4*Math.tan(17.5*Math.PI/180)*.94);
    list.forEach(function(dk,i){var k=dcd(dk);U.holo.value=k.holo;U.glare.value=k.glare;U.la.value=k.la;U.grain.value=k.grain;U.relief.value=k.relief;U.edge.value=k.edge;U.cen.value=k.cen;U.fit.value=k.fit;U.hole.value=k.hole;U.tint.value.set(dk.tint||S.cd.tint);
     if(tx[i]){U.tex.value=tx[i].t;U.hasTex.value=1}else U.hasTex.value=0;
     var e={};if(big)e.still=snap(big*2,big,0);if(o.angles)e.frames=o.angles.map(function(a){return snap(fs*2,fs,a)});else if(fr){e.frames=[];for(var j=0;j<fr;j++)e.frames.push(snap(fs*2,fs,-j/fr*Math.PI*2))}
     out[dk.k]=e});
   }catch(err){out=null}
   U.tex.value=sv.tex;U.hasTex.value=sv.has;U.holo.value=sv.holo;U.glare.value=sv.glare;U.la.value=sv.la;U.grain.value=sv.grain;U.relief.value=sv.relief;U.edge.value=sv.edge;U.cen.value=sv.cen;U.fit.value=sv.fit;U.hole.value=sv.hole;U.tint.value.copy(sv.tint);U.engA.value=sv.engA;U.sy.value=sv.sy;U.sw.value=sv.sw;
   d.scale.setScalar(sv.sc);d.rotation.copy(sv.rot);lg.visible=sv.lgv;C.aspect=sv.asp;C.updateProjectionMatrix();R.setRenderTarget(sv.rt);R.setClearColor(sv.cc,sv.ca);
   tx.forEach(function(x){if(x&&x.own&&x.t.dispose)x.t.dispose()});Object.keys(rts).forEach(function(n){rts[n].dispose()});
   return out})}
 window.__gl={vis:function(v){d.visible=!!v},face:function(){ry=0;rx=0;fl=0;vx=0;vy=.035;hold=0},mat:function(){d.updateMatrix();var e=d.matrix.elements,k=Math.hypot(e[0],e[1],e[2])||1;return [e[0]/k,e[1]/k,e[4]/k,e[5]/k]},shots:shots,shotsFree:shotsFree,front:function(ms){var n=performance.now();hold=Math.max(hold,n+(ms||1600));fl=Math.round(ry/6.2832)*6.2832-ry;vy=0;vx=0},engrave:engrave,hint:function(on){if(on){if(!engB)engrave(true);engT=.3}else engSync()},side:function(){return Math.cos(ry)<0},hold:function(v){hold=v},reveal:function(){var n=performance.now();ry=0;rx=0;spin=0;vx=0;fl=0;sdy=0;tz=n;hold=0;last=scrollY;size();
   if(U.hasTex.value===1){seenTex=true;revealing=true;shownCv=false;c.style.transition='none';c.style.opacity=0;void c.offsetWidth;c.style.transition='opacity .5s ease';requestAnimationFrame(function(){requestAnimationFrame(function(){revealing=false;showCv()})})}
   else{seenTex=false;shownCv=false;rv=n;c.style.transition='none';c.style.opacity=0;void c.offsetWidth;c.style.transition='opacity .5s ease'}},size:size,cd:cd,flip:flip,kick:function(n){vy+=.3*(n||1)}};
 if(window.ResizeObserver)new ResizeObserver(size).observe(c);else addEventListener('resize',size);
 var inView=true;if(window.IntersectionObserver)new IntersectionObserver(function(es){inView=es[es.length-1].isIntersecting},{rootMargin:'120px'}).observe($('hero'));
 size();cd();
 var checked=false,lastT=performance.now(),ema=16,slow=0,fast=0,dn=0;
 function loop(){
  var now=performance.now(),dt=Math.min(100,now-lastT);lastT=now;var k=Math.min(3,dt/16.7);
  if(S.zm&&S.zm.on===false)ZT=1;if(Math.abs(ZT-ZM)>.0008){ZM+=(ZT-ZM)*(1-Math.pow(.86,k));d.scale.setScalar(DS*ZM);var gz=$('grab');gz.style.width=gz.style.height=Math.round(GS*ZM)+'px'}
  var dd=curDisc(),spd=calm?0:(dd&&typeof dd.rs==='number'?dd.rs:S.spd);
  var hd=now<hold||(!seenTex&&now<rv+6000);if(!shownCv&&now>rv+3500)showCv();if(seenTex&&!shownCv&&!revealing&&c.clientWidth>0)showCv();
  if(!drag){vy+=(.006*spd-vy)*(1-Math.pow(.96,k));if(hd){if(!fl){var tr2=Math.round(ry/6.2832)*6.2832;ry+=(tr2-ry)*(1-Math.pow(.9,k))}vy*=.9;var tx2=Math.round(rx/6.2832)*6.2832;rx+=(tx2-rx)*(1-Math.pow(.88,k));vx*=.85}else ry+=vy*k;if(hd){var tg=Math.round(spin/6.2832)*6.2832;spin+=(tg-spin)*(1-Math.pow(.9,k))}else spin+=.004*spd*k;if(S.rot.free){rx+=vx*k;vx*=Math.pow(.93,k)}
   if(fl){var fs=fl*(1-Math.pow(.88,k));ry+=fs;fl-=fs;if(Math.abs(fl)<.002){ry+=fl;fl=0}}}
  var sc=scrollY;sdy+=(sc-last)*.004;last=sc;if(hd)sdy=0;sdy=Math.max(-.4,Math.min(.4,sdy));ry+=sdy*.3;sdy*=.7;
  var ti2=calm?0:(now-tz)/1000;d.rotation.set(rx+Math.sin(spin*2)*.08+Math.sin(ti2*.9)*.2,ry+Math.sin(ti2*.55)*.12,spin);if(BRK){d.rotation.x+=(Math.random()-.5)*.06;d.rotation.y+=(Math.random()-.5)*.06}
  U.engA.value+=(engT-U.engA.value)*.035;
  U.ti.value=calm?3:(now-t0)/1000;U.sw.value=0;try{var hr=$('hero').getBoundingClientRect(),chh=c.clientHeight||1;UL.sy.value=Math.max(-5,Math.min(5,(hr.top+chh/2-innerHeight/2)*(2*4.4*Math.tan(17.5*Math.PI/180))/chh))}catch(e){}
  if(!seenTex&&U.hasTex.value===1){seenTex=true;hold=0;vy=.006*spd;showCv()}
  lg.visible=UL.hasTex.value===1&&tmode()!=='text';
  if(c.clientWidth&&inView&&!window.PGON){
   R.render(Sc,C);
   /* qualite adaptative : si l'appareil rame, on baisse un peu la definition pour garder la fluidite */
   ema=ema*.9+dt*.1;if(ema>21&&QS>.5){if(++slow>16){QS=Math.max(.5,QS-.14);slow=0;ema=16;dn++;size()}}else if(ema>26&&QS<=.5){if(++slow>40){slow=0;document.documentElement.classList.add('lite')}}else{slow=0;if(ema<19&&QS<1&&dn<3){if(++fast>720){QS=Math.min(1,QS+.08);fast=0;size()}}else fast=0}
  }
  if(!checked){checked=true;try{var pr=R.info.programs&&R.info.programs[0];if(pr&&pr.diagnostics&&pr.diagnostics.runnable===false)document.body.classList.add('nogl')}catch(e){}}
  requestAnimationFrame(loop)
 }
 loop();
})();

/* ================= shader qui englobe tout le site (grain, irisation, vignette) ================= */
function fxEff(){var d=curDisc();if(d&&d.fx&&typeof d.fx==='object'){var o={};for(var k in S.fx)o[k]=S.fx[k];nz(d.fx,o);if(typeof d.fx.mode==='string')o.mode=d.fx.mode;return o}return S.fx}
var FXm=(function(){
 var FQ=1,fgap=60,fslow=0,cv=null,gl=null,run=false,mx=.5,my=.5,T=0,last=0,forced=null,calm=matchMedia('(prefers-reduced-motion:reduce)').matches;
 var MODES=['iris','pellicule','rayons','brume','cubique','vhs','casse','_','soleil','aurore','pluie','neon','braise','eau'];
 function FSG(code){return ['#ifdef GL_FRAGMENT_PRECISION_HIGH\nprecision highp float;\n#else\nprecision mediump float;\n#endif',
 'uniform vec2 res,mp;uniform float t,tg,gr,sh,vg,md;',
 'float h(vec2 p){return fract(sin(dot(p,vec2(12.9898,78.233)))*43758.5453);}',
 'float vn(vec2 p){vec2 i=floor(p),f=fract(p);f=f*f*(3.-2.*f);return mix(mix(h(i),h(i+vec2(1.,0.)),f.x),mix(h(i+vec2(0.,1.)),h(i+vec2(1.,1.)),f.x),f.y);}',
 'float fbm(vec2 p){float a=.5,s=0.;for(int i=0;i<4;i++){s+=a*vn(p);p=p*2.03+vec2(7.1,3.7);a*=.5;}return s;}',
 'vec4 over(vec4 a,vec4 b){return a+b*(1.-a.a);}',
 'void main(){vec2 uv=gl_FragCoord.xy/res;float asp=res.x/res.y;vec2 p=vec2(uv.x*asp,uv.y);',
 ' float n=h(gl_FragCoord.xy+floor(tg*24.)*7.31)-.5;',
 ' float v=smoothstep(.3,1.,length((uv-.5)*vec2(1.,.9)));',
 ' vec4 c=vec4(0.,0.,0.,v*vg*.6);',
 ' if(md<.5){',
 '  vec2 q=p*1.15+(mp-.5)*.5;vec2 w=vec2(fbm(q+vec2(t*.11,t*.07)),fbm(q+vec2(5.2-t*.09,1.3+t*.06)));',
 '  float a=fbm(q*.8+w*1.7+t*.05)*2.4+t*.03;vec3 ir=.5+.5*cos(6.2832*(a+vec3(0.,.33,.67)));',
 '  float band=smoothstep(.28,.78,fbm(q*1.3-w+vec2(t*.08,-t*.06)));float as=band*sh*.3;c=over(vec4(ir*as,as),c);',
 ' }else if(md<1.5){',
 '  float l1=fbm(p*.9+vec2(t*.09,t*.02));float l2=fbm(p*.7-vec2(t*.03,t*.07)+4.);',
 '  vec3 lk=mix(vec3(1.,.5,.18),vec3(1.,.22,.4),l2);float la=smoothstep(.5,.9,l1)*sh*.4*(.4+.6*(1.-uv.x));',
 '  c=over(vec4(lk*la,la),c);float dust=step(.9985,h(floor(gl_FragCoord.xy/2.)+floor(tg*12.)));c=over(vec4(vec3(dust)*.7*gr,dust*.5*gr),c);',
 ' }else if(md<2.5){',
 '  vec2 sn=vec2(.12+.05*sin(t*.07),1.08);vec2 d=(uv-sn)*vec2(asp,1.);float an=atan(d.y,d.x),ln=length(d);',
 '  float ry=fbm(vec2(an*7.+t*.12,ln*1.5-t*.05));float s2=pow(ry,2.2)*smoothstep(1.6,.1,ln);',
 '  float glow=exp(-ln*2.2);float a=clamp((s2*1.6+glow*.5)*sh*.5,0.,.85);c=over(vec4(vec3(1.,.82,.5)*a,a),c);',
 ' }else if(md<3.5){',
 '  float f=fbm(p*1.1+vec2(t*.07,t*.03));float f2=fbm(p*2.4-vec2(t*.05,0.)+3.);float f3=fbm(p*.6+vec2(0.,t*.02)+9.);',
 '  float a=smoothstep(.38,.85,f*.6+f2*.35+f3*.3)*sh*.38*(.5+.5*(1.-uv.y));c=over(vec4(vec3(.82,.9,1.)*a,a),c);',
 ' }else if(md<4.5){',
 '  float cs=res.y/34.;vec2 cell=floor(gl_FragCoord.xy/cs);',
 '  float cl=fbm(floor(p*13.)/13.+vec2(t*.05,0.));float ca=smoothstep(.55,.62,cl)*sh*.3;c=over(vec4(vec3(ca),ca),c);',
 '  float la=(h(cell)-.5)*gr*.16;c=over(la>0.?vec4(vec3(la),la):vec4(0.,0.,0.,-la),c);',
 '  vec3 sky=mix(vec3(.4,.65,1.),vec3(1.,.8,.55),.5+.5*sin(t*.03));float sa=sh*.08*uv.y;c=over(vec4(sky*sa,sa),c);',
 ' }else if(md<5.5){',
 '  float sl=.5+.5*sin(gl_FragCoord.y*2.0944);c=over(vec4(0.,0.,0.,sl*sh*.22),c);',
 '  float rb=exp(-pow((uv.y-fract(t*.1))*14.,2.))*.14*sh;c=over(vec4(vec3(.9,.9,1.)*rb,rb),c);',
 '  float jl=step(.985,h(vec2(floor(uv.y*90.),floor(tg*8.))))*.35*sh;c=over(vec4(vec3(.2,.9,1.)*jl,jl),c);',
 ' }else if(md>6.5&&md<7.5){',code,
 ' }else if(md>7.5&&md<8.5){',
 '  vec2 sp=vec2(.92+.03*sin(t*.05),1.06);vec2 sq=sp*vec2(asp,1.);vec2 d=p-sq;float ln=length(d),an=atan(d.y,d.x);',
 '  float core=exp(-ln*3.4),halo=exp(-ln*1.15);float ry=pow(fbm(vec2(an*9.+t*.08,ln*1.3-t*.03)),2.)*smoothstep(1.9,.05,ln);',
 '  float a=clamp((core*1.4+halo*.4+ry*.75)*sh*.6,0.,.92);vec3 wm=mix(vec3(1.,.7,.32),vec3(1.,.95,.74),core);c=over(vec4(wm*a,a),c);',
 '  vec2 ax=vec2(.5*asp,.5)-sq;float gh=0.;for(int i=1;i<5;i++){float fi=float(i);vec2 gp=sq+ax*(fi*.5);float r=length(p-gp);gh+=exp(-pow((r-.05*fi)*30.,2.))*.14/fi+exp(-r*r*(60./fi))*.05;}',
 '  c=over(vec4(vec3(1.,.82,.5)*gh*sh,gh*sh*.8),c);',
 '  float hz=smoothstep(.1,1.,uv.x*.6+uv.y*.7)*sh*.14;c=over(vec4(vec3(1.,.78,.45)*hz,hz),c);',
 ' }else if(md>8.5&&md<9.5){',
 '  float w=fbm(vec2(uv.x*asp*1.4+t*.05,t*.04));float ry=fbm(vec2(uv.x*asp*7.,t*.12))*.8+.2;',
 '  float y1=.66+.2*w+.05*sin(uv.x*asp*4.+t*.3);float r1=exp(-pow((uv.y-y1)*5.5,2.));',
 '  float y2=.5+.16*fbm(vec2(uv.x*asp*1.1-t*.04,3.))+.04*sin(uv.x*asp*3.-t*.25);float r2=exp(-pow((uv.y-y2)*7.,2.));',
 '  vec3 g1=mix(vec3(.1,1.,.6),vec3(.55,.3,1.),smoothstep(.4,.95,uv.y+w*.3));float a1=r1*ry*sh*.55,a2=r2*(1.-ry*.4)*sh*.4;',
 '  c=over(vec4(g1*a1,a1),c);c=over(vec4(vec3(.3,.6,1.)*a2,a2),c);',
 '  float st=step(.9975,h(floor(gl_FragCoord.xy/2.)))*smoothstep(.45,.9,uv.y)*(.5+.5*sin(t*2.+h(floor(gl_FragCoord.xy/2.))*30.));c=over(vec4(vec3(st*.8),st*.7),c);',
 ' }else if(md>9.5&&md<10.5){',
 '  c=over(vec4(vec3(.02,.05,.1)*.18*sh,.18*sh),c);',
 '  float col=floor(uv.x*asp*70.);float r=h(vec2(col,1.));float yy=fract(uv.y*(.5+r*.8)+t*(.55+r*.9)+r*7.);float xx=abs(fract(uv.x*asp*70.)-.5);',
 '  float st=smoothstep(0.,.02,yy)*smoothstep(.16,.02,yy)*step(.8,h(vec2(col,2.)))*smoothstep(.2,0.,xx)*.55*sh;c=over(vec4(vec3(.72,.86,1.)*st,st),c);',
 '  vec2 gd=p*14.;vec2 gi=floor(gd),gf=fract(gd)-.5;vec2 jo=(vec2(h(gi+3.),h(gi+7.))-.5)*.4;float dp=step(.84,h(gi))*smoothstep(.2,.08,length(gf-jo));',
 '  float hl=smoothstep(.09,0.,length(gf-jo-vec2(-.05,.07)))*step(.84,h(gi));float dl=exp(-pow((fract(t*.07+h(gi)*5.)-.5)*3.,2.));',
 '  c=over(vec4(vec3(.55,.75,1.)*dp*.16*sh,dp*.16*sh),c);c=over(vec4(vec3(1.)*hl*.7*sh,hl*.6*sh),c);',
 ' }else if(md>10.5&&md<11.5){',
 '  float pu=.72+.28*sin(t*.9);float e1=exp(-uv.x*4.5),e2=exp(-(1.-uv.x)*4.5),e3=exp(-(1.-uv.y)*5.);',
 '  float a1=e1*pu*sh*.65,a2=e2*(1.72-pu)*sh*.55,a3=e3*sh*.3;',
 '  c=over(vec4(vec3(1.,.12,.6)*a1,a1),c);c=over(vec4(vec3(.1,.85,1.)*a2,a2),c);c=over(vec4(vec3(.55,.2,1.)*a3,a3),c);',
 '  float bar=exp(-pow((uv.y-fract(t*.07))*16.,2.))*.14*sh;c=over(vec4(vec3(.8,.4,1.)*bar,bar),c);',
 '  float sl=.5+.5*sin(gl_FragCoord.y*3.1416);c=over(vec4(0.,0.,0.,sl*.07*sh),c);',
 ' }else if(md>11.5&&md<12.5){',
 '  float gl=exp(-uv.y*3.2)*sh*.42;c=over(vec4(vec3(1.,.32,.06)*gl,gl),c);',
 '  for(int i=0;i<3;i++){float fi=float(i);vec2 q=p*vec2(9.+fi*7.,9.+fi*7.);q.y-=t*(.55+fi*.35);vec2 id=floor(q),f=fract(q)-.5;float r=h(id+fi*13.);',
 '   vec2 of=vec2(sin(t*.8+r*6.28)*.25,(r-.5)*.5);float d=length(f-of);float spk=step(.74,r)*smoothstep(.1,0.,d)*(.55+.45*sin(t*3.+r*20.))*sh;',
 '   c=over(vec4(vec3(1.,.55,.15)*spk,spk*.9),c);}',
 ' }else if(md>12.5){',
 '  vec2 q=p*3.2;for(int i=0;i<3;i++){float fi=float(i);q+=vec2(sin(q.y*1.3+t*.4+fi),cos(q.x*1.1-t*.35+fi*2.))*.45;}',
 '  float ca=abs(sin(q.x*2.)+sin(q.y*2.))*.5;ca=pow(1.-ca,6.);float a=ca*sh*.4*(.35+.65*uv.y);c=over(vec4(vec3(.65,.95,1.)*a,a),c);',
 '  c=over(vec4(vec3(0.,.25,.3)*.14*sh,.14*sh),c);',
 ' }else{',
 '  float row=floor(uv.y*28.);float g=step(.9,h(vec2(row,floor(tg*7.))));float off=h(vec2(row,floor(tg*7.)+1.));',
 '  vec3 gc=off>.5?vec3(1.,.05,.15):vec3(0.,.9,1.);float ga=g*.45;c=over(vec4(gc*ga,ga),c);',
 '  float dk=.5+.25*h(vec2(floor(tg*10.),1.));c=over(vec4(0.,0.,0.,dk),c);',
 '  float pl=.5+.5*sin(t*1.8);c=over(vec4(vec3(.55,0.,.03)*v*(.5+.5*pl),v*(.6+.3*pl)),c);',
 '  float rb=step(.97,fract(uv.y*3.+tg*.7))*.2;c=over(vec4(vec3(.8,0.,.1)*rb,rb),c);',
 ' }',
 ' float ag=abs(n)*gr*(md>5.5?.75:.55);c=over(n>0.?vec4(ag):vec4(0.,0.,0.,ag),c);gl_FragColor=c;}'].join('\n')}
 var progs={},lastErr='',VS0='attribute vec2 p;void main(){gl_Position=vec4(p,0.,1.);}',buf=null;
 function mkProg(code){if(progs[code]!==undefined)return progs[code];
  function sh(ty,s){var o=gl.createShader(ty);gl.shaderSource(o,s);gl.compileShader(o);return o}
  var fs=sh(gl.FRAGMENT_SHADER,FSG(code).join?FSG(code):FSG(code));
  if(!gl.getShaderParameter(fs,gl.COMPILE_STATUS)){lastErr=String(gl.getShaderInfoLog(fs)||'erreur').slice(0,220);progs[code]=null;return null}
  var pg=gl.createProgram();gl.attachShader(pg,sh(gl.VERTEX_SHADER,VS0));gl.attachShader(pg,fs);gl.linkProgram(pg);
  if(!gl.getProgramParameter(pg,gl.LINK_STATUS)){lastErr=String(gl.getProgramInfoLog(pg)||'erreur').slice(0,220);progs[code]=null;return null}
  var P={pg:pg,a:gl.getAttribLocation(pg,'p'),U:{}};['res','mp','t','tg','gr','sh','vg','md'].forEach(function(k){P.U[k]=gl.getUniformLocation(pg,k)});progs[code]=P;return P}
 function use(P){gl.useProgram(P.pg);gl.bindBuffer(gl.ARRAY_BUFFER,buf);gl.enableVertexAttribArray(P.a);gl.vertexAttribPointer(P.a,2,gl.FLOAT,false,0,0)}
 function init(){
  if(cv)return true;
  var c=document.createElement('canvas');c.id='fxl';c.setAttribute('aria-hidden','true');
  try{gl=c.getContext('webgl',{alpha:true,premultipliedAlpha:true,antialias:false,powerPreference:'low-power'})}catch(e){}
  if(!gl)return false;
  buf=gl.createBuffer();gl.bindBuffer(gl.ARRAY_BUFFER,buf);gl.bufferData(gl.ARRAY_BUFFER,new Float32Array([-1,-1,3,-1,-1,3]),gl.STATIC_DRAW);
  if(!mkProg('')){gl=null;return false}
  cv=c;document.body.append(cv);
  addEventListener('pointermove',function(e){mx=e.clientX/innerWidth;my=1-e.clientY/innerHeight},{passive:true});
  addEventListener('resize',size);size();return true}
 function test(code){if(!init())return 'WebGL indisponible sur cet appareil.';delete progs[code];return mkProg(code)?'':lastErr}
 function size(){if(!cv)return;var k=(matchMedia('(pointer:coarse)').matches?.62:.55)*FQ;cv.width=Math.max(2,Math.round(innerWidth*k));cv.height=Math.max(2,Math.round(innerHeight*k));gl.viewport(0,0,cv.width,cv.height)}
 function frame(now){
  if(!run)return;requestAnimationFrame(frame);
  if(document.hidden||window.FRZ||now-last<(matchMedia('(pointer:coarse)').matches?58:42))return;if(last&&now-last<400){fgap=fgap*.9+(now-last)*.1;if(fgap>(matchMedia('(pointer:coarse)').matches?95:64)&&FQ>.45){if(++fslow>10){FQ=Math.max(.45,FQ-.1);fslow=0;fgap=60;size()}}else fslow=0}var dt=last?Math.min(.2,(now-last)/1000):0;last=now;
  var f=fxEff(),spd=f.spd==null?1:f.spd;T+=dt*spd;var op=forced?Math.max(.8,f.amt):f.amt;if(cv.style.opacity!==String(op))cv.style.opacity=op;
  var m=forced||f.mode,code='',mi=0;
  if(m&&String(m).indexOf('c:')===0){var cs=(f.custom||[]).filter(function(x){return 'c:'+x.id===m})[0];code=cs&&cs.code?cs.code:'';mi=code?7:0}else{mi=MODES.indexOf(m);if(mi<0)mi=0}
  var P=code?mkProg(code):null;if(!P){P=mkProg('');if(mi===7)mi=0}
  use(P);var U=P.U;
  gl.uniform2f(U.res,cv.width,cv.height);gl.uniform2f(U.mp,mx,my);gl.uniform1f(U.t,calm?3:T);gl.uniform1f(U.tg,calm?3:now/1000);
  gl.uniform1f(U.gr,f.grain);gl.uniform1f(U.sh,f.sheen);gl.uniform1f(U.vg,f.vig);gl.uniform1f(U.md,mi);
  gl.drawArrays(gl.TRIANGLES,0,3)}
 function apply(){
  var fe=fxEff();document.documentElement.setAttribute('data-fx',(fe.on||forced)?String(forced||fe.mode):'');if((fe.on||forced)&&init()){cv.style.display='';cv.style.opacity=forced?Math.max(.8,fe.amt):fe.amt;if(!run){run=true;last=0;requestAnimationFrame(frame)}}
  else{run=false;if(cv)cv.style.display='none'}}
 return {apply:apply,test:test,force:function(m){forced=m;apply()}}
})();

/* ================= sons synthétisés (aucun fichier) ================= */
var SND=(function(){
 var PN=null,PT=0,BUF={},BLD={},AF={},ctx=null,mst=null,vb=null,wetG=null,ambN=null,lastH=0,BR=false,DEMO=false,sig='',rt=null;
 var TH={cristal:{w:'sine',sc:[0,2,4,7,9],b:659.25,d:1.1,bell:1},boise:{w:'triangle',sc:[0,3,5,7,10],b:261.63,d:.32},bulle:{w:'sine',sc:[0,2,5,7,9],b:392,d:.2,gl:1},retro:{w:'square',sc:[0,4,7,12],b:329.63,d:.16,lp:1800},
  orgue:{w:'sawtooth',sc:[0,3,7,10],b:196,d:.55,lp:900},sombre:{w:'triangle',sc:[0,1,5,7],b:110,d:.9,lp:700}};
 function th(){return TH[DK()?'sombre':S.snd.th]||TH.cristal}
 function oc(){var w=window.BRKW||1;try{return ((typeof curDisc==='function'&&curDisc().mys)?.5:1)*w}catch(e){return w}}
 function DK(){return BR||oc()<1}
 function ok(){return SNDON&&S.snd.show!==false&&!document.documentElement.classList.contains('locked')}
 function wv(){var r=S.snd.rev;return Math.max(0,Math.min(1,r==null?.4:r))*.9}
 function pit(){return (S.snd.pitch||0)-(BR?5:0)}
 function init(){
  if(ctx)return true;var AC=window.AudioContext||window.webkitAudioContext;if(!AC)return false;
  try{ctx=new AC()}catch(e){return false}
  mst=ctx.createGain();mst.gain.value=S.snd.vol;var cp=ctx.createDynamicsCompressor();mst.connect(cp);cp.connect(ctx.destination);
  vb=ctx.createDelay(1);vb.delayTime.value=.17;var fb=ctx.createGain();fb.gain.value=.34;var lp=ctx.createBiquadFilter();
  lp.type='lowpass';lp.frequency.value=2600;wetG=ctx.createGain();wetG.gain.value=wv();
  vb.connect(lp);lp.connect(fb);fb.connect(vb);lp.connect(wetG);wetG.connect(mst);return true}
 function fr(i){var T=th(),n=T.sc.length;return T.b*Math.pow(2,((T.sc[((i%n)+n)%n]+12*Math.floor(i/n))+pit())/12)}
 function tone(f,o){o=o||{};if(!o.nb){var K=oc();f*=K;if(o.from)o.from*=K}var T=th(),t=ctx.currentTime+(o.at||0),d=(o.d||T.d)*(S.snd.len||1),v=o.v==null?.5:o.v,os=ctx.createOscillator(),g=ctx.createGain();
  os.type=T.w;os.frequency.setValueAtTime(o.from||(T.gl?f*.7:f),t);if(o.from||T.gl)os.frequency.exponentialRampToValueAtTime(f,t+d*.5);
  g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(v,t+.006);g.gain.exponentialRampToValueAtTime(.0008,t+d);
  if(T.lp){var lp=ctx.createBiquadFilter();lp.type='lowpass';lp.frequency.value=T.lp;os.connect(lp);lp.connect(g)}else os.connect(g);
  g.connect(mst);var s=ctx.createGain();s.gain.value=.5;g.connect(s);s.connect(vb);os.start(t);os.stop(t+d+.05);
  if(T.bell&&!o.nb)tone(f*2.76,{at:o.at,d:d*.45,v:v*.28,nb:1})}
 function noiseBuf(sec){var len=Math.floor(ctx.sampleRate*sec),bf=ctx.createBuffer(1,len,ctx.sampleRate),a=bf.getChannelData(0);for(var i=0;i<len;i++)a[i]=Math.random()*2-1;return bf}
 function whoosh(){var t=ctx.currentTime,s=ctx.createBufferSource();s.buffer=noiseBuf(.5);var f=ctx.createBiquadFilter();f.type='bandpass';f.Q.value=3;f.frequency.setValueAtTime(300*oc(),t);f.frequency.exponentialRampToValueAtTime(3200*oc(),t+.28);
  var g=ctx.createGain();g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(.3,t+.12);g.gain.exponentialRampToValueAtTime(.001,t+.45);s.connect(f);f.connect(g);g.connect(mst);s.start(t)}
 function b2ab(u){var m=/^data:[^,]*;base64,(.*)$/i.exec(u||'');if(m){var s=atob(m[1]),n=s.length,a=new Uint8Array(n);for(var i=0;i<n;i++)a[i]=s.charCodeAt(i);return Promise.resolve(a.buffer)}return fetch(LOCAL[u]||u).then(function(r){return r.arrayBuffer()})}
 function decode(ab){return new Promise(function(res,rej){if(!init()){rej(new Error('audio'));return}var p=ctx.decodeAudioData(ab,res,rej);if(p&&p.catch)p.catch(rej)})}
 function loadBuf(u){if(BUF[u])return Promise.resolve(BUF[u]);if(BLD[u])return BLD[u];BLD[u]=b2ab(u).then(decode).then(function(b){BUF[u]=b;return b}).catch(function(){delete BLD[u];return null});return BLD[u]}
 function preload(){if(!ctx)return;var f=S.snd.files||{};for(var k in f)if(f[k]&&audOK(f[k]))loadBuf(f[k]);if(S.snd.pf&&audOK(S.snd.pf))loadBuf(S.snd.pf)}
 function playBuf(b,vol,out,sec){var s=ctx.createBufferSource(),g=ctx.createGain();s.buffer=b;s.playbackRate.value=oc();g.gain.value=vol;s.connect(g);g.connect(out||mst);s.start();if(sec)setTimeout(function(){try{s.stop()}catch(e){}},sec*1000);return s}
 function stopPf(){PT++;var n=PN;PN=null;if(!n)return;try{n.g.gain.setTargetAtTime(0,ctx.currentTime,.25)}catch(e){}setTimeout(function(){try{n.s.stop()}catch(e){}},1500)}
 function pfAud(on){var u=S.snd.pf;
  if(on&&u&&audOK(u)&&init()){if(ctx.state==='suspended')ctx.resume();var v=Math.max(0,Math.min(1,S.snd.pfv==null?.5:S.snd.pfv));
   if(PN&&PN.u===u){PN.g.gain.setTargetAtTime(v,ctx.currentTime,.2);return}
   if(PN)stopPf();var tk=++PT;
   loadBuf(u).then(function(b){if(!b||tk!==PT||PN||S.snd.pf!==u||!ok())return;var s=ctx.createBufferSource(),g=ctx.createGain();s.buffer=b;s.loop=true;s.playbackRate.value=oc();g.gain.value=0;s.connect(g);g.connect(ctx.destination);s.start();g.gain.setTargetAtTime(Math.max(0,Math.min(1,S.snd.pfv==null?.5:S.snd.pfv)),ctx.currentTime,.6);PN={s:s,g:g,u:u}})}
  else{PT++;if(PN)stopPf()}}
 function play(k,n){
  var fu=S.snd.files&&S.snd.files[k];
  if(fu&&audOK(fu)){if(!ok()||!init())return;if(ctx.state==='suspended')ctx.resume();if(k==='hover'){var nw=performance.now();if(!S.snd.hov||nw-lastH<110)return;lastH=nw}
   try{mst.gain.value=S.snd.vol;var fb=BUF[fu];if(fb)playBuf(fb,1);else loadBuf(fu)}catch(e){}return}
  if(!ok()||!init())return;if(ctx.state==='suspended')ctx.resume();mst.gain.value=S.snd.vol;
  try{
  if(k==='click')tone(fr(2),{d:th().d*.7,v:.45});
  else if(k==='hover'){var now=performance.now();if(!S.snd.hov||now-lastH<110)return;lastH=now;tone(fr(Math.floor(Math.random()*5)+5),{d:th().d*.5,v:.12})}
  else if(k==='switch'){whoosh();tone(fr(4),{at:.08,v:.4});tone(fr(7),{at:.17,v:.35})}
  else if(k==='tap')tone(fr(n||0),{v:.5});
  else if(k==='focus')tone(fr(4),{d:th().d*.6,v:.2});
  else if(k==='key'){var nk=performance.now();if(nk-lastH<55)return;lastH=nk;tone(fr(Math.floor(Math.random()*4)+8),{d:th().d*.3,v:.07})}
  else if(k==='egg'){[0,2,4,7,9,12,14].forEach(function(x,i){tone(fr(x),{at:i*.085,v:.4,d:th().d*1.3})})}
  else if(k==='break'){whoosh();[0,-3,-7,-12,-17].forEach(function(x,i){var f=110*Math.pow(2,x/12);tone(f,{at:i*.07,v:.5,d:.45,from:f*1.6})})}
  else if(k==='ok'){tone(fr(4),{v:.4});tone(fr(9),{at:.1,v:.4});tone(fr(11),{at:.2,v:.35})}
  else if(k==='err')tone(fr(0)/2,{v:.4,d:.25})}catch(e){}}
 function lvl(){var p=S.snd.pv;return Math.max(0,Math.min(.4,p==null?.07:p))*(DK()?1.3:1)}
 function psig(){var s=S.snd;return [DK()?'sombre':s.pk,s.pn,s.pb,s.pm,oc()].join('|')}
 function stopPad(){var n=ambN;ambN=null;if(!n)return;if(n.tm)clearTimeout(n.tm);n.g.gain.cancelScheduledValues(ctx.currentTime);n.g.gain.setTargetAtTime(0,ctx.currentTime,.25);setTimeout(function(){n.os.forEach(function(o){try{o.stop()}catch(e){}})},1500)}
 function startPad(){
  var s=S.snd,k=DK()?'sombre':(s.pk||'nappe'),root=110*oc()*Math.pow(2,((s.pn||0)-(k==='sombre'?12:0))/12),br=s.pb==null?.5:s.pb,mv=s.pm==null?.5:s.pm;
  var g=ctx.createGain();g.gain.value=0;var os=[],lp=ctx.createBiquadFilter();lp.type='lowpass';lp.frequency.value=(k==='sombre'?250:500)+br*(k==='sombre'?900:4000);g.connect(lp);lp.connect(mst);
  var node={g:g,os:os,lg:null,tm:null};
  if(k==='nappe'||k==='sombre'){(k==='nappe'?[0,7,12,16]:DK()?[0,1,6,13]:[0,7,10,19]).forEach(function(st,i){var o=ctx.createOscillator();o.type=k==='nappe'?'sine':'triangle';o.frequency.value=root*Math.pow(2,st/12);o.detune.value=(i-1.5)*(k==='sombre'?24:6);o.connect(g);o.start();os.push(o)})}
  else if(k==='vent'){var bs=ctx.createBufferSource();bs.buffer=noiseBuf(3);bs.loop=true;var bp=ctx.createBiquadFilter();bp.type='bandpass';bp.Q.value=1.4;bp.frequency.value=(250+br*1800)*oc();
   var lf=ctx.createOscillator(),lgg=ctx.createGain();lf.frequency.value=.05+mv*.4;lgg.gain.value=(150+br*600)*oc();lf.connect(lgg);lgg.connect(bp.frequency);bs.connect(bp);bp.connect(g);bs.start();lf.start();os.push(bs,lf)}
  else if(k==='cloches'){var step=function(){if(ambN!==node)return;try{tone(fr(Math.floor(Math.random()*8)),{d:2.4,v:Math.min(1,lvl()*5)})}catch(e){}node.tm=setTimeout(step,1800+Math.random()*(6000-mv*4500))};node.tm=setTimeout(step,600)}
  var lfo=ctx.createOscillator(),lg=ctx.createGain();lfo.frequency.value=.03+mv*.35;lg.gain.value=lvl()*.35;lfo.connect(lg);lg.connect(g.gain);lfo.start();os.push(lfo);node.lg=lg;
  g.gain.setTargetAtTime(lvl(),ctx.currentTime,1.2);ambN=node;sig=psig()}
 function amb(){
  var hp=!!(S.snd.pf&&audOK(S.snd.pf));pfAud(ok()&&S.snd.amb&&hp&&!BR&&!window.PGON);var want=!window.PGON&&(DEMO||(ok()&&(DK()||(S.snd.amb&&!hp))));
  if(want&&init()){if(ctx.state==='suspended')ctx.resume();
   if(!ambN)startPad();else if(sig!==psig()){stopPad();startPad()}else{ambN.g.gain.setTargetAtTime(lvl(),ctx.currentTime,.3);ambN.lg.gain.value=lvl()*.35}}
  else if(ambN)stopPad()}
 function ui(){var b=$('sb');if(b){b.hidden=S.snd.show===false;b.setAttribute('aria-pressed',SNDON?'true':'false');b.classList.toggle('off',!SNDON)}
  if(mst)mst.gain.value=S.snd.vol;if(wetG)wetG.gain.value=wv();
  if(ctx)preload();if(ambN||PN||(S.snd.amb&&ok()&&(ctx||S.snd.pf))){clearTimeout(rt);rt=setTimeout(amb,250)}}
 function toggle(){SNDON=!SNDON;try{localStorage.setItem('yuu-snd',SNDON?'1':'0')}catch(e){}ui();if(SNDON){if(ctx&&ctx.state==='suspended')ctx.resume();play('ok')}amb();if(!SNDON&&ctx){setTimeout(function(){try{if(!SNDON&&ctx.state==='running')ctx.suspend()}catch(e){}},900)}}
 var hbT=null,rsT=null;
 function thump(){if(!ctx||!ok()||window.PGON)return;try{tone(48,{v:.95,d:.45,from:95,nb:1});tone(44,{at:.22,v:.8,d:.45,from:80,nb:1})}catch(e){}}
 function rasp(){if(!ctx||!ok()||window.PGON)return;try{var t=ctx.currentTime,s=ctx.createBufferSource();s.buffer=noiseBuf(1.6);var f=ctx.createBiquadFilter();f.type='bandpass';f.Q.value=8;var K=oc();f.frequency.setValueAtTime((900+Math.random()*1800)*K,t);f.frequency.exponentialRampToValueAtTime((200+Math.random()*300)*K,t+1.4);var g=ctx.createGain();g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(.35,t+.5);g.gain.exponentialRampToValueAtTime(.001,t+1.5);s.connect(f);f.connect(g);g.connect(mst);s.start(t)}catch(e){}}
 function doom(){if(!ok()||!init())return;if(ctx.state==='suspended')ctx.resume();
  try{var t=ctx.currentTime;
   [41,43.3,82].forEach(function(f,i){var o=ctx.createOscillator(),g=ctx.createGain(),lp=ctx.createBiquadFilter();o.type=i<2?'sawtooth':'square';o.frequency.setValueAtTime(f,t);o.frequency.linearRampToValueAtTime(f*.7,t+6.4);lp.type='lowpass';lp.frequency.value=170;
    g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(.5,t+4.4);g.gain.linearRampToValueAtTime(.85,t+5);g.gain.exponentialRampToValueAtTime(.001,t+6.6);o.connect(lp);lp.connect(g);g.connect(mst);o.start(t);o.stop(t+6.8)});
   var s=ctx.createBufferSource();s.buffer=noiseBuf(6.6);var bp=ctx.createBiquadFilter();bp.type='bandpass';bp.Q.value=.7;bp.frequency.setValueAtTime(120,t);bp.frequency.exponentialRampToValueAtTime(2500,t+5);
   var g2=ctx.createGain();g2.gain.setValueAtTime(0,t);g2.gain.linearRampToValueAtTime(.45,t+4.9);g2.gain.exponentialRampToValueAtTime(.001,t+6);s.connect(bp);bp.connect(g2);g2.connect(mst);s.start(t);
   var b=ctx.createOscillator(),bg=ctx.createGain();b.type='sine';b.frequency.setValueAtTime(70,t+4.95);b.frequency.exponentialRampToValueAtTime(26,t+6.2);bg.gain.setValueAtTime(0,t+4.9);bg.gain.linearRampToValueAtTime(1.2,t+4.97);bg.gain.exponentialRampToValueAtTime(.001,t+6.4);b.connect(bg);bg.connect(mst);b.start(t+4.9);b.stop(t+6.6);
   menace(true,true)}catch(e){}}
 function menace(on,fast){clearInterval(hbT);clearTimeout(rsT);if(!on)return;hbT=setInterval(thump,fast?430:1150);(function nx(){rsT=setTimeout(function(){rasp();nx()},2500+Math.random()*4500)})()}
 var MY=false;
 function sync(){var m=oc()<1;if(m!==MY){MY=m;menace(m||BR)}try{if(PN)PN.s.playbackRate.value=oc()}catch(e){}try{if(window.AUD){AUD.playbackRate=oc();AUD.preservesPitch=false;AUD.mozPreservesPitch=false;AUD.webkitPreservesPitch=false}}catch(e){}amb()}
 function chip(f,o){o=o||{};var t=ctx.currentTime+(o.at||0),d=o.d||.08,v=o.v==null?.2:o.v,os=ctx.createOscillator(),g=ctx.createGain(),lp=ctx.createBiquadFilter(),K=window.PGON?(window.PGDK?.5:1):oc();os.type=o.w||'square';os.frequency.setValueAtTime(f*K,t);if(o.to)os.frequency.exponentialRampToValueAtTime(o.to*K,t+d);g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(v,t+.004);g.gain.exponentialRampToValueAtTime(.0008,t+d);lp.type='lowpass';lp.frequency.value=o.lp||5200;os.connect(lp);lp.connect(g);g.connect(mst);os.start(t);os.stop(t+d+.05)}
 function game(k,n){if(!SNDON||S.snd.show===false||!init())return;if(ctx.state==='suspended')ctx.resume();mst.gain.value=S.snd.vol;var PEN=[0,3,5,7,10],nt=function(i){return 220*Math.pow(2,(PEN[i%5]+12*Math.floor(i/5))/12)},st=function(x){return Math.pow(2,x/12)};
  try{if(k==='hit'){var i=Math.min(n||0,14);chip(nt(i+5),{d:.09,v:.2});chip(nt(i+5)*2,{d:.05,v:.06,w:'triangle'})}
  else if(k==='ai')chip(nt(Math.min(n||0,14)+2),{d:.08,v:.15,w:'triangle'});
  else if(k==='wall')chip(330,{d:.035,v:.08});
  else if(k==='goal')[523.25,659.25,783.99,1046.5].forEach(function(f,i){chip(f,{at:i*.07,d:.12,v:.17})});
  else if(k==='lose'){chip(392,{to:98,d:.55,v:.2,w:'sawtooth',lp:1800});chip(196,{at:.05,to:55,d:.6,v:.15,lp:900})}
  else if(k==='coin'){chip(987.77,{d:.08,v:.15});chip(1318.5,{at:.08,d:.35,v:.15})}
  else if(k==='lvl')[0,4,7,12,16].forEach(function(x,i){chip(392*st(x),{at:i*.05,d:.1,v:.14})});
  else if(k==='win'){[0,4,7,12,7,12,16,19,24].forEach(function(x,i){chip(392*st(x),{at:i*.09,d:.16,v:.16})});chip(98,{at:.8,d:.9,v:.2,w:'triangle'})}
  else if(k==='over')[7,5,3,0,-5].forEach(function(x,i){chip(220*st(x),{at:i*.16,d:.26,v:.17,lp:2200})});
  else if(k==='sel')chip(880,{d:.03,v:.09});
  else if(k==='rare'){[0,7,12,19].forEach(function(x,i){chip(523.25*st(x),{at:i*.07,d:.3,v:.13,w:'triangle'})});chip(1046.5,{at:.32,d:.6,v:.08,w:'sine'})}
  else if(k==='gold'){[0,4,7,12,16,19,24,28,31].forEach(function(x,i){chip(523.25*st(x),{at:i*.06,d:.22,v:.13})});[0,4,7].forEach(function(x){chip(261.63*st(x),{at:.6,d:1.1,v:.1,w:'triangle'})});for(var j=0;j<6;j++)chip(2093*st(j*2),{at:.7+j*.08,d:.12,v:.05,w:'sine'})}
  else if(k==='glitch'){for(var q=0;q<3;q++)chip(150+Math.random()*2200,{at:q*.03,d:.03,v:.07})}
  else if(k==='ok'){chip(659.25,{d:.06,v:.14});chip(987.77,{at:.06,d:.12,v:.14})}}catch(e){}}
 function media(el){if(!init())return null;try{var s0=ctx.createMediaElementSource(el),g=ctx.createGain();g.gain.value=0;s0.connect(g);g.connect(mst);return g}catch(e){return null}}
 return {sync:sync,game:game,media:media,wake:function(){try{if(init()&&ctx.state==='suspended')ctx.resume()}catch(e){}},ready:function(){return !!ctx&&ctx.state==='running'},probe:function(u){if(!init())return Promise.resolve(null);if(ctx.state==='suspended')ctx.resume();return loadBuf(u)},decode:function(ab){return decode(ab)},preview:function(u,v,sec){if(!init())return;if(ctx.state==='suspended')ctx.resume();loadBuf(u).then(function(b){if(b)playBuf(b,v==null?.5:v,ctx.destination,sec||8)})},play:play,doom:doom,toggle:toggle,ui:ui,amb:amb,broke:function(on){BR=on;amb();ui();menace(on||oc()<1)},demo:function(){DEMO=true;amb();setTimeout(function(){DEMO=false;amb()},7000)}}
})();
(function(){
 var lastHov=null;
 $('sb').addEventListener('click',function(){SND.toggle()});
 document.addEventListener('click',function(e){var t=e.target.closest&&e.target.closest('a,button,.card,summary,label,select,[role=button],[tabindex],input[type=checkbox],input[type=radio],video');
  if(!t&&e.target.closest){var x=e.target;for(var i=0;x&&x.nodeType===1&&i<4;i++,x=x.parentElement){try{if(getComputedStyle(x).cursor==='pointer'){t=x;break}}catch(z){}}}
  if(t&&!t.closest('#pn')&&!t.closest('.dsw')&&!t.closest('#pong')&&t.id!=='sb'&&t.id!=='ed')SND.play('click')},true);
 document.addEventListener('focusin',function(e){var t=e.target;if(t&&/^(INPUT|TEXTAREA|SELECT)$/.test(t.tagName)&&t.type!=='file'&&t.type!=='checkbox'&&!t.closest('#pn')&&!t.closest('#pong'))SND.play('focus')},true);
 document.addEventListener('input',function(e){var t=e.target;if(t&&/^(INPUT|TEXTAREA)$/.test(t.tagName)&&!t.closest('#pn')&&!t.closest('#pong'))SND.play('key')},true);
 document.addEventListener('pointerover',function(e){if(e.pointerType==='touch')return;var t=e.target.closest&&e.target.closest('.card,.btn,.chip,header a,footer a');
  if(t&&t!==lastHov&&!t.closest('#pn')){lastHov=t;SND.play('hover')}else if(!t)lastHov=null});
 function hint(on){var h=$('sh');if(h){h.hidden=!on;if(on)h.textContent=S.tx.sndHint||''}}
 var gev=['pointerdown','pointerup','touchend','click','keydown'],gh=function(){SND.amb();setTimeout(function(){if(SND.ready()){gev.forEach(function(e){removeEventListener(e,gh,true)});hint(false)}},250)};
 gev.forEach(function(e){addEventListener(e,gh,true)});
 setTimeout(function(){try{SND.amb()}catch(e){}},0);
 setTimeout(function(){hint(!!S.tx.sndHint&&!document.documentElement.classList.contains('locked')&&SNDON&&S.snd.amb&&S.snd.show!==false&&!SND.ready())},1400);
})();

/* ================= projets, contact, newsletter ================= */
function spPath(p){return !p.spx&&/^(track|album|playlist|artist|episode)\/[A-Za-z0-9]{10,30}$/.test(p.sp||'')?p.sp:''}
function audOK(u){return /^(https?:\/\/|\/|assets\/|blob:|data:audio\/)[^\s"'<>]+$/i.test(u||'')}
function tracks(p){return (p.a||[]).filter(function(x){return audOK(x.u)})}
function fmtT(s){s=Math.max(0,Math.floor(s||0));return Math.floor(s/60)+':'+('0'+s%60).slice(-2)}
function playerHTML(p){var tk=tracks(p),sp=spPath(p);
 if(tk.length)return tk.map(function(x,j){var k=esc(p.s)+':'+j;return '<div class="ap" data-k="'+k+'"><button type="button" class="apb" data-tk="'+k+'" aria-label="Lecture">▶</button><div class="apm"><b>'+esc(x.t||('Piste '+(j+1)))+'</b><input type="range" class="apr" min="0" max="1000" value="0" aria-label="Position"></div><span class="apt">0:00</span></div>'}).join('');
 return ''}
function pjr(){
 var L=S.pj.list||[];$('ecouter').hidden=!L.length;
 var sig=JSON.stringify([L,S.tx.pjGo,S.tx.pjSoon,S.tx.pjHere,S.tx.pjOn,S.tx.pjHide,Object.keys(PJOPEN).filter(function(k){return PJOPEN[k]})]);if(sig===PJSIG)return;PJSIG=sig;
 $('pj').innerHTML=L.map(function(p,i){var b='pj.list.'+i+'.',im=safeImg(p.img),ls=(p.l||[]).map(function(x,j){return{x:x,j:j}}).filter(function(o){return o.x.u&&o.x.u.trim()});
  var go=ls[0],here=tracks(p).length,open=!!(PJOPEN[p.s]&&here);
  return '<article class="pj"><div class="pc" style="'+(im?"background:url('"+im+"') center/cover":'background:'+grad(p.h||260))+'"><button type="button" class="cvb" data-cv="'+i+'" title="Changer l’image" aria-label="Changer l’image">📷</button></div><div class="pi"><h3 data-p="'+b+'n">'+esc(p.n)+'</h3><p data-ml data-p="'+b+'d">'+esc(p.d)+'</p><div class="pb">'
   +(here?'<button type="button" class="btn" data-pl="'+i+'" aria-expanded="'+open+'">'+esc(open?S.tx.pjHide:S.tx.pjHere)+'</button>':go?'<a class="btn" target="_blank" rel="noopener" href="'+esc(safeUrl(go.x.u))+'" data-p="tx.pjGo">'+esc(S.tx.pjGo)+'</a>':'<span class="btn off" data-p="tx.pjSoon">'+esc(S.tx.pjSoon)+'</span>')+'</div>'
   +(ls.length?'<div class="pb pon"><span class="pol" data-p="tx.pjOn">'+esc(S.tx.pjOn)+'</span>'+ls.map(function(o){return '<a class="chip" target="_blank" rel="noopener" href="'+esc(safeUrl(o.x.u))+'" data-p="'+b+'l.'+o.j+'.t">'+esc(o.x.t)+'</a>'}).join('')+'</div>':'')
   +'<div class="pp"'+(open?'':' hidden')+'>'+(open?playerHTML(p):'')+'</div></div></article>'}).join('');
 PJsync()}
function PJsync(){document.querySelectorAll('#pj .ap').forEach(function(r){var on=r.dataset.k===PJCUR,pl=on&&AUD&&!AUD.paused,rg=r.querySelector('.apr'),tm=r.querySelector('.apt');
 r.classList.toggle('on',on);r.querySelector('.apb').textContent=pl?'❚❚':'▶';
 if(on&&AUD&&AUD.duration){if(document.activeElement!==rg)rg.value=Math.round(AUD.currentTime/AUD.duration*1000);tm.textContent=fmtT(AUD.currentTime)+' / '+fmtT(AUD.duration)}else if(!on){rg.value=0;tm.textContent='0:00'}})}
function pjFind(s){return (S.pj.list||[]).filter(function(x){return x.s===s})[0]}
function playTk(key){var a=key.split(':'),p=pjFind(a[0]);if(!p)return;var x=tracks(p)[+a[1]];if(!x)return;
 if(!AUD){AUD=new Audio();AUD.preload='none';['timeupdate','play','pause','loadedmetadata'].forEach(function(n){AUD.addEventListener(n,PJsync)});
  AUD.addEventListener('ended',function(){var b=PJCUR.split(':'),pp=pjFind(b[0]);if(pp&&tracks(pp)[+b[1]+1])playTk(b[0]+':'+(+b[1]+1));else PJsync()});
  AUD.addEventListener('error',function(){toast('Lecture impossible (fichier introuvable ?)')})}
 if(PJCUR===key&&AUD.getAttribute('src')){if(AUD.paused){var q=AUD.play();if(q&&q.catch)q.catch(function(){})}else AUD.pause();return}
 PJCUR=key;AUD.src=x.u;try{AUD.preservesPitch=false;AUD.mozPreservesPitch=false;AUD.webkitPreservesPitch=false;AUD.playbackRate=(typeof MYSON!=='undefined'&&MYSON)?.5:1}catch(e){}var q2=AUD.play();if(q2&&q2.catch)q2.catch(function(){});PJsync()}
$('pj').addEventListener('click',function(e){
 var cv=e.target.closest&&e.target.closest('[data-cv]');if(cv){var pp=S.pj.list[+cv.dataset.cv],fi=document.createElement('input');fi.type='file';fi.accept='image/*';fi.onchange=function(){up(fi.files[0],function(u){pp.img=u;dirty();render()},{max:1200,jpg:true})};fi.click();return}
 var pl=e.target.closest&&e.target.closest('[data-pl]');if(pl){var p=S.pj.list[+pl.dataset.pl];if(p){PJOPEN[p.s]=!PJOPEN[p.s];pjr();if(window.SND)SND.play('click')}return}
 var tb=e.target.closest&&e.target.closest('[data-tk]');if(tb)playTk(tb.dataset.tk)});
$('pj').addEventListener('input',function(e){var r=e.target.closest&&e.target.closest('.apr');if(r&&AUD&&AUD.duration){var row=r.closest('.ap');if(row&&row.dataset.k===PJCUR)AUD.currentTime=AUD.duration*r.value/1000}});
var favDef='';
function defFav(){if(favDef)return favDef;try{var c=document.createElement('canvas');c.width=c.height=128;var g=c.getContext('2d'),bg=(getComputedStyle(document.documentElement).getPropertyValue('--bg')||'').trim()||'#0f0c20';
 g.fillStyle=bg;g.beginPath();if(g.roundRect)g.roundRect(0,0,128,128,28);else g.rect(0,0,128,128);g.fill();
 var d;if(g.createConicGradient){d=g.createConicGradient(.6,64,64);['#ff7ac8','#ffd36e','#7affc9','#7aa8ff','#c97aff','#ff7ac8'].forEach(function(x,i){d.addColorStop(i/5,x)})}else{d=g.createLinearGradient(10,10,118,118);d.addColorStop(0,'#ff7ac8');d.addColorStop(.5,'#7affc9');d.addColorStop(1,'#7aa8ff')}
 g.fillStyle=d;g.beginPath();g.arc(64,64,54,0,6.3);g.fill();g.fillStyle=bg;g.beginPath();g.arc(64,64,15,0,6.3);g.fill();g.strokeStyle='rgba(255,255,255,.55)';g.lineWidth=3;g.beginPath();g.arc(64,64,24,0,6.3);g.stroke();
 favDef=c.toDataURL('image/png')}catch(e){favDef=''}return favDef}
function favApply(){if(document.querySelector('link[data-static]'))return;var u=/^(data:image\/|assets\/|\/|https?:)/.test(S.fav||'')?LOCAL[S.fav]||S.fav:defFav();
 [['icon',''],['apple-touch-icon','']].forEach(function(r){var l=document.querySelector('link[rel="'+r[0]+'"]');if(!l){l=document.createElement('link');l.rel=r[0];document.head.append(l)}if(l.dataset.u!==u){l.dataset.u=u;l.removeAttribute('type');l.href=u}})}
function tabFav(B){var g=G('Logo du site et nom','L’icône qui apparaît dans l’onglet du navigateur, dans les favoris et sur l’écran d’accueil du téléphone.'),
 pv=mk('img',{src:LOCAL[S.fav]||S.fav||defFav(),alt:'',style:'width:64px;height:64px;border-radius:14px;object-fit:cover;border:1px solid var(--pl,#555)'}),f=mk('input',{type:'file',accept:'image/*'});
 f.onchange=function(){var fl=f.files[0];if(!fl)return;msg('Import du logo…');prep(fl,{max:256,png:true}).then(function(b){var r=new FileReader();r.onload=function(){S.fav=r.result;after();msg('Logo importé. Pense à publier.')};r.readAsDataURL(b)})};
 g.append(pv,mk('label',{className:'f'},[lab('Importer un logo (image carrée, idéalement 256 px)'),f]),fld(S,'name','Nom du site (titre de l’onglet et des favoris)','t'));
 if(S.fav)g.append(btn('Revenir au logo par défaut (un disque)',function(){S.fav='';after()}));B.append(g)}
function fillTx(){try{favApply()}catch(e){}try{cartUpd()}catch(e){}var m={ctN:'ctName',ctE:'ctMail',ctM:'ctMsg',nlE:'nlPh'};for(var k in m)$(k).placeholder=S.tx[m[k]]||'';
 $('rep').textContent=S.tx.repB;$('cr').hidden=true;$('sn').hidden=S.snd.show===false;
 $('mtE').placeholder=S.mt.ph;$('mtPw').placeholder='· · ·';$('mtPw').setAttribute('aria-label',S.mt.pl)}
var lastSend=0;
function mailBody(data){return Object.keys(data).map(function(k){return k+' : '+data[k]}).join('\n')}
function mailHref(sub,data){return 'mailto:'+S.ct.to+'?subject='+encodeURIComponent(sub)+'&body='+encodeURIComponent(mailBody(data))}
function sendMail(sub,data){
 return new Promise(function(res,rej){
  if(S.ct.mode!=='direct'||!S.ct.to)return rej(new Error('manuel'));
  var done=false,tm=setTimeout(function(){if(!done){done=true;rej(new Error('délai dépassé'))}},20000);
  function fail(e){if(done)return;done=true;clearTimeout(tm);rej(e||new Error('refusé'))}
  try{fetch('https://formsubmit.co/ajax/'+encodeURIComponent(S.ct.to),{method:'POST',headers:{'Content-Type':'application/json',Accept:'application/json'},
   body:JSON.stringify(Object.assign({_subject:sub,_captcha:'false',_template:'table'},data))})
  .then(function(r){return r.json()}).then(function(j){if(done)return;if(j&&(j.success===true||j.success==='true')){done=true;clearTimeout(tm);res('ok')}else fail(new Error('refusé par le service'))},fail)}catch(e){fail(e)}})}
function copyTxt(t,box,btn){
 function manual(){var ta=mk('textarea',{rows:5,value:t,readOnly:true});ta.style.cssText='display:block;width:100%;margin-top:.5rem';box.append(ta);ta.focus();ta.select()}
 try{navigator.clipboard.writeText(t).then(function(){btn.textContent=S.tx.ctCopied},manual)}catch(e){manual()}}
function failUI(s,sub,data,why){
 s.innerHTML='';
 s.append(mk('span',{textContent:(why==='manuel'?S.tx.ctReady:S.tx.ctFail)+' '}),mk('b',{textContent:S.ct.to}),document.createElement('br'));
 var a=mk('a',{className:'chip',href:mailHref(sub,data),textContent:S.tx.ctOpen}),c=mk('button',{type:'button',className:'chip',textContent:S.tx.ctCopy});
 c.onclick=function(){copyTxt('À : '+S.ct.to+'\nObjet : '+sub+'\n\n'+mailBody(data),s,c)};
 s.append(a,' ',c)}
function wire(fid,sid,okk,build){
 $(fid).addEventListener('submit',function(e){
  e.preventDefault();var f=$(fid),s=$(sid),hp=f.querySelector('[name=_honey]');if(hp&&hp.value)return;
  var m=build();if(!m.ok){s.textContent=m.err;SND.play('err');return}
  var now=Date.now();if(now-lastSend<2500){return}lastSend=now;s.textContent='Envoi…';
  sendMail(m.sub,m.data).then(function(){s.textContent=S.tx[okk];f.reset();SND.play('ok')},function(er){failUI(s,m.sub,m.data,er&&er.message);SND.play('err')})})}
function isMail(v){return /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(v||'')}
wire('ctF','ctS','ctOk',function(){var n=$('ctN').value.trim(),e=$('ctE').value.trim(),m=$('ctM').value.trim();
 if(!isMail(e))return{err:'Adresse e-mail invalide.'};if(!m)return{err:'Écris un petit message.'};return{ok:1,sub:'Message depuis le site'+(n?' – '+n:''),data:{Nom:n,Email:e,Message:m}}});
wire('nlF','nlS','nlOk',function(){var e=$('nlE').value.trim();if(!isMail(e))return{err:'Adresse e-mail invalide.'};return{ok:1,sub:'Inscription newsletter',data:{Email:e,Source:'Newsletter'}}});
wire('mtF','mtS','ctOk',function(){var e=$('mtE').value.trim();if(!isMail(e))return{err:'Adresse e-mail invalide.'};return{ok:1,sub:'Ouverture du site : préviens-moi',data:{Email:e,Source:'Page d’ouverture'}}});

function vidOK(u){return /^(https?:\/\/|\/)[^\s"'<>]+$/i.test(u||'')}
function ytId(u){var m=String(u||'').match(/(?:youtu\.be\/|youtube(?:-nocookie)?\.com\/(?:watch\?(?:[^#]*&)?v=|embed\/|shorts\/|live\/))([\w-]{11})/);return m?m[1]:''}
function clN(it){var u=it.u||'',x=it.x&&/^https?:/i.test(safeUrl(it.x))?safeUrl(it.x):'';
 if(u&&(netOf(u)||/youtu|vimeo|dailymotion/i.test(u))){if(!x)x=safeUrl(u);u=''}
 var play=!!u&&vidOK(u),id=ytId(x),p=safeImg(it.p);return{play:play,u:u,x:x,id:id,emb:false,p:p,name:it.n||''}}
function clips(){return (S.clip.list||[]).filter(function(c){var n=c&&clN(c);return n&&(n.play||n.x)})}
function clr(){
 var c=S.clip,box=$('clv'),sec=$('clip'),L=clips();
 sec.hidden=!L.length&&!!c.hide;
 box.style.setProperty('--clw',(c.w||36)+'rem');
 var sig=JSON.stringify([c.list,S.tx.clSoon,S.tx.clExt]);if(sig===CLSIG)return;CLSIG=sig;
 box.innerHTML='';
 if(!L.length){var d=mk('div',{className:'clp',textContent:S.tx.clSoon});d.dataset.p='tx.clSoon';box.append(d);return}
 var g=mk('div',{className:'clg'});
 L.forEach(function(it,i){var n=clN(it),btn=n.play||n.emb,el=mk(btn?'button':'a',{className:'clc'});
  if(btn){el.type='button';el.dataset.ci=i}else{el.href=n.x;el.target='_blank';el.rel='noopener'}
  el.setAttribute('aria-label',(n.name||S.tx.clH)+(btn?' (lecture)':' (ouvrir)'));
  var th=mk('span',{className:'clth'});
  if(n.p)th.style.backgroundImage="url('"+n.p+"')";
  else if(n.id){var im=mk('img',{alt:'',loading:'lazy',src:'https://i.ytimg.com/vi/'+n.id+'/hqdefault.jpg'});im.onerror=function(){im.remove()};th.append(im)}
  th.append(mk('span',{className:'clpl',textContent:'▶'}));el.append(th);
  if(n.name)el.append(mk('span',{className:'clnm',textContent:n.name}));
  g.append(el)});
 box.append(g)}
function closeLbx(){var L=$('lbx');L.hidden=true;L.querySelector('.lbb').innerHTML='';L.querySelector('.lbl').innerHTML=''}
function openLbx(i){var it=clips()[i];if(!it)return;var n=clN(it),L=$('lbx'),b=L.querySelector('.lbb'),l=L.querySelector('.lbl');b.innerHTML='';l.innerHTML='';
 if(n.play){var v=mk('video',{controls:true,autoplay:true,preload:'auto'});v.setAttribute('playsinline','');if(n.p)v.poster=n.p;v.src=n.u;b.append(v)}
 else if(n.emb){var f=mk('iframe',{src:'https://www.youtube-nocookie.com/embed/'+n.id+'?autoplay=1&rel=0',title:n.name||'Clip'});f.setAttribute('allow','autoplay; encrypted-media; picture-in-picture; fullscreen');f.setAttribute('allowfullscreen','');b.append(f)}
 if(n.x)l.append(mk('a',{className:'btn alt',href:n.x,target:'_blank',rel:'noopener',textContent:S.tx.clExt}));
 if(n.emb)l.append(mk('p',{className:'lbn',textContent:'Si le lecteur reste noir, utilise le bouton : YouTube s’ouvrira dans un nouvel onglet.'}));
 L.hidden=false;try{L.querySelector('.lbc').focus()}catch(e){}}
$('clv').addEventListener('click',function(e){var b=e.target.closest&&e.target.closest('[data-ci]');if(b)openLbx(+b.dataset.ci)});
$('lbx').addEventListener('click',function(e){if(e.target.id==='lbx'||(e.target.closest&&e.target.closest('.lbc')))closeLbx()});
document.addEventListener('keydown',function(e){if(e.key==='Escape'&&!$('lbx').hidden)closeLbx()});
function setBroken(on){
 on=!!on;if(on&&!S.eg2.on)return;if(on&&GONE){toast(S.tx.gone||'Il est parti.');return}if(on===BRK)return;BRK=on;
 document.documentElement.classList.toggle('broken',on);
  if(window.FXm)FXm.force(on?'casse':null);
 if(window.SND){SND.broke(on);SND.play(on?'break':'ok')}
 if(window.__gl)__gl.kick(on?4:0);
 clearInterval(brT);var v=document.querySelector('#lbx video');
 var rb=$('rep');if(rb){rb.hidden=true;if(on)setTimeout(function(){if(BRK)rb.hidden=false},5000)}
 if(on){if(S.eg2.txt)toast(S.tx.brkM);brT=setInterval(brkTick,600)}else if(v){v.playbackRate=1}}
var REP=false,xcImg=null,GONE=false;
var xcImgs={};
function xcImage(txt){txt=txt||'השלישי יהיה האחרון';if(xcImgs[txt]!=null)return xcImgs[txt];var W=1400,H=760,cv=document.createElement('canvas');cv.width=W;cv.height=H;var g=cv.getContext('2d');
 var fam='"Noto Sans Hebrew","Arial Hebrew","Heebo","David","Segoe UI","Arial",sans-serif',ws=txt.split(/\s+/),L=ws.length>1&&txt.length>9?[ws.slice(0,Math.ceil(ws.length/2)).join(' '),ws.slice(Math.ceil(ws.length/2)).join(' ')]:[txt],fs=L.length>1?270:360;
 g.direction='rtl';g.textAlign='center';g.textBaseline='middle';g.font='900 '+fs+'px '+fam;
 var w=0;L.forEach(function(s){w=Math.max(w,g.measureText(s).width)});if(w>W*.88){fs=Math.max(40,Math.floor(fs*W*.88/w));g.font='900 '+fs+'px '+fam}
 var seed=11;function rn(){seed=(seed*16807)%2147483647;return seed/2147483647}
 function lines(f){L.forEach(function(s,i){f(s,H/2+(i-(L.length-1)/2)*fs*1.08)})}
 g.fillStyle='#5a0a12';lines(function(s,y){g.fillText(s,W/2,y)});
 g.globalCompositeOperation='source-atop';
 var gr=g.createLinearGradient(0,0,W,H);gr.addColorStop(0,'rgba(255,120,150,.0)');gr.addColorStop(.25,'rgba(255,170,90,.16)');gr.addColorStop(.5,'rgba(255,90,190,.15)');gr.addColorStop(.75,'rgba(120,150,255,.15)');gr.addColorStop(1,'rgba(255,120,150,.0)');g.fillStyle=gr;g.fillRect(0,0,W,H);
 var rg=g.createRadialGradient(W*.34,H*.3,10,W*.34,H*.3,W*.5);rg.addColorStop(0,'rgba(255,225,225,.16)');rg.addColorStop(1,'rgba(255,225,225,0)');g.fillStyle=rg;g.fillRect(0,0,W,H);
 for(var s=0;s<14000;s++){var l=rn()<.5;g.fillStyle=l?'rgba(255,200,200,'+(.03+rn()*.07)+')':'rgba(40,0,6,'+(.05+rn()*.16)+')';g.beginPath();g.arc(rn()*W,rn()*H,.5+rn()*1.9,0,6.3);g.fill()}
 g.globalCompositeOperation='source-over';g.lineJoin='round';g.lineWidth=2;g.strokeStyle='rgba(255,200,200,.14)';lines(function(s,y){g.strokeText(s,W/2-1,y-1)});
 try{xcImgs[txt]=cv.toDataURL('image/png')}catch(e){xcImgs[txt]=''}return xcImgs[txt]}
function xcBuild(n){var st=$('xcb');st.innerHTML='';var im=xcImage(S.eg2.threat);
 for(var i=0;i<n;i++){var d=mk('div',{className:'xcl'});d.style.backgroundImage="url('"+im+"')";d.style.transform='translateZ('+((i-n/2)*3.4)+'px)';d.style.filter='brightness('+(.5+.9*i/n)+')';st.append(d)}}
function repairSeq(){
 if(!BRK||REP)return;REP=true;
 var calm=matchMedia('(prefers-reduced-motion:reduce)').matches,X=$('xs'),B=$('xcb'),T=$('xtx'),F=X.querySelector('.xfl'),G=X.querySelector('.xbg'),ST=X.querySelector('.xst'),R=document.documentElement,tm=[],jt=null,ft=null;
 function at(ms,f){tm.push(setTimeout(f,ms))}
 xcBuild(calm?3:14);X.hidden=false;X.style.background='rgba(0,0,0,0)';T.textContent='';T.style.opacity=0;B.style.display='';B.style.opacity=0;F.style.opacity=0;ST.style.transform='';
 $('rep').hidden=true;var t0=performance.now();
 G.animate([{opacity:0},{opacity:1}],{duration:calm?300:900,fill:'forwards'});
 if(calm){B.animate([{transform:'none',opacity:0},{transform:'none',opacity:1}],{duration:300,fill:'forwards'});T.style.opacity=1;at(1800,finish);return}
 R.classList.add('doom');clearInterval(brT);brT=setInterval(brkTick,150);
 if(window.SND)SND.doom();
 B.animate([
  {transform:'translateZ(-1400px) rotateY(-70deg) rotateX(8deg) scale(.4)',opacity:0,offset:0},
  {transform:'translateZ(-500px) rotateY(-35deg) rotateX(4deg)',opacity:1,offset:.12},
  {transform:'translateZ(-80px) rotateY(18deg) rotateX(-3deg)',opacity:1,offset:.55},
  {transform:'translateZ(40px) rotateY(-12deg) rotateX(2deg)',opacity:1,offset:.85},
  {transform:'translateZ(840px) rotateY(0deg) rotateX(0deg)',opacity:1,offset:1}],{duration:5400,fill:'forwards'});
 jt=setInterval(function(){var p=Math.min(1,(performance.now()-t0)/5400),a=2+p*16;ST.style.transform='translate('+((Math.random()-.5)*a)+'px,'+((Math.random()-.5)*a)+'px)'},45);
 at(3000,function(){ft=setInterval(function(){T.style.opacity=Math.random()<.78?1:.15},90)});
 at(5000,function(){F.animate([{opacity:0},{opacity:1},{opacity:1}],{duration:380,fill:'forwards'})});
 at(5450,function(){clearInterval(jt);clearInterval(ft);X.style.background='#000';B.style.display='none';T.style.opacity=0;G.style.opacity=0;F.getAnimations().forEach(function(a){a.cancel()});F.style.opacity=0});
 at(5900,finish);
 function finish(){tm.forEach(clearTimeout);clearInterval(jt);clearInterval(ft);R.classList.remove('doom');GONE=true;setBroken(false);render();
  X.animate([{opacity:1},{opacity:0}],{duration:calm?300:900,fill:'forwards'});
  setTimeout(function(){X.hidden=true;X.getAnimations().forEach(function(a){a.cancel()});G.getAnimations().forEach(function(a){a.cancel()});B.getAnimations().forEach(function(a){a.cancel()});X.style.opacity='';REP=false;toast(S.tx.repOk||'Site réparé.')},calm?350:950)}}
function brkTick(){
 if(document.hidden)return;
 var v=document.querySelector('#lbx video');if(v){try{v.playbackRate=[.5,1,1.6,2,.3][Math.floor(Math.random()*5)];if(Math.random()<.25&&v.duration&&!v.paused)v.currentTime=Math.max(0,v.currentTime-.5)}catch(e){}}
 if(S.eg2.txt&&Math.random()<.4){var w=S.eg2.words||[],bw=$('brkw');if(w.length&&bw){bw.textContent=w[Math.floor(Math.random()*w.length)];bw.classList.add('on');setTimeout(function(){bw.classList.remove('on')},350+Math.random()*600)}}
 if(EDIT||OWN&&$('pn')&&!$('pn').hidden)return;
 var els=document.querySelectorAll(S.eg2.txt?'main:not([hidden]) h2,main:not([hidden]) h3,#hero h1 span,header a,.lead':'#hero h1 span'),e=els[Math.floor(Math.random()*els.length)];
 if(!e||e.isContentEditable||e===document.activeElement||e.children.length)return;
 var t=e.textContent;if(!t||t.length>90)return;
 var g='█▓▒░#@%&?/\\',s=t.split('').map(function(ch){return ch===' '||Math.random()>.45?ch:g[Math.floor(Math.random()*g.length)]}).join('');
 e.textContent=s;setTimeout(function(){if(e.textContent===s)e.textContent=t},170)}
(function(){var bk=[];
 document.addEventListener('click',function(e){var a=e.target.closest&&e.target.closest('header b a');if(!a)return;var n=performance.now();bk.push(n);bk=bk.filter(function(t){return n-t<3500});if(bk.length>=7){bk=[];setBroken(true)}});
 $('rep').addEventListener('click',function(){repairSeq()})})();

/* ================= page d'ouverture / maintenance ================= */
function hx(b){return Array.prototype.map.call(new Uint8Array(b.buffer||b),function(x){return('0'+x.toString(16)).slice(-2)}).join('')}
function hashPw(pw,mt){mt=mt&&typeof mt==='object'?mt:{s:mt};if(!(window.crypto&&crypto.subtle&&window.TextEncoder))return Promise.resolve('');var E=new TextEncoder(),s=String(mt.s||'');
 if(mt.kdf==='pbkdf2')return crypto.subtle.importKey('raw',E.encode(String(pw)),'PBKDF2',false,['deriveBits']).then(function(k){return crypto.subtle.deriveBits({name:'PBKDF2',hash:'SHA-256',salt:E.encode(s),iterations:Math.max(10000,Math.min(2000000,+mt.it||210000))},k,256)}).then(hx).catch(function(){return ''});
 return crypto.subtle.digest('SHA-256',E.encode(s+'|'+pw)).then(hx).catch(function(){return ''})}
var MTB=false;
function mtRender(){
 var m=S.mt,el=$('mt'),show=(m.on&&!MT_OK&&(!OWN||m.gate))||MT_PRE;
 el.hidden=!show;document.documentElement.classList.toggle('locked',show);if(window.__gl&&window.__mtShown&&!show)__gl.reveal();window.__mtShown=show;try{if(window.SND&&SND.amb)SND.amb()}catch(e){}
 $('mtT').textContent=m.t;$('mtD').textContent=m.d;$('mtF').hidden=!m.mail;$('mtB').textContent=m.mb;$('mtP').textContent='·';$('mtP').title=m.pl;$('mtP').setAttribute('aria-label',m.pl);$('mtPb').textContent=m.pb;
 $('mtP').hidden=true;$('mtW').hidden=false;$('mtX').hidden=!MT_PRE;
 $('mtbn').hidden=!(m.on&&OWN&&!MT_PRE);$('mtbp').textContent=(m.h||m.hp)?'Changer le mot de passe d’accès':'Définir le mot de passe d’accès';fillTx();try{mqUpd()}catch(e){}}
$('mtbp').addEventListener('click',function(){openPanel();TAB='ct';fillBody()});
$('mtP').addEventListener('click',function(){$('mtW').hidden=!$('mtW').hidden;if(!$('mtW').hidden)$('mtPw').focus()});
$('mtX').addEventListener('click',function(){MT_PRE=false;mtRender()});
$('mtW').addEventListener('submit',function(e){e.preventDefault();var s=$('mtS');
 if(S.mt.gate){var pw=$('mtPw').value;if(!pw||MTB)return;MTB=true;s.textContent='…';
  fetch('/.netlify/functions/porte',{method:'POST',headers:{'Content-Type':'application/json'},credentials:'same-origin',cache:'no-store',body:JSON.stringify({pw:String(pw).slice(0,200)})}).then(function(r){
   if(r.ok){location.reload();return}
   MTB=false;$('mtPw').value='';s.textContent=r.status===429?'Trop d’essais. Réessaie dans quelques minutes.':r.status===401?S.mt.bad:'Connexion impossible. Réessaie.';try{SND.play('err')}catch(x){}
  }).catch(function(){MTB=false;s.textContent='Connexion impossible. Réessaie.'});return}
 hashPw($('mtPw').value,S.mt).then(function(h){
  if(S.mt.h&&h&&h===S.mt.h){MT_OK=true;SND.play('egg');mtRender()}
  else{s.textContent=S.mt.bad;SND.play('err')}})});

(function(){try{['yuu_pass','yuu_porte'].forEach(function(n){document.cookie=n+'=; Path=/; Max-Age=0'});sessionStorage.removeItem('yuu-porte')}catch(e){}})();
/* ================= secrets n°3, n°4, n°5 ================= */
function hidP(){return S.products.filter(function(p){return p.hid})[0]}
function engLink(){var p=hidP();if(!p)return'';var hs=String(S.eg5.host||location.host||'').replace(/^https?:\/\//,'').replace(/^www\./,'').replace(/\/.*$/,'');return (hs+'/#'+p.s).toUpperCase()}
var ACTT=Date.now();function actv(){ACTT=Date.now()}
['pointerdown','pointermove','keydown','wheel','touchstart','scroll'].forEach(function(k){addEventListener(k,actv,{passive:true,capture:true})});
var MYQ=false,MYQT=0;
function posMyq(){var b=$('myq'),d=$('dsw'),hr=$('hero');if(!b||!d||!hr||b.hidden)return;var r=d.getBoundingClientRect(),q=hr.getBoundingClientRect(),w=b.offsetWidth||38;if(!r.width)return;var l=r.right-q.left+10;l=Math.min(l,q.width-w-8);b.style.left=Math.round(l)+'px';b.style.top=Math.round(r.top-q.top+(r.height-w)/2)+'px'}
function hideMyq(){MYQ=false;clearInterval(MYQT);var b=$('myq');if(b)b.remove()}
function showMyq(){if(MYQ||MYSON)return;var hr=$('hero');if(!hr)return;MYQ=true;var b=document.createElement('button');b.type='button';b.id='myq';b.className='myq';b.textContent='?';b.setAttribute('aria-label','?');b.addEventListener('click',function(e){e.stopPropagation();mysGo()});hr.appendChild(b);posMyq();MYQT=setInterval(posMyq,700);if(window.SND)SND.play('tap',2)}
function mysGo(){hideMyq();if(window.SND&&S.snd.show!==false&&S.eg3.snd!==false){if(window.SNDON===false)SND.toggle();else SND.wake&&SND.wake()}unlockMys(true);var j=vis().findIndex(function(d){return d.mys});if(j>=0){ACT=j;dswSel();heroUpd();bgr();if(window.FXm)FXm.apply();if(window.__gl){__gl.cd();__gl.front(1800)}}
 if(window.SND)SND.sync()}
addEventListener('resize',posMyq);
function unlockMys(force){if(!force&&(!S.eg3.on||MYSON))return;MYSON=true;if(window.SND)SND.sync();dsig='';dswSync();var b=document.querySelector('#dsw button:last-of-type');if(b){b.classList.add('pls');setTimeout(function(){b.classList.remove('pls')},6000)}if(window.__gl)__gl.front(1800);if(window.SND)SND.play('egg')}
setInterval(function(){if(OWN||MYSON||!S.eg3.on||document.hidden||BRK||document.documentElement.classList.contains('locked'))return;if(scrollY>innerHeight*.9)return;if(!MYQ&&Date.now()-ACTT>Math.max(5,+S.eg3.sec||60)*1000)showMyq()},1000);
/* n°4 : code gestuel -> compte à rebours */
var SWB='',SWT=0,CWAS=false,CTM=0;
function cdnClose(){var o=$('cdn');if(o)o.remove();clearInterval(CTM);if(window.__gl)__gl.hold(0);window.FRZ=false;if(CWAS&&window.SNDON===false&&window.SND)SND.toggle();CWAS=false}
function cdnOpen(){if($('cdn'))return;var o=mk('div',{id:'cdn',role:'dialog'});o.innerHTML='<div class="ci"><p class="cl"></p><p class="cp2"></p><div class="ct2"></div><p class="ce2"></p><p class="cm" style="margin:1.2rem auto 0;max-width:30rem;font:600 clamp(1rem,3.4vw,1.5rem)/1.5 ui-monospace,Menlo,monospace;text-align:center;white-space:pre-line;color:#fff"></p><small>touche pour fermer</small></div>';document.body.append(o);
 o.querySelector('.cl').textContent=S.eg4.lbl;o.querySelector('.cp2').textContent=S.eg4.pre;var MD=S.eg4.mode||'count',cm=o.querySelector('.cm');cm.textContent=S.eg4.msg||'';cm.style.display=(MD==='count'||!S.eg4.msg)?'none':'';if(MD==='msg'){o.querySelector('.ct2').style.display='none';o.querySelector('.cp2').style.display='none'}
 window.FRZ=true;if(window.__gl)__gl.hold(1e12);CWAS=!!window.SNDON;if(window.SNDON&&window.SND)SND.toggle();
 function tick(){var t=new Date(S.eg4.date).getTime(),d=isFinite(t)?Math.max(0,t-Date.now()):0,s=Math.floor(d/1000),p=function(n){return String(n).padStart(2,'0')};
  var dd=Math.floor(s/86400),hh=Math.floor(s%86400/3600),mm=Math.floor(s%3600/60),ss=s%60;
  o.querySelector('.ct2').innerHTML=[[dd,'jours'],[hh,'heures'],[mm,'minutes'],[ss,'secondes']].map(function(x){return '<span><b>'+p(x[0])+'</b><i>'+x[1]+'</i></span>'}).join('');
  o.querySelector('.ce2').textContent=(d===0&&MD!=='msg')?S.eg4.end:''}
 tick();CTM=setInterval(tick,1000);o.addEventListener('click',cdnClose);if(window.SND)SND.play('egg')}
document.addEventListener('keydown',function(e){if(e.key==='Escape'&&$('cdn'))cdnClose()});
/* Mini-jeu (secret n°4) : PONG « YUU VS YOU », lancé par le code du disque. Le CD de la partie est tiré au sort
   parmi les disques du site (rendus par le même moteur 3D). Classement commun : fonction Netlify « scores » */
window.PGON=false;
window.PONG=(function(){
 var LW=360,LH=640,PH=10,A_Y=56,P_Y=584,sc=1,dpr=1,root=null,fit=null,scr=null,cv=null,cx=null,bgc=null,cvR=null,ui={},raf=0,last=0,oldOv='',oldOvB='';
 var st='title',paused=false,G=null,overT=0,dropT=0,dropI=0,dropAt=0,plan=[],glT=0,glD=0,revOn=false,revT=0,dropShk=0,cdX=180,cdY=300,cdR=60,ERR='',gm=false,nv=false;
 var rfx=[],rings=[],FORCE=null,PRESC=0,ALL=[],CRK=[],crc=null;
 /* musique de la partie : une par rareté (les 2 communs partagent la leur), remplaçable par disque dans le panneau */
 var MU=null,MUG=null,MU2=null,MUon=false;
 var AR='https://archive.org/download/Komiku-Poupis_incredible_adventures/';
 var MDEF={commun:['/assets/music/commun-v1.mp3',AR+'Komiku_-_29_-_Poupi_Great_Adventures__The_Arcade_Game.mp3'],rare:['/assets/music/rare-v1.mp3',AR+'Komiku_-_25_-_Space_Bicycle.mp3'],mystere:['/assets/music/mystere-v1.mp3',AR+'Komiku_-_14_-_Fracture_of_the_universe_will_happen_soon.mp3'],noir:['/assets/music/noir-v1.mp3',AR+'Komiku_-_35_-_Mr_Angst_Theme.mp3'],ahabah:['/assets/music/ahabah-v1.mp3',AR+'Komiku_-_58_-_Universe_big_takedown.mp3'],eeveie:['/assets/music/eeveie-v1.mp3',AR+'Komiku_-_16_-_Disco_Cat.mp3'],taku:['/assets/music/taku-v1.mp3',AR+'Komiku_-_19_-_Cat_Race_Challenge.mp3']};
 var OPN={eeveie:{n:'EEVEIE',v:'VAINCUE',k:'eev',c:['#ff6fb1','#ffd166','#7cf5c8','#7aa8ff','#c79bff']},taku:{n:'TAKU',v:'VAINCU',k:'taku',c:['#4fd8ff','#5dffa1','#b6ff5d','#ffe14f','#ff9f4a']}};
 var P={x:180,vx:0,w:80,fl:0,react:0,err:0},A={x:180,vx:0,w:80,fl:0,react:0,err:0};
 var B={x:180,y:320,vx:0,vy:0,r:14,spin:0,live:false,wait:1,dir:-1,base:330};
 var trail=[],parts=[],bans=[],shake=0,flC='#fff',flT=0;
 var keys={l:false,r:false},ptrX=null;
 var board=[],cats={},BC='',src='load',rank=0,crank=0,HI=0,NEWREC=false;
 var DISC=[],ICON={},spr=null,cP='#ff4d6d',cA='#a99bff',glow='#ffffff',carI=0,carT=0,shotsOK=false;
 var API='/.netlify/functions/scores',CH='ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789',ini=[0,0,0],cur=0;
 var TOUCH=false;
 var DEF={setsuna:[40,1],gry:[40,1],yukyu:[13,2],mystere:[5,3]};
 var RAR={1:['COMMUN','#c9c4e8'],2:['RARE','#6fb6ff'],3:['LÉGENDAIRE','#ff4d6d'],4:['MYTHIQUE','#ffcf4a']};
 var GOLD={k:'ahabah',d:{k:'ahabah',n:'AHABAH',t:'',img:'',tint:'#e2b33c',cd:{holo:.2,glare:1.35,la:1.3,grain:.6,relief:.07,cen:.62,fit:.94,edge:.82,hole:.12}},w:0,p:4,name:'AHABAH',col:'#ffcf4a',still:null,frames:null,pc:0};
 var NOIR={k:'noir',d:{k:'noir',n:'DISQUE NOIR',t:'',img:'',tint:'#101014',cd:{holo:.2,glare:1.35,la:1.3,grain:.6,relief:.07,cen:.62,fit:.94,edge:.82,hole:.12}},w:0,p:4,name:'DISQUE NOIR',col:'#dde1ec',still:null,frames:null,pc:0};
 function isMy(D){return D===GOLD||D===NOIR}
 function carL(){return DISC.concat([GOLD,NOIR])}
 /* réglages du jeu figés au chargement pour les visiteurs (les modifier depuis la console ne change rien) */
 var CFG0=null;try{CFG0=JSON.parse(JSON.stringify(S.pong||{}));(function fz(o){Object.freeze(o);Object.keys(o).forEach(function(k){if(o[k]&&typeof o[k]==='object')fz(o[k])})})(CFG0)}catch(e){}
 function cfg(){if(CFG0&&!(window.__PGT||(typeof OWN!=='undefined'&&OWN)))return CFG0;return S.pong||{}}
 var GCD=GOLD.d.cd,GIMG={};
 function mysD(){return (S.discs||[]).filter(function(x){return x.mys})[0]||null}
 function msrc(m){return m&&m.img?((window.LOCAL&&LOCAL[m.img])||m.img):''}
 var PAL={ahabah:[[0,[34,20,2]],[.3,[108,70,12]],[.55,[188,138,38]],[.78,[240,200,96]],[1,[255,247,214]]],noir:[[0,[3,3,5]],[.35,[16,16,22]],[.6,[42,43,54]],[.82,[100,103,120]],[1,[200,204,218]]]};
 function gpal(v){gpal.L=gpal.L||{};if(gpal.L[v])return gpal.L[v];var T=PAL[v],L=new Uint8Array(768);for(var i=0;i<256;i++){var t=i/255,j=0;while(j<T.length-2&&t>T[j+1][0])j++;var a=T[j],b=T[j+1],u=(t-a[0])/(b[0]-a[0]);for(var c=0;c<3;c++)L[i*3+c]=Math.round(a[1][c]+(b[1][c]-a[1][c])*u)}return gpal.L[v]=L}
 function goldPrep(){return;var src=msrc(mysD());if(!src)return;['ahabah','noir'].forEach(function(v){var C=GIMG[v]=GIMG[v]||{src:'',url:'',busy:''};if(C.src===src||C.busy===src)return;C.busy=src;var im=new Image();im.crossOrigin='anonymous';
  im.onload=function(){try{var w=im.naturalWidth,h=im.naturalHeight,k=Math.min(1,1024/Math.max(w,h));w=Math.max(1,Math.round(w*k));h=Math.max(1,Math.round(h*k));var c=document.createElement('canvas');c.width=w;c.height=h;var g=c.getContext('2d');g.drawImage(im,0,0,w,h);var id=g.getImageData(0,0,w,h),p=id.data,L=gpal(v);
   for(var i=0;i<p.length;i+=4){var l=Math.round(.299*p[i]+.587*p[i+1]+.114*p[i+2]);p[i]=L[l*3];p[i+1]=L[l*3+1];p[i+2]=L[l*3+2]}g.putImageData(id,0,0);
   c.toBlob(function(b){if(!b||C.busy!==src){C.busy='';return}C.url=URL.createObjectURL(b);C.src=src;C.busy='';goldSync(true)},'image/png')}catch(e){C.busy=''}};
  im.onerror=function(){C.busy=''};im.src=src})}
 function noirize(c){var nd=(S.discs||[]).filter(function(x){return x.k==='noir'&&x.myt})[0];if(nd&&(nd.img||String(nd.tint||'').toLowerCase()!=='#101014'))return c;try{var g=c.getContext('2d'),id=g.getImageData(0,0,c.width,c.height),p=id.data,L=gpal('noir');for(var i=0;i<p.length;i+=4){if(!p[i+3])continue;var l=Math.round(.299*p[i]+.587*p[i+1]+.114*p[i+2]);p[i]=L[l*3]*.8;p[i+1]=L[l*3+1]*.8;p[i+2]=L[l*3+2]*.85}g.putImageData(id,0,0)}catch(e){}return c}
 function mythD(v,m){var o=(S.discs||[]).filter(function(x){return x.k===v&&x.myt})[0],d=JSON.parse(JSON.stringify(o||m||{}));delete d.mys;delete d.egg;delete d.myt;d.k=v;d.n=v==='noir'?'DISQUE NOIR':'AHABAH';d.t='';if(!o){d.tint=v==='noir'?'#101014':'#e2b33c';d.img=''}if(!d.cd)d.cd=GCD;return d}
 function goldSync(late){var m=mysD(),on=late&&window.PGON&&root;[GOLD,NOIR].forEach(function(O){var d=mythD(O.k,m);O.d=d;O.still=O.frames=O.sp=null;O.fb=0;
  if(on){O.sp=mkSpr(d);if(G&&G.disc===O)framesFor(O);if(window.__gl&&__gl.shots)__gl.shots([d],{still:300}).then(function(o){if(O.d===d&&o&&o[O.k]&&o[O.k].still){O.still=O===NOIR?noirize(o[O.k].still):o[O.k].still;icons();drawBoards()}}).catch(function(){})}});
  if(on){icons();drawBoards()}}
 function gk(){return G&&G.ck==='noir'?'noir':'ahabah'}
 function mslot(D){if(isMy(D))return D.k;var k=D.k;return k==='setsuna'||k==='gry'?'commun':k==='yukyu'?'rare':k==='mystere'?'mystere':(D.d&&D.d.mys)||D.p===3?'mystere':(D.d&&D.d.egg)||D.p===2?'rare':'commun'}
 function murls(D){if(G&&G.eev&&G.eevIn&&OPN[G.eev]){var ce=(cfg().mus||{})[G.eev];if(ce&&typeof audOK==='function'&&audOK(ce))return [(window.LOCAL&&LOCAL[ce])||ce];return MDEF[G.eev].slice()}var c=(cfg().mus||{})[D.k];if(c&&typeof audOK==='function'&&audOK(c))return [(window.LOCAL&&LOCAL[c])||c];return MDEF[mslot(D)].slice()}
 function mvol(){var v=parseFloat(cfg().mv);return isFinite(v)?clamp(v,0,1):.35}
 function mwant(){return cfg().mon!==false&&!!window.SNDON&&S.snd.show!==false}
 function muInit(){if(MU)return;MU=new Audio();MU.loop=true;MU.preload='auto';MU.setAttribute('playsinline','');try{MUG=window.SND&&SND.media?SND.media(MU):null}catch(e){MUG=null}if(!MUG)MU.volume=0}
 function muSet(D){if(!mwant())return;muInit();var L=murls(D);chipStop(.05);if(G)G.chip=false;MU._L=L;MU._i=0;var xo=function(u){try{if(MUG&&/^https?:/i.test(u)&&new URL(u,location.href).origin!==location.origin)MU.crossOrigin='anonymous';else MU.removeAttribute('crossorigin')}catch(e){}};MU.onerror=function(){var i=++MU._i;if(MU._L&&i<MU._L.length){xo(MU._L[i]);MU.src=MU._L[i];if(MUon)muPlay()}else if(G&&G.eev){G.chip=true;try{MU.pause()}catch(e){}if(MUon)chipStart(G.eev)}};xo(L[0]);MU.src=L[0];
  try{MU.muted=true;var p=MU.play();if(p&&p.then)p.then(function(){if(!MUon)MU.pause();MU.muted=false}).catch(function(){MU.muted=false});else{MU.pause();MU.muted=false}}catch(e){MU.muted=false}}

 /* musique de secours d'EEVEIE et TAKU, jouée par le navigateur (aucun fichier) : elle se lance toujours, même si le mp3 manque */
 var CHP=null;
 function chipCtx(){try{if(MUG&&MUG.context)return MUG.context}catch(e){}try{if(!window.__chipCtx){var AC=window.AudioContext||window.webkitAudioContext;if(!AC)return null;window.__chipCtx=new AC()}return window.__chipCtx}catch(e){return null}}
 function mkSong(k){var L=[],B=[],A=[];
  if(k==='taku'){var ch=[[40,[0,3,7,12]],[36,[0,4,7,12]],[38,[0,4,7,12]],[35,[0,4,7,10]]];
   ch.forEach(function(c,bi){for(var i=0;i<16;i++){B.push(c[0]+(i%4===2?12:0));var t=c[1];A.push(c[0]+36+t[(i+(bi%2?2:0))%4]);L.push(i%4===0||i===6||i===10||i===14?c[0]+24+t[[3,2,1,2,0,1,2,3][(i>>1)%8]%4]+12:null)}});return {bpm:150,b:B,a:A,l:L,w:'sawtooth',wl:'square',av:.05,bv:.16,lv:.07,hat:2}}
  var cd=[[45,[0,3,7]],[41,[0,4,7]],[48,[0,4,7]],[43,[0,4,7]]],mel=[[12,null,15,null,19,null,15,12,null,10,12,null,7,null,null,null],[12,null,16,null,19,null,21,19,null,16,null,12,14,null,null,null],[19,null,16,null,12,null,16,19,null,24,null,19,16,null,null,null],[14,null,11,null,7,null,11,14,null,19,null,17,14,null,11,null]];
  cd.forEach(function(c,bi){for(var i=0;i<16;i++){B.push(i%2===0?c[0]+(i%4===2?12:0):null);A.push(i%2===1?c[0]+24+c[1][(i>>1)%3]:null);var m=mel[bi][i];L.push(m==null?null:c[0]+12+m)}});
  return {bpm:122,b:B,a:A,l:L,w:'triangle',wl:'square',av:.035,bv:.22,lv:.075,hat:1}}
 function chipStop(t){if(!CHP)return;var h=CHP;CHP=null;clearInterval(h.iv);try{var n=h.c.currentTime;h.o.gain.cancelScheduledValues(n);h.o.gain.setValueAtTime(h.o.gain.value,n);h.o.gain.linearRampToValueAtTime(0,n+(t||.3));setTimeout(function(){try{h.o.disconnect()}catch(e){}},((t||.3)+.2)*1000)}catch(e){}}
 function chipStart(k){chipStop(.05);var c=chipCtx();if(!c)return;try{if(c.state==='suspended')c.resume()}catch(e){}
  var S=mkSong(k),o=c.createGain(),st=0,nt=c.currentTime+.06,nz=c.createBuffer(1,c.sampleRate*.25,c.sampleRate),d=nz.getChannelData(0);for(var i=0;i<d.length;i++)d[i]=Math.random()*2-1;
  o.gain.value=0;o.connect(c.destination);o.gain.linearRampToValueAtTime(mvol()*1.4,c.currentTime+.6);
  function f(m){return 440*Math.pow(2,(m-69)/12)}
  function tone(m,t,du,w,v){var x=c.createOscillator(),g=c.createGain();x.type=w;x.frequency.value=f(m);g.gain.setValueAtTime(0,t);g.gain.linearRampToValueAtTime(v,t+.005);g.gain.exponentialRampToValueAtTime(.0005,t+du);x.connect(g);g.connect(o);x.start(t);x.stop(t+du+.02)}
  function noise(t,du,v,hp){var x=c.createBufferSource(),fl=c.createBiquadFilter(),g=c.createGain();x.buffer=nz;fl.type=hp?'highpass':'bandpass';fl.frequency.value=hp?7000:1800;g.gain.setValueAtTime(v,t);g.gain.exponentialRampToValueAtTime(.0005,t+du);x.connect(fl);fl.connect(g);g.connect(o);x.start(t);x.stop(t+du+.02)}
  function kick(t){var x=c.createOscillator(),g=c.createGain();x.frequency.setValueAtTime(150,t);x.frequency.exponentialRampToValueAtTime(42,t+.12);g.gain.setValueAtTime(.55,t);g.gain.exponentialRampToValueAtTime(.001,t+.2);x.connect(g);g.connect(o);x.start(t);x.stop(t+.22)}
  CHP={k:k,c:c,o:o,iv:setInterval(function(){if(!CHP)return;var r=(MU&&MU.playbackRate)||1,sp=60/S.bpm/4/r;while(nt<c.currentTime+.18){var q=st%16;
    if(q%4===0)kick(nt);if(q===4||q===12)noise(nt,.16,.32,false);if(q%S.hat===(S.hat-1)||S.hat===1&&q%2===1)noise(nt,.04,.09,true);
    if(S.b[st]!=null)tone(S.b[st],nt,sp*1.6,S.w,S.bv);if(S.a[st]!=null)tone(S.a[st],nt,sp*.9,'square',S.av);if(S.l[st]!=null)tone(S.l[st],nt,sp*1.8,S.wl,S.lv);
    st=(st+1)%S.b.length;nt+=sp}},25)}}
 function chipOn(){return !!(G&&G.eev&&G.chip)}
 function muFade(v,t){if(CHP){try{var cn=CHP.c.currentTime;CHP.o.gain.cancelScheduledValues(cn);CHP.o.gain.setValueAtTime(CHP.o.gain.value,cn);CHP.o.gain.linearRampToValueAtTime(v*1.4,cn+(t||.6))}catch(e){}}if(!MU)return;if(MUG){try{var c=MUG.context,n=c.currentTime;MUG.gain.cancelScheduledValues(n);MUG.gain.setValueAtTime(MUG.gain.value,n);MUG.gain.linearRampToValueAtTime(v,n+(t||.6))}catch(e){MUG.gain.value=v}}else{try{MU.volume=v}catch(e){}}}
 function muPlay(){if(chipOn()&&mwant()){MUon=true;if(!CHP)chipStart(G.eev);else muFade(mvol(),1);return}if(!MU||!mwant())return;MUon=true;MU.muted=false;try{if(MUG&&MUG.context.state==='suspended')MUG.context.resume()}catch(e){}try{var p=MU.play();if(p&&p.catch)p.catch(function(){})}catch(e){}muFade(mvol(),1.2)}
 function muStop(now){MUon=false;chipStop(now?.05:.5);if(!MU)return;muFade(0,now?.05:.5);setTimeout(function(){if(!MUon&&MU)try{MU.pause()}catch(e){}},now?80:600)}
 function clamp(v,a,b){return v<a?a:v>b?b:v}
 function rnd(a,b){return a+Math.random()*(b-a)}
 var BADN='ADF AFD AHH ANL ANU ARS ASS BCT BGN BIC BIT BJB BLD BNL BTD BTE BTR BZ1 CAC CAK CHT CKE CNE CNR CNT COC COK CON CUL CUM DAE DCK DIC DIE DIK EIL ENC ENK FAG FCK FDP FFS FUC FUK FUQ GAZ GNE GOU HER HIT HIV HOE HTL HTR ISI ISS JEW JIZ KAK KIL KKK KLL KLX KMS KYS LFI LFN LPN LRN LSD MDM MLP MRD MRT NAZ NEG NGA NGG NGO NGR NIG NIK NIQ NKT NPA NTA NTM NUD PCF PDD PDE PED PEN PIP PIS PNL PNS POR PRN PTN PUS PUT RAP RAT RPE SAL SEX SHO SHT SLP SLT SSS SUC SUI SUK SXE SXY TEB TGL TIT TPD TWT UMP VAG VIH WHR WPW WTF XXX ZEB ZEM ZMR ZOB'.split(' ');function badN(n){var u=String(n||'').toUpperCase(),l=u.replace(/0/g,'O').replace(/1/g,'I').replace(/3/g,'E').replace(/4/g,'A').replace(/5/g,'S').replace(/7/g,'T').replace(/8/g,'B').replace(/9/g,'G').replace(/6/g,'G'),l2=l.replace(/I/g,'L'),l3=u.replace(/0/g,'O').replace(/1/g,'L');if(/^(L|N)?[RF]N|[RF]N[0-9LN]$|^SS|SS[0-9]$|^PD|PD$|88|14$|^H8|^AH[0-9]|^K[KQ]K/.test(u)||/^(L|N)?[RF]N|[RF]N[0-9LN]$|^SS|SS[0-9]$|^PD|PD$|88|14$|^H8|^AH|^K[KQ]K/.test(l))return true;return [u,l,l2,l3].some(function(x){return BADN.indexOf(x)>=0})}
 function okB(L){return (L||[]).filter(function(e){return !badN(e&&e.n)})}
 function p6(n){return String(Math.max(0,Math.floor(n))).padStart(6,'0')}
 function pB(n){var t=p6(n);return n>=1e6?'<b class="pg-mil">'+t+'</b>':n>=1e5?'<b class="pg-k">'+t+'</b>':t}
 function olC(L){var m=0;(L||[]).forEach(function(e){if(+e.s>m)m=+e.s});return m>=1e8?' class="pg-big pg-huge"':m>=1e6?' class="pg-big"':''}
 function F(px){return px+'px "Press Start 2P",ui-monospace,Menlo,monospace'}
 function esc(s){return String(s).replace(/[&<>"]/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]})}
 function hexA(h,a){var n=parseInt(String(h).slice(1),16);if(!isFinite(n))n=0xffffff;return 'rgba('+(n>>16&255)+','+(n>>8&255)+','+(n&255)+','+a+')'}
 function okC(list,f){for(var i=0;i<list.length;i++){var c=String(list[i]||'').trim();if(/^#[0-9a-f]{6}$/i.test(c)&&lum(c)>=.2)return c}return f}
 function plain(s){return String(s||'').normalize('NFD').replace(/[̀-ͯ]/g,'').toUpperCase()}
 function snd(k,n){if(!G||(st!=='play'&&st!=='drop'&&k!=='over'))return;try{if(window.SND&&SND.game)SND.game(k,n)}catch(e){}}
 function lives(){return clamp(parseInt(cfg().lives)||3,1,5)}
 function winG(){return clamp(parseInt(cfg().goals)||5,3,10)}
 function base(){return G&&st==='play'&&G.disc!==NOIR?2:0}
 function tx2(){return G&&G.disc!==NOIR&&G.disc!==GOLD?1.6:1}
 function tier(){return G&&st==='play'?Math.min(12,Math.floor((G.score||0)/1e5)):0}
 function skill(lv){if(G&&G.fx&&G.fx.hard&&st==='play')lv+=Math.round(5*G.fx.hard);lv+=tier()+base();return{err:Math.max(3,44-7*(lv-1)),spd:Math.min(780,230+62*(lv-1)),react:Math.max(.03,.2-.03*(lv-1))}}
 function v0(lv){return 330+18*(lv-1)+(G&&G.fx&&G.fx.hard?120*G.fx.hard:0)+22*tier()*tx2()+15*base()}
 function vmax(lv){var hd=G&&G.fx&&G.fx.hard?G.fx.hard:0,tr=tier()*tx2();return Math.min(980+200*hd+30*tr,640+34*(lv-1)+200*hd+30*tr)}
 function lvl(){return G&&st==='play'?G.lv:4}
 function pw(){return G&&G.disc?G.disc.p:1}
 /* ---------- les disques : tirage au sort et puissance ---------- */
 function mkDiscs(){var dr=cfg().drop||{};ALL=(S.discs||[]).filter(function(d){return !d.myt}).map(function(d){var df=DEF[d.k]||(d.mys?[5,3]:d.egg?[13,2]:[40,1]),o=dr[d.k]||{},w=parseFloat(String(o.w==null?'':o.w).replace(',','.'));if(!isFinite(w))w=df[0];w=Math.max(0,w);
   return {k:d.k,d:d,w:w,p:clamp(parseInt(o.p)||df[1],1,3),name:d.mys?'?':plain(d.n||d.k),col:d.mys?'#ff2a4a':okC([d.th&&d.th.tcol,d.th&&d.th.ink,d.tint],'#ff4d6d'),still:null,frames:null}});DISC=ALL.filter(function(x){return x.w>0});
  if(!DISC.length)DISC=[{k:'yuu',d:null,w:1,p:1,name:'YUU',col:'#ff4d6d',still:null,frames:null}];
  var tot=DISC.reduce(function(a,x){return a+x.w},0),rest=Math.max(0,100-goldP()-ahaP());DISC.forEach(function(x){var v=rest*x.w/tot;x.pc=v>0&&v<.1?.1:Math.round(v*10)/10})}
 function forced(){if(!FORCE)return null;if(FORCE==='ahabah')return GOLD;if(FORCE==='noir'||FORCE==='or')return NOIR;return ALL.filter(function(x){return x.k===FORCE})[0]||null}
 function pcv(x,d){var v=parseFloat(String(x==null||x===''?d:x).replace(',','.'));return isFinite(v)?clamp(v,0,10):d}
 function noirP(){return pcv(cfg().noir,.5)}
 function goldP(){return noirP()}
 function ahaP(){return pcv(cfg().ahabah,1.5)}
 function fmtP(v){return String(Math.round(v*1000)/1000).replace('.',',')}
 function draw1(){var r=Math.random()*100,a=ahaP();if(r<a)return GOLD;if(r<a+noirP())return NOIR;var tot=DISC.reduce(function(a,x){return a+x.w},0),r=Math.random()*tot;for(var i=0;i<DISC.length;i++){r-=DISC[i].w;if(r<=0)return DISC[i]}return DISC[DISC.length-1]}
 function hardOf(D){if(D===NOIR)return 1;var top=0;DISC.forEach(function(x){if(+x.pc>top)top=+x.pc});var pc=D===GOLD?ahaP():+D.pc,lo=noirP();if(!(top>0)||!(pc>0)||!(lo>0)||pc>=top)return 0;return Math.pow(clamp(Math.log(top/pc)/Math.log(top/Math.min(lo,pc)),0,1),.55)}
 function fx(D){var o=D===NOIR?{m:10,sh:1.45,pw:.82,shield:0}:D.p===4?{m:5,sh:1.42,pw:.86,shield:1}:D.p>=3?{m:3,sh:1.3,pw:1.05}:D.p===2?{m:2,sh:1.15,pw:1}:{m:1,sh:1,pw:1};var h=0;try{h=hardOf(D)}catch(e){}if(h>.01)o.hard=Math.round(h*100)/100;return o}
 function mkSpr(d){var N=192,c=document.createElement('canvas');c.width=c.height=N;var g=c.getContext('2d'),R=N/2,tint=okC([d&&d.tint],'#9aa3c0');
  function paint(img){g.setTransform(1,0,0,1,0,0);g.globalCompositeOperation='source-over';g.clearRect(0,0,N,N);g.save();g.beginPath();g.arc(R,R,R-1,0,7);g.clip();
   var b=g.createRadialGradient(R*.75,R*.65,R*.1,R,R,R);b.addColorStop(0,'#f4f6fb');b.addColorStop(.6,'#c3c8d6');b.addColorStop(1,'#8b92a6');g.fillStyle=b;g.fillRect(0,0,N,N);
   if(img&&img.naturalWidth){var s=Math.max(N/img.naturalWidth,N/img.naturalHeight),w=img.naturalWidth*s,h=img.naturalHeight*s;g.drawImage(img,(N-w)/2,(N-h)/2,w,h)}
   else{var tg=g.createLinearGradient(0,0,N,N);tg.addColorStop(0,hexA(tint,.95));tg.addColorStop(.5,hexA(tint,.6));tg.addColorStop(1,hexA(tint,.9));g.fillStyle=tg;g.fillRect(0,0,N,N)}
   for(var r=R*.36;r<R*.985;r+=1.5){g.strokeStyle='rgba(255,255,255,'+((Math.round(r*3)%7===0)?.09:.03)+')';g.lineWidth=.7;g.beginPath();g.arc(R,R,r,0,7);g.stroke()}
   g.fillStyle='rgba(226,233,246,.55)';g.beginPath();g.arc(R,R,R*.34,0,7);g.arc(R,R,R*.15,0,7,true);g.fill();
   g.globalCompositeOperation='destination-out';g.beginPath();g.arc(R,R,R*.125,0,7);g.fill();g.globalCompositeOperation='source-over';g.restore();
   g.strokeStyle='rgba(255,255,255,.7)';g.lineWidth=2;g.beginPath();g.arc(R,R,R-2,0,7);g.stroke()}
  paint(null);if(d&&d.img){var im=new Image();im.decoding='async';im.onload=function(){try{paint(im)}catch(e){}};im.src=(window.LOCAL&&LOCAL[d.img])||d.img}
  c._f=1;c._2d=1;return c}
 function icons(){ICON={};ALL.concat(DISC,[GOLD,NOIR]).forEach(function(D){var s=D.still||D.sp;if(!s)return;try{var c=document.createElement('canvas');c.width=c.height=36;var g=c.getContext('2d'),f=s._f||1,z=36/f;g.drawImage(s,(36-z)/2,(36-z)/2,z,z);ICON[D.k]=c.toDataURL('image/png')}catch(e){}});if(ICON.ahabah)ICON.or=ICON.ahabah}
 function photos(){shotsOK=false;var L=DISC.concat(ALL.filter(function(x){return DISC.indexOf(x)<0}),[GOLD,NOIR]);L.forEach(function(D){D.sp=mkSpr(D.d)});spr=DISC[0].sp;icons();
  if(!(window.__gl&&__gl.shots))return;var i=0;
  (function next(){if(!window.PGON||i>=L.length){if(i>=L.length){shotsOK=true;icons();drawBoards()}return}var D=L[i++];
   __gl.shots([D.d],{still:420}).then(function(o){if(o&&o[D.k]&&o[D.k].still)D.still=D===NOIR?noirize(o[D.k].still):o[D.k].still;setTimeout(next,40)}).catch(function(){setTimeout(next,40)})})()}
 function framesFor(D){if(D.frames||D.fb||!(window.__gl&&__gl.shots)||!D.d)return;var N=20,acc=[],i=0,dd=D.d;D.fb=1;
  (function next(){if(!window.PGON){D.fb=0;return}var ang=[];for(var j=0;j<4&&i<N;j++,i++)ang.push(-i/N*6.2832);
   __gl.shots([D.d],{angles:ang,fsize:176}).then(function(o){if(D.d!==dd)return;var f=o&&o[D.k]&&o[D.k].frames;if(!f){D.fb=0;return}acc=acc.concat(D===NOIR?f.map(noirize):f);if(acc.length>=N){D.frames=acc;D.fb=0}else setTimeout(next,30)}).catch(function(){D.fb=0})})()}
 /* ---------- dessin du CD ---------- */
 function conic(g,a){return g.createConicGradient?g.createConicGradient(a,0,0):null}
 function cdImg(D,spin){if(D&&D.frames&&D.frames.length){var n=D.frames.length,a=((spin%6.2832)+6.2832)%6.2832;return {i:D.frames[Math.floor(a/6.2832*n)%n],r:0}}return {i:(D&&(D.still||D.sp))||spr,r:spin}}
 var FELC=[[-1.25,-.22],[-.5,-.06],[-.16,.2],[.3,.04],[.6,.3],[1.25,.18]];
 function felImg(g,im,z,r,spin,cr){var gap=Math.max(.7,r*.05);[-1,1].forEach(function(sd){g.save();g.rotate(spin);g.beginPath();FELC.forEach(function(q,i){if(i)g.lineTo(q[0]*r,q[1]*r);else g.moveTo(q[0]*r,q[1]*r)});g.lineTo(1.3*r,sd*1.4*r);g.lineTo(-1.3*r,sd*1.4*r);g.closePath();g.clip();
   g.translate(sd*gap*.25,sd*gap);g.rotate(cr-spin+sd*.035);g.drawImage(im,-z,-z,z*2,z*2);g.restore()});
  g.save();g.rotate(spin);g.beginPath();g.arc(0,0,r*.99,0,7);g.clip();g.lineJoin='round';g.beginPath();FELC.forEach(function(q,i){if(i)g.lineTo(q[0]*r,q[1]*r-gap);else g.moveTo(q[0]*r,q[1]*r-gap)});g.strokeStyle='rgba(255,255,255,.8)';g.lineWidth=Math.max(.5,r*.022);g.stroke();
  if(r>10){g.beginPath();g.moveTo(.3*r,.04*r-gap);g.lineTo(.42*r,-.34*r);g.lineTo(.66*r,-.58*r);g.moveTo(-.5*r,-.06*r+gap);g.lineTo(-.62*r,.36*r);g.strokeStyle='rgba(0,0,0,.7)';g.lineWidth=Math.max(.8,r*.03);g.stroke();g.strokeStyle='rgba(255,255,255,.55)';g.lineWidth=Math.max(.4,r*.012);g.stroke()}g.restore()}
 function drawCD(g,x,y,r,spin,t,D,shadow){var c=cdImg(D,spin),im=c.i;if(!im)return;var f=im._f||1,z=r/f;
  g.save();g.translate(x,y);
  if(shadow!==false){g.fillStyle='rgba(0,0,0,.42)';g.beginPath();g.ellipse(r*.16,r*.3,r*1.02,r*.94,0,0,7);g.fill();
   if(D===NOIR){var ng=g.createRadialGradient(0,0,r*.9,0,0,r*1.5);ng.addColorStop(0,'rgba(0,0,0,.7)');ng.addColorStop(.5,'rgba(6,4,14,.3)');ng.addColorStop(1,'rgba(0,0,0,0)');g.fillStyle=ng;g.beginPath();g.arc(0,0,r*1.5,0,7);g.fill();g.strokeStyle='rgba(120,112,160,'+(.25+.15*Math.sin(t*3))+')';g.lineWidth=Math.max(1,r*.05);g.beginPath();g.arc(0,0,r*1.08,0,7);g.stroke()}
   else{var lo=D&&D.p===1,gr=lo?1.45:2.1,hg=g.createRadialGradient(0,0,r*.85,0,0,r*gr);hg.addColorStop(0,hexA(glow,lo?.08:.26));hg.addColorStop(1,hexA(glow,0));g.fillStyle=hg;g.beginPath();g.arc(0,0,r*gr,0,7);g.fill()}}
  var fe=G&&G.fel&&G.felOn&&D===G.disc;
  if(fe)felImg(g,im,z,r,spin,c.r);else{g.save();g.rotate(c.r);g.drawImage(im,-z,-z,z*2,z*2);g.restore()}
  if(im._2d&&!fe){g.save();g.beginPath();g.arc(0,0,r*.975,0,7);g.arc(0,0,r*.13,0,7,true);g.clip();var h=(t*45+x*.6+y*.35)%360,cg=conic(g,t*.45+x*.012);
   if(cg){for(var i=0;i<=6;i++)cg.addColorStop(i/6,'hsla('+((h+i*60)%360)+',100%,62%,.5)');g.globalCompositeOperation='overlay';g.fillStyle=cg;g.fillRect(-r,-r,r*2,r*2)}g.restore()}
  g.restore()}
 /* ---------- interface ---------- */
 function build(){
  root=document.createElement('div');root.id='pong';root.setAttribute('role','dialog');root.setAttribute('aria-label','Mini-jeu : yuu contre toi');
  root.innerHTML='<div class="pg-fit"><div class="pg-scr"><canvas></canvas>'+
   '<div class="pg-ui" data-v="title"><p class="pg-small pg-test" hidden></p><canvas class="pg-cd"></canvas><p class="pg-dn"></p><div class="pg-logo"><span class="pg-p2">YUU</span><i>VS</i><span class="pg-p1">YOU</span></div><p class="pg-blink pg-go"></p><div class="pg-board"></div><p class="pg-small pg-help"></p></div>'+
   '<div class="pg-ui pg-dropui" data-v="drop" hidden><canvas class="pg-fx"></canvas><p class="pg-small pg-dtt">TIRAGE DU DISQUE</p><canvas class="pg-cd pg-cd2"></canvas><p class="pg-dname"></p><p class="pg-drar"></p><p class="pg-small pg-dbon"></p></div>'+
   '<div class="pg-ui" data-v="over" hidden><div class="pg-logo"><span class="pg-s">GAME OVER</span></div><p>SCORE <span class="pg-sc"></span></p><p class="pg-small pg-stat"></p>'+
    '<div class="pg-q"><p class="pg-blink">TOP 10 !</p><p class="pg-small">TES INITIALES</p><div class="pg-ini"></div><p class="pg-small pg-qerr" aria-live="polite"></p><button class="pg-btn pg-ok" type="button">VALIDER</button></div>'+
    '<div class="pg-res"><p class="pg-small pg-msg"></p><div class="pg-board"></div><div class="pg-row"><button class="pg-btn pg-again" type="button">REJOUER</button><button class="pg-btn alt pg-quit" type="button">QUITTER</button></div></div></div>'+
   '<div class="pg-crt"></div></div></div><div class="pg-top"><button type="button" class="pg-snd" aria-label="Son">♪</button><button type="button" class="pg-x" aria-label="Fermer">✕</button></div>';
  document.body.appendChild(root);fit=root.querySelector('.pg-fit');scr=root.querySelector('.pg-scr');cv=scr.querySelector('canvas');cx=cv.getContext('2d');
  ui.title=root.querySelector('[data-v=title]');ui.drop=root.querySelector('[data-v=drop]');ui.over=root.querySelector('[data-v=over]');ui.cd=root.querySelector('.pg-cd');ui.cdx=ui.cd.getContext('2d');ui.cd2=root.querySelector('.pg-cd2');ui.cdx2=ui.cd2.getContext('2d');
  ui.fx=root.querySelector('.pg-fx');ui.fxx=ui.fx.getContext('2d');ui.dtt=root.querySelector('.pg-dtt');ui.dn=root.querySelector('.pg-dn');ui.dname=root.querySelector('.pg-dname');ui.drar=root.querySelector('.pg-drar');ui.dbon=root.querySelector('.pg-dbon');
  ui.q=root.querySelector('.pg-q');ui.res=root.querySelector('.pg-res');ui.ini=root.querySelector('.pg-ini');ui.ok=root.querySelector('.pg-ok');ui.msg=root.querySelector('.pg-msg');
  ui.go=root.querySelector('.pg-go');ui.help=root.querySelector('.pg-help');ui.snd=root.querySelector('.pg-snd');
  ui.go.textContent=TOUCH?'TOUCHE POUR JOUER':'CLIQUE POUR JOUER';ui.help.textContent=TOUCH?'GLISSE LE DOIGT POUR BOUGER':'SOURIS OU FLÈCHES · P = PAUSE';
  for(var i=0;i<3;i++){var s=document.createElement('div');s.className='pg-slot';s.innerHTML='<button type="button" data-d="1" aria-label="Lettre suivante">▲</button><b></b><button type="button" data-d="-1" aria-label="Lettre précédente">▼</button>';s.dataset.i=i;ui.ini.appendChild(s)}
  ui.ini.addEventListener('click',function(e){var s=e.target.closest('.pg-slot');if(!s)return;cur=+s.dataset.i;var b=e.target.closest('button');if(b)turn(+b.dataset.d);else iniDraw()});
  ui.ok.addEventListener('click',function(){submit()});
  root.addEventListener('click',function(e){var b=e.target.closest&&e.target.closest('[data-bc]');if(!b)return;e.stopPropagation();BC=String(b.dataset.bc||'');drawBoards();try{if(window.SND&&SND.game)SND.game('sel')}catch(x){}});
  root.querySelector('.pg-again').addEventListener('click',function(){start()});
  root.querySelector('.pg-quit').addEventListener('click',function(){close()});
  root.querySelector('.pg-x').addEventListener('click',function(){close()});
  ui.snd.addEventListener('click',function(){try{SND.toggle()}catch(e){}sndUi();if(!window.SNDON)muStop(true);else if(st==='play'&&G){if(!MU||!MU.src)muSet(G.disc);muPlay()}});
  /* souris bloquée dans le jeu pendant la partie (ordinateur) : elle ne peut plus sortir de l'écran ; Échap la libère (pause) */
  var FINE=matchMedia('(pointer:fine)').matches,plk=function(){return document.pointerLockElement===fit},LKW=false;
  window.__pgLock=function(on){try{if(on){if(FINE&&fit.requestPointerLock&&!plk()){var p=fit.requestPointerLock();if(p&&p.catch)p.catch(function(){})}}else if(plk())document.exitPointerLock()}catch(e){}};
  document.addEventListener('pointerlockchange',function(){var l=plk();if(l){LKW=true;fit.style.cursor='none'}else{fit.style.cursor='';if(LKW&&st==='play'&&!paused&&G){paused=true;try{muFade(0,.3)}catch(e){}ban('PAUSE','CLIQUE POUR REPRENDRE',cA,1.6)}LKW=false}});
  fit.addEventListener('pointermove',function(e){if(plk()){ptrX=clamp((ptrX==null?P.x:ptrX)+(e.movementX||0)/sc,P.w/2,LW-P.w/2)}else ptrX=lx(e.clientX)});
  fit.addEventListener('pointerdown',function(e){if(!plk())ptrX=lx(e.clientX);if(e.target.closest('button'))return;if(st==='title')start();else if(st==='drop'){if(revOn&&revT>.4){go();__pgLock(true)}}else if(st==='play'){if(paused){paused=false;muPlay()}__pgLock(true)}});
  root.addEventListener('touchmove',function(e){e.preventDefault()},{passive:false});
  root.addEventListener('contextmenu',function(e){e.preventDefault()})}
 function sndUi(){if(ui.snd)ui.snd.classList.toggle('off',!window.SNDON)}
 function lx(x){if(!cvR)cvR=cv.getBoundingClientRect();return (x-cvR.left)/sc}
 function show(v){if(v!=='play'&&window.__pgLock)__pgLock(false);ui.title.hidden=v!=='title';ui.drop.hidden=v!=='drop';ui.over.hidden=v!=='over';root.classList.toggle('pg-play',v==='play')}
 function layout(){if(!root)return;var r=fit.getBoundingClientRect(),vw=Math.max(200,r.width),vh=Math.max(200,r.height);
  sc=Math.min(vw/LW,vh/LH);dpr=Math.min(2,window.devicePixelRatio||1);var w=Math.floor(LW*sc),h=Math.floor(LH*sc);
  scr.style.width=w+'px';scr.style.height=h+'px';cv.width=Math.round(w*dpr);cv.height=Math.round(h*dpr);root.style.setProperty('--u',sc+'px');
  var cs=Math.round(92*sc*dpr);ui.cd.width=ui.cd.height=cs;var c2=Math.round(150*sc*dpr);ui.cd2.width=ui.cd2.height=c2;ui.fx.width=cv.width;ui.fx.height=cv.height;mkBg();cvR=null}
 function mkBg(){crc=null;bgc=document.createElement('canvas');bgc.width=cv.width;bgc.height=cv.height;var g=bgc.getContext('2d');g.setTransform(sc*dpr,0,0,sc*dpr,0,0);
  g.fillStyle='#05040b';g.fillRect(0,0,LW,LH);
  var t1=g.createLinearGradient(0,0,0,LH/2);t1.addColorStop(0,hexA(cA,.14));t1.addColorStop(1,hexA(cA,0));g.fillStyle=t1;g.fillRect(0,0,LW,LH/2);
  var t2=g.createLinearGradient(0,LH,0,LH/2);t2.addColorStop(0,hexA(cP,.14));t2.addColorStop(1,hexA(cP,0));g.fillStyle=t2;g.fillRect(0,LH/2,LW,LH/2);
  g.fillStyle=nv?'rgba(190,196,220,.07)':gm?'rgba(255,214,90,.09)':'rgba(255,255,255,.05)';for(var y=34;y<LH-30;y+=12)for(var x=6;x<LW;x+=12)g.fillRect(x,y,1,1);
  g.fillStyle=nv?'rgba(200,206,226,.38)':gm?'rgba(255,214,90,.45)':'rgba(255,255,255,.24)';for(var x2=4;x2<LW;x2+=16)g.fillRect(x2,LH/2-1.5,8,3);
  g.fillStyle='rgba(255,255,255,.12)';g.fillRect(0,28,2,LH-56);g.fillRect(LW-2,28,2,LH-56);
  g.fillStyle='rgba(255,255,255,.09)';g.fillRect(0,28,LW,1);g.fillRect(0,LH-29,LW,1)}
 function BOOM(){return !!(G&&G.boom)}
 function crkCol(){return nv?'210,214,230':gm?'255,226,150':'230,226,255'}
 function walk(x,y,a,L,j){var p=[[x,y]],s=0;while(s<L){var st=rnd(8,17);a+=rnd(-j,j);x+=Math.cos(a)*st;y+=Math.sin(a)*st;s+=st;p.push([x,y]);if(x<-10||x>LW+10||y<-10||y>LH+10)break}return p}
 function web(cx,cy,R,n,lv){var rays=[];for(var i=0;i<n;i++){var a=i/n*6.2832+rnd(-.22,.22),p=walk(cx,cy,a,R*rnd(.55,1.2),.1);CRK.push({p:p,w:1.1,a:.62});rays.push(p);
   if(Math.random()<.35){var k=p[Math.floor(p.length*rnd(.3,.8))];if(k)CRK.push({p:walk(k[0],k[1],a+rnd(-.9,.9),R*rnd(.2,.45),.14),w:.7,a:.42})}}
  for(var r=1;r<=2+(lv>4?1:0);r++){var f=r/(3+(lv>4?1:0));for(var q=0;q<n;q++){var A=rays[q],Bq=rays[(q+1)%n],ia=A[Math.floor((A.length-1)*f)],ib=Bq[Math.floor((Bq.length-1)*f)];if(ia&&ib&&Math.random()<.85)CRK.push({p:[ia,[(ia[0]+ib[0])/2+rnd(-5,5),(ia[1]+ib[1])/2+rnd(-5,5)],ib],w:.85,a:.46});
    if(lv>=5&&ia&&ib&&Math.random()<.12+lv*.03){var c0=A[Math.max(0,Math.floor((A.length-1)*(f-.3)))]||[cx,cy];CRK.push({sh:[c0,ia,ib],a:.22+lv*.02})}}}}
 function mkCrk(){if(!cv)return;crc=document.createElement('canvas');crc.width=cv.width;crc.height=cv.height;var g=crc.getContext('2d');g.setTransform(sc*dpr,0,0,sc*dpr,0,0);g.lineJoin='round';g.lineCap='round';var C=crkCol();
  CRK.forEach(function(c){if(c.sh){g.fillStyle='rgba(0,0,0,'+c.a+')';g.beginPath();g.moveTo(c.sh[0][0],c.sh[0][1]);g.lineTo(c.sh[1][0],c.sh[1][1]);g.lineTo(c.sh[2][0],c.sh[2][1]);g.closePath();g.fill();g.strokeStyle='rgba('+C+','+(c.a*.9)+')';g.lineWidth=.6;g.stroke()}});
  CRK.forEach(function(c){if(!c.p)return;g.beginPath();c.p.forEach(function(q,i){if(i)g.lineTo(q[0]+.9,q[1]+.9);else g.moveTo(q[0]+.9,q[1]+.9)});g.strokeStyle='rgba(0,0,0,'+(c.a*.8)+')';g.lineWidth=c.w+1.1;g.stroke();
   g.beginPath();c.p.forEach(function(q,i){if(i)g.lineTo(q[0],q[1]);else g.moveTo(q[0],q[1])});g.strokeStyle='rgba('+C+','+c.a+')';g.lineWidth=c.w;g.stroke()})}
 function crackUp(lv){var cx=rnd(50,LW-50),cy=rnd(70,LH-70);
  if(lv<10){web(cx,cy,60+lv*20,5+Math.ceil(lv*.7),lv);for(var i=0;i<Math.max(0,lv-3);i++){var e=Math.floor(rnd(0,4)),x=e===0?0:e===1?LW:rnd(0,LW),y=e===2?0:e===3?LH:rnd(0,LH);CRK.push({p:walk(x,y,Math.atan2(cy-y,cx-x)+rnd(-.5,.5),rnd(160,420),.08),w:.95,a:.5})}
   mkCrk();flC='#ffffff';flT=.3+lv*.03;shake=Math.min(1,.45+lv*.06);burst(cx,cy,'#ffffff',18+lv*4,-1);burst(cx,cy,'#ffffff',10+lv*3,1);rings.push({x:cx,y:cy,r:6,a:.8,v:320,c:'#ffffff'});
   ban(String(lv)+'00 000',(lv>=8?'L’ÉCRAN NE TIENT PLUS':lv>=5?'L’ÉCRAN SE BRISE':'L’ÉCRAN SE FISSURE')+' · ÇA SE CORSE',cP,1.6);snd('glitch');snd('wall')}
  else{G.boom=true;G.bt=0;CRK=[];crc=null;flC='#ffffff';flT=1.6;shake=1.3;for(var k=0;k<7;k++)burst(rnd(40,LW-40),rnd(60,LH-60),k%2?'#ffffff':cP,40,k%2?1:-1);for(var r=0;r<5;r++)rings.push({x:LW/2,y:LH/2,r:10+r*30,a:1,v:520+r*90,c:'#ffffff'});
   if(root)root.classList.add('pg-boom');ban('1 000 000','L’ÉCRAN A EXPLOSÉ',cP,2.6);snd('gold');snd('win')}
  if(MU){try{MU.playbackRate=Math.min(1.8,1+.07*lv)}catch(e){}}}
 function boomBg(g,t){var k=Math.min(1,G.bt/1.2);g.setTransform(sc*dpr,0,0,sc*dpr,0,0);var rg=g.createRadialGradient(LW/2,LH/2,10,LW/2,LH/2,LH*.75);rg.addColorStop(0,'#ffffff');rg.addColorStop(.55,'#fbfaff');rg.addColorStop(1,'#e9e6f4');g.globalAlpha=k;g.fillStyle=rg;g.fillRect(0,0,LW,LH);
  g.save();g.translate(LW/2,LH/2);g.rotate(t*.06);for(var i=0;i<14;i++){g.rotate(6.2832/14);var gr=g.createLinearGradient(0,0,0,-LH);gr.addColorStop(0,'rgba(255,255,255,0)');gr.addColorStop(.25,'rgba(255,250,235,.55)');gr.addColorStop(1,'rgba(255,255,255,0)');g.fillStyle=gr;g.beginPath();g.moveTo(0,0);g.lineTo(-14-6*Math.sin(t*1.3+i),-LH);g.lineTo(14+6*Math.sin(t*1.3+i),-LH);g.closePath();g.fill()}g.restore();
  g.fillStyle='rgba(120,110,170,.08)';for(var y=34;y<LH-30;y+=12)for(var x=6;x<LW;x+=12)g.fillRect(x,y,1,1);g.fillStyle='rgba(90,80,140,.22)';for(var x2=4;x2<LW;x2+=16)g.fillRect(x2,LH/2-1.5,8,3);g.globalAlpha=1}
 function setCol(D){gm=!!(D&&D.p===4);nv=D===NOIR;cP=D?D.col:'#ff4d6d';cA=nv?'#c3c8d8':gm?'#ffe9a8':'#a99bff';glow=nv?'#6a6290':gm?'#ffd65a':okC([D&&D.d&&D.d.tint],'#ffffff');if(root){root.style.setProperty('--pgP',cP);root.style.setProperty('--pgA',cA);root.style.setProperty('--pgG',hexA(glow,.2))}if(bgc)mkBg()}
 /* ---------- classement ---------- */
 function locGet(){try{var a=JSON.parse(localStorage.getItem('yuu-pong-top')||'[]');return Array.isArray(a)?a:[]}catch(e){return[]}}
 function locSet(a){try{localStorage.setItem('yuu-pong-top',JSON.stringify(a))}catch(e){}}
 function online(){return typeof isSA==='function'?isSA():!window.claude}
 function catOf(k){k=String(k||'');return k==='or'||k==='ahabah'?'myth':k}
 function tabOf(k){k=catOf(k);return k==='noir'?'myth':k}
 function grp(L){var o={};L.forEach(function(e){var c=catOf(e.c);if(c)(o[c]=o[c]||[]).push(e)});return o}
 function okCats(c){var o={};if(c&&typeof c==='object')Object.keys(c).forEach(function(k){if(/^[a-z0-9_-]{1,24}$/.test(k)&&Array.isArray(c[k]))o[k]=c[k]});return o}
 function load(){src='load';drawBoards();
  if(!online()){board=locGet();cats=grp(board);src='local';drawBoards();return}
  fetch(API,{cache:'no-store'}).then(function(r){if(!r.ok)throw 0;return r.json()}).then(function(j){if(!j||!Array.isArray(j.top))throw 0;board=j.top;cats=j.cats?okCats(j.cats):grp(board);src='net';drawBoards()}).catch(function(){board=locGet();cats=grp(board);src='off';drawBoards()})}
 function tabsHTML(){var T=[['','TOUS','']].concat(ALL.map(function(x){var d=x.d||{};return [x.k,d.mys?'?':plain(String(d.n||x.k)).split(' ')[0],ic(x.k)]}),[['myth','MYTHIQUE',ic('ahabah')+ic('noir')]]);
  if(BC&&!T.some(function(t){return t[0]===BC}))BC='';
  return '<div class="pg-tabs" role="tablist">'+T.map(function(t){return '<button type="button" role="tab" class="pg-tab'+(t[0]===BC?' on':'')+(t[0]==='myth'?' myth':'')+'" aria-selected="'+(t[0]===BC)+'" data-bc="'+esc(t[0])+'">'+t[2]+esc(t[1])+'</button>'}).join('')+'</div>'}
 function ic(k,fe){k=String(k||'');var c='pg-ic'+(k==='or'||k==='ahabah'?' pg-gold':k==='noir'?' pg-noir':'')+(fe?' pg-fel':''),u=Object.prototype.hasOwnProperty.call(ICON,k)?String(ICON[k]):'';return /^data:image\/png;base64,[A-Za-z0-9+\/=]+$/.test(u)?'<i class="'+c+'" style="background-image:url('+u+')"></i>':'<i class="'+c+'"></i>'}
 function boardHTML(){var h='<h3>'+(src==='net'?'CLASSEMENT MONDIAL':src==='off'?'HORS LIGNE · SCORES DE CET APPAREIL':'SCORES DE CET APPAREIL')+'</h3>';
  if(src==='load')return h+'<p class="pg-small">CHARGEMENT...</p>';
  h+=tabsHTML();
  if(BC==='myth'){var col=function(k,icn){var M=okB(cats[k]);return '<div class="pg-mc"><p class="pg-mh">'+ic(icn)+'</p>'+(M.length?'<ol'+olC(M.slice(0,10))+'>'+M.slice(0,10).map(function(e,i){return '<li class="'+(e.me||isMe(e)?'me ':'')+(i<5?'pg-r'+(i+1):'')+'"><span>'+(i+1)+'.</span><span><b class="pg-nm">'+esc(e.n)+'</b></span><span>'+pB(+e.s||0)+'</span></li>'}).join('')+'</ol>':'<p class="pg-small">PERSONNE<br>ENCORE.</p>')+'</div>'};return h+'<div class="pg-m2">'+col('myth','ahabah')+col('noir','noir')+'</div>'}
  var L=okB(BC?cats[BC]:board);
  if(!L.length)return h+'<p class="pg-small">'+(BC?'PERSONNE SUR CE DISQUE.':'PERSONNE ENCORE.')+'<br>SOIS LE PREMIER !</p>';
  return h+'<ol'+olC(L.slice(0,10))+'>'+L.slice(0,10).map(function(e,i){return '<li class="'+(e.me||isMe(e)?'me ':'')+(i<5?'pg-r'+(i+1):'')+'"><span>'+(i+1)+'.</span><span>'+ic(e.c,e.f)+'<b class="pg-nm">'+esc(e.n)+'</b></span><span>'+pB(+e.s||0)+'</span></li>'}).join('')+'</ol>'}
 function myBest(){try{var o=JSON.parse(localStorage.getItem('yuu-pong-best')||'null');return o&&o.s>0?o:null}catch(e){return null}}
 function myN(){try{return localStorage.getItem('yuu-pong-n')||''}catch(e){return ''}}
 function isMe(e){var b=myBest(),n=myN();return !!(b&&n&&e.n===n&&e.s===b.s)}
 function meHTML(){var b=myBest();if(!b)return '';return '<p class="pg-me'+(NEWREC?' new':'')+'">'+(NEWREC?'NOUVEAU RECORD ! ':'TON RECORD : ')+ic(b.c)+p6(b.s)+'</p>'}
 function drawBoards(){var OB=okB(board);HI=OB[0]?OB[0].s:0;locGet().forEach(function(e){if(e.s>HI)HI=e.s});if(!root)return;var h=meHTML()+boardHTML();root.querySelectorAll('.pg-board').forEach(function(b){b.innerHTML=h})}
 function hiScore(){return Math.max(HI,G?G.score:0)}
 function qual(){if(!(G&&G.score>0&&src!=='load'))return false;var c=catOf(G.ck||G.disc.k),L=cats[c]||[];return board.length<10||G.score>board[Math.min(9,board.length-1)].s||(!!c&&(L.length<10||G.score>L[Math.min(9,L.length-1)].s))}
 function iniDraw(){ui.ini.querySelectorAll('.pg-slot').forEach(function(s,i){s.classList.toggle('on',i===cur);s.querySelector('b').textContent=CH[ini[i]]})}
 function turn(d){ini[cur]=(ini[cur]+d+CH.length)%CH.length;iniDraw();if(window.SND&&SND.game)SND.game('sel')}
 function submit(){if(st!=='enter')return;var n=ini.map(function(i){return CH[i]}).join('');var qe=root&&root.querySelector('.pg-qerr');if(badN(n)){try{snd('lose')}catch(x){}if(qe){qe.textContent='NOM INTERDIT · CHOISIS-EN UN AUTRE';qe.style.color='#ff4d6d'}return}if(qe)qe.textContent='';try{localStorage.setItem('yuu-pong-n',n)}catch(e){}
  var e={n:n,s:G.score,h:G.hits,g:G.goals,lv:G.lv,t:Math.round(G.dur*1000),c:G.ck||G.disc.k,m:G.fx.m,x:G.sx||0,y:G.sg||0,f:G.fel?1:0},L=locGet();L.forEach(function(x){delete x.me});L.push({n:n,s:e.s,c:e.c,f:e.f||undefined,d:new Date().toISOString().slice(0,10),me:true});L.sort(function(a,b){return b.s-a.s});L=L.slice(0,100);locSet(L);
  if(window.SND&&SND.game)SND.game('ok');
  if(src!=='net'||!G.tok){var wasNet=src==='net';board=L;cats=grp(L);if(L.indexOf(L.filter(function(x){return x.me})[0])>=10)BC=tabOf(e.c);src=src==='off'||wasNet?'off':'local';res(wasNet?'PARTIE HORS LIGNE :<br>SCORE GARDÉ SUR CET APPAREIL.':'');return}e.tok=G.tok;
  st='send';ui.ok.disabled=true;ui.ok.textContent='ENVOI...';
  fetch(API,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(e)}).then(function(r){return r.json().catch(function(){return{}}).then(function(j){if(!r.ok)throw j;return j})})
   .then(function(j){board=Array.isArray(j.top)?j.top:board;if(j.cats)cats=okCats(j.cats);rank=parseInt(j.rank,10)||0;crank=parseInt(j.crank,10)||0;if(rank>10&&crank>0&&crank<=10)BC=tabOf(e.c);res(rank>10?'TON RANG : '+rank+(crank>0?'<br>N°'+crank+' AVEC CE DISQUE':''):'')})
   .catch(function(j){res(j&&j.error==='trop'?'DOUCEMENT ! RÉESSAIE DANS UN INSTANT.':'CLASSEMENT INDISPONIBLE.<br>SCORE GARDÉ SUR CET APPAREIL.',true)})}
 function res(m,err){st='res';ui.q.hidden=true;ui.res.hidden=false;ui.msg.innerHTML=m||'';ui.msg.classList.toggle('pg-err',!!err);ui.msg.hidden=!m;drawBoards();try{root.querySelector('.pg-again').focus({preventScroll:true})}catch(e){}}
 function showOver(){bans=[];show('over');root.querySelector('.pg-sc').textContent=p6(G.score);root.querySelector('.pg-stat').textContent=G.disc.name+(G.fel?' FÊLÉ':'')+' · NIVEAU '+G.lv+' · '+G.hits+' RENVOI'+(G.hits>1?'S':'')+(G.beat?(G.eev?' · '+OPN[G.eev].n+' '+OPN[G.eev].v:' · YUU VAINCU'):'')+(G.eev&&!G.beat?' · CONTRE '+OPN[G.eev].n:'');
  ui.ok.disabled=false;ui.ok.textContent='VALIDER';
  if(G.test){res('PARTIE TEST : SCORE NON ENREGISTRÉ.');return}
  var mb=myBest();NEWREC=G.score>0&&(!mb||G.score>mb.s);if(NEWREC){try{localStorage.setItem('yuu-pong-best',JSON.stringify({s:G.score,c:G.ck||G.disc.k,d:new Date().toISOString().slice(0,10)}))}catch(e){}if(window.SND&&SND.game)SND.game('win');var sx=root.querySelector('.pg-stat');if(sx)sx.textContent+=' · NOUVEAU RECORD !'}drawBoards();
  if(qual()){st='enter';ui.q.hidden=false;ui.res.hidden=true;var n='';try{n=localStorage.getItem('yuu-pong-n')||''}catch(e){}ini=[0,0,0];for(var i=0;i<3;i++){var k=CH.indexOf((n[i]||'A').toUpperCase());ini[i]=k<0?0:k}cur=0;iniDraw()}
  else res(G.score>0?'PAS ENCORE DANS LE TOP 10.':'')}
 /* ---------- partie ---------- */
 var WAITG=false;
 /* anti-triche : en ligne, le tirage (disque, fêlure, éclat, adversaire) est fait par le serveur, qui signe un ticket ; sans ticket, le score reste sur l'appareil */
 function start(){if(WAITG)return;if(FORCE||PRESC||!online()){start0(null);return}WAITG=true;var done=false,fin=function(j){if(done)return;done=true;clearTimeout(tm);WAITG=false;start0(j&&typeof j.tok==='string'&&typeof j.c==='string'?j:null)},tm=setTimeout(function(){fin(null)},3500);
  try{fetch(API,{method:'POST',headers:{'Content-Type':'application/json'},body:'{"go":1}',cache:'no-store'}).then(function(r){return r.ok?r.json():null}).then(fin,function(){fin(null)})}catch(e){fin(null)}}
 function byK(k){return k==='ahabah'?GOLD:k==='noir'?NOIR:ALL.filter(function(x){return x.k===k})[0]||null}
 function start0(R){var D=forced()||(R&&byK(R.c))||draw1(),rar=function(k,d){var n=parseInt(cfg()[k],10);n=isFinite(n)&&n>0?n:d;return Math.random()<1/n},FEL=FORCE==='fele'||(R?!!R.f:(!FORCE&&rar('fel',2000))),EEV=FORCE==='eeveie'||FORCE==='taku'?FORCE:FORCE?false:R?(R.o==='eeveie'||R.o==='taku'?R.o:false):rar('eev',200)?'eeveie':rar('taku',200)?'taku':false;NEWREC=false;CRK=[];crc=null;if(root)root.classList.remove('pg-boom');G={crk:0,boom:false,bt:0,score:0,goals:0,lost:0,lives:lives(),lv:1,hits:0,rally:0,beat:false,win:winG(),dur:0,disc:D,fx:fx(D),test:!!(FORCE||PRESC),eev:EEV,tok:R&&!FORCE&&!PRESC&&byK(R.c)===D?R.tok:''};G.shield=G.fx.shield?1:0;G.ck=D.k;if(FEL){G.fel=true;G.fx=Object.assign({},G.fx,{m:G.fx.m*10});G.lives=1}G.sht=FORCE==='eclat'?2.5:R?(R.e?rnd(8,40):0):(!FORCE&&rar('ecl',2000)?rnd(8,40):0);G.shd=[];G.sx=0;G.sg=0;muSet(D);
  window.PGDK=0;framesFor(D);paused=false;trail=[];parts=[];bans=[];P.x=A.x=LW/2;P.vx=A.vx=0;ptrX=null;keys.l=keys.r=false;
  P.w=Math.round(80*G.fx.pw);B.live=false;B.wait=99;B.x=LW/2;B.y=LH/2;
  setCol(DISC[0]);st='drop';dropT=0;dropI=Math.floor(Math.random()*DISC.length);dropAt=0;glT=0;glD=0;revOn=false;revT=0;rfx=[];rings=[];
  var n=DISC.length,tg=isMy(D)?Math.floor(Math.random()*n):DISC.indexOf(D),stp=n*3+((tg-dropI+n)%n);plan=[];for(var i=1;i<=stp;i++)plan.push(2.1*Math.pow(i/stp,2.2));
  show('drop');ui.dtt.textContent='TIRAGE DU DISQUE';ui.dname.textContent='';ui.drar.textContent='';ui.dbon.textContent='';ui.drar.className='pg-drar';snd('coin')}
 function reveal(){if(revOn)return;revOn=true;revT=0;var D=G.disc,T=D.p,R=RAR[T];dropAt=dropT;
  try{setCol(D);var r1=ui.cd2.getBoundingClientRect(),r0=scr.getBoundingClientRect();cdX=(r1.left+r1.width/2-r0.left)/sc;cdY=(r1.top+r1.height/2-r0.top)/sc;cdR=r1.width*.435/sc}catch(e){}
  ui.dtt.textContent=T===4?'ERREUR DE LECTURE… TROUVÉ :':'TU AS TIRÉ';ui.dname.textContent=D.name;ui.drar.textContent=R[0]+(T===4?' · '+fmtP(G.ck==='ahabah'?ahaP():noirP())+'%':' · '+fmtP(D.pc)+'%');ui.drar.style.color=T===4&&nv?'#c9cfe0':R[1];ui.drar.className='pg-drar pg-r'+T;
  ui.dbon.textContent=T===4&&nv?'×10 POINTS · ULTRA DUR · RAQUETTE ÉTROITE · AUCUN BOUCLIER':T===4?'×5 POINTS · BOUCLIER D\'OR · TIR SURPUISSANT · RAQUETTE LARGE':T===3?'×3 POINTS · TIR SURPUISSANT · RAQUETTE LARGE':T===2?'×2 POINTS · TIR PUISSANT':'×1 POINT';
    var nP=[0,16,40,70,130][T];for(var i=0;i<nP;i++){var a=rnd(0,6.2832),sp=rnd(60,180+T*70),co=T===4&&Math.random()<.7;rfx.push({x:cdX,y:cdY,vx:Math.cos(a)*sp,vy:Math.sin(a)*sp-(co?120:0),gr:co?260:T===3?-20:0,l:rnd(.8,1.6+T*.3),m:1.6+T*.3,c:T===4?(nv?(Math.random()<.5?'#c9cfe0':'#24242c'):(Math.random()<.5?'#ffd65a':'#fff1c2')):T===3?(Math.random()<.6?'#ff2a4a':'#160006'):T===2?(Math.random()<.6?'#6fb6ff':'#ffffff'):(Math.random()<.5?cP:'#ffffff'),z:co?rnd(4,7):rnd(2,3+T),coin:co,rot:rnd(0,6),vr:rnd(4,10)})}
  dropShk=[0,0,.15,.5,.35][T];window.PGDK=D.d&&D.d.mys?1:0;
  snd(T===4?'gold':T===3?'win':T===2?'rare':'goal');if(T===3)setTimeout(function(){snd('lose')},250)}
 function felCrack(){G.felOn=true;try{ui.dtt.textContent='CRAC… IL EST FÊLÉ !';ui.dname.textContent=G.disc.name;ui.drar.textContent='FÊLÉ · 1 CHANCE SUR '+(parseInt(cfg().fel,10)||2000);ui.drar.style.color='#ffb38a';ui.drar.className='pg-drar pg-r3';ui.dbon.textContent='×'+G.fx.m+' POINTS · UNE SEULE VIE'}catch(e){}
  dropShk=.8;for(var i=0;i<34;i++){var a=rnd(0,6.2832),sp=rnd(80,300);rfx.push({x:cdX,y:cdY,vx:Math.cos(a)*sp,vy:Math.sin(a)*sp,gr:300,l:rnd(.5,1.1),m:1.1,c:Math.random()<.6?'#ffffff':'#ffb38a',z:rnd(2,4),coin:false,rot:0,vr:0})}snd('lose');snd('glitch')}
 function go(){if(st!=='drop')return;if(PRESC&&G){G.score=PRESC;PRESC=0}try{if(!revOn)reveal()}catch(e){}if(G.fel&&!G.felOn)try{felCrack()}catch(e){}st='play';muPlay();show('play');try{ui.cd2.style.transform=''}catch(e){}serve(false,G.eev?2.6:1.2);if(G.eev){G.eevIn=true;G.eevS=null;G.eevLand=0;try{muSet(G.disc);muPlay()}catch(e){}var gE=G;setTimeout(function(){if(G!==gE||!MUon||G.chip||!mwant())return;var ok=MU&&!MU.paused&&MU.readyState>=3&&MU.currentTime>.3;if(!ok){G.chip=true;try{MU.pause()}catch(e){}chipStart(G.eev)}},3500);snd('glitch');shake=Math.max(shake,5);setTimeout(function(){if(G&&G.eev&&st==='play'){var OP=OPN[G.eev]||OPN.eeveie;ban(OP.n+' ENTRE EN JEU','1 CHANCE SUR '+(parseInt(cfg()[OP.k],10)||200)+' · LA MUSIQUE CHANGE',OP.c[0],2.2)}},650)}ban('PRÊT ?',G.fel?'DISQUE FÊLÉ · ×'+G.fx.m+' · UNE SEULE VIE':G.disc.name+(G.fx.m>1?' · ×'+G.fx.m:''),cP,G.fel?1.6:1.1)}
 function serve(down,w){B.x=LW/2;B.y=LH/2;B.vx=B.vy=0;B.live=false;B.wait=w||1.1;B.dir=down?1:-1;trail=[];if(G)G.rally=0}
 function launch(){var lv=lvl(),sp=v0(lv),a=rnd(-.42,.42);B.base=sp;B.vx=Math.sin(a)*sp;B.vy=B.dir*Math.cos(a)*sp;B.live=true;var k=skill(lv);
  if(B.dir<0){A.react=k.react;A.err=rnd(-1,1)*k.err+rnd(-1,1)*A.w*.25}else{var kd=skill(4);P.react=kd.react;P.err=rnd(-1,1)*kd.err}}
 function predict(ty){if(Math.abs(B.vy)<1)return null;var t=(ty-B.y)/B.vy;if(t<0)return null;var x=B.x+B.vx*t,L=B.r,w=LW-2*B.r,u=((x-L)%(2*w)+2*w)%(2*w);return L+(u<=w?u:2*w-u)}
 function ai(p,top,dt,k){var tw=top?B.vy<0:B.vy>0,tg;
  if(B.live&&tw){if(p.react>0){p.react-=dt;tg=p.x}else{var px=predict(top?A_Y+PH/2+B.r:P_Y-PH/2-B.r);tg=(px==null?B.x:px)+p.err}}
  else tg=LW/2+(B.x-LW/2)*.3;
  var v=clamp((tg-p.x)*9,-k.spd,k.spd);p.vx=v;p.x=clamp(p.x+v*dt,p.w/2,LW-p.w/2)}
 function me(dt){var tx=P.x;if(keys.l||keys.r){tx=P.x+((keys.r?1:0)-(keys.l?1:0))*900*dt;ptrX=null}else if(ptrX!=null)tx=ptrX;
  var nx=clamp(P.x+clamp(tx-P.x,-2400*dt,2400*dt),P.w/2,LW-P.w/2);P.vx=P.vx*.5+((nx-P.x)/Math.max(dt,1e-3))*.5;P.x=nx}
 function hit(p,top){var off=clamp((B.x-p.x)/(p.w/2+B.r),-1,1),a=clamp(off*1.05+clamp(p.vx/1800,-.28,.28),-1.15,1.15),lv=lvl();
  B.base=Math.min(vmax(lv),B.base*1.045);var sp=B.base*(!top&&G&&st==='play'?G.fx.sh:1);
  B.vx=Math.sin(a)*sp;B.vy=(top?1:-1)*Math.cos(a)*sp;B.y=top?A_Y+PH/2+B.r:P_Y-PH/2-B.r;p.fl=.1;if(G)G.rally++;var T=G?G.disc.p:1,lvb=G?Math.min(8,G.lv):1;burst(B.x,B.y,top?cA:cP,8+5*(T-1)+lvb,top?1:-1);if(T>=2)rings.push({x:B.x,y:B.y,r:B.r,a:.5+.1*T,v:160+40*T,c:top?cA:cP});shake=Math.max(shake,.08+.03*T);
  if(!top){var k=skill(lv);A.react=k.react;A.err=rnd(-1,1)*k.err+rnd(-1,1)*A.w*.25;if(G&&st==='play'){G.hits++;G.score+=(10*G.lv+2*Math.min(G.rally,50))*G.fx.m;if(G.fx.sh>1)burst(B.x,B.y,'#ffd166',G.fx.m*5,-1)}snd('hit',G?G.rally:0)}
  else{var kd=skill(4);P.react=kd.react;P.err=rnd(-1,1)*kd.err;snd('ai',G?G.rally:0)}}
 function point(meScored){B.live=false;
  if(!G||st!=='play'){serve(!meScored,.8);return}
  if(meScored){var lb=G.lv;G.goals++;G.score+=100*lb*G.fx.m;G.lv=G.goals+1;flC=cP;flT=.35;shake=.35;burst(B.x,8,cP,26+10*G.disc.p,1);for(var q=0;q<G.disc.p;q++)rings.push({x:LW/2,y:LH/2,r:10+q*18,a:.7,v:260+60*q,c:q%2?cA:cP});
   if(G.goals===G.win&&!G.beat){G.beat=true;G.score+=1000*G.fx.m;ban(G.eev?OPN[G.eev].n+' '+OPN[G.eev].v:'YUU VAINCU',String(G.eev?'Tu as battu '+OPN[G.eev].n+'.':cfg().msg||'Tu as battu yuu.').replace(/[’‘]/g,"'").toUpperCase(),cA,3);snd('win');serve(false,3)}
   else{ban('BUT !',(G.beat?'ÉTERNITÉ · ':'')+'NIVEAU '+G.lv+'  +'+(100*lb*G.fx.m),cP,1.4);snd('goal');setTimeout(function(){snd('lvl')},380);serve(false,1.5)}}
  else{G.lost++;G.lives--;flC='#ff2a4a';flT=.5;shake=.5;burst(B.x,LH-8,'#ff2a4a',22,-1);snd('lose');
   if(G.lives<=0){st='over';overT=1.5;muStop();ban('GAME OVER','',cP,99);setTimeout(function(){snd('over')},450);return}
   ban('VIE PERDUE',G.lives+(G.lives>1?' VIES':' VIE')+' RESTANTE'+(G.lives>1?'S':''),'#ff4d6d',1.3);serve(true,1.4)}}
 function burst(x,y,c,n,dir){for(var i=0;i<n;i++){var a=rnd(0,Math.PI),s=rnd(60,260);parts.push({x:x,y:y,vx:Math.cos(a)*s*(Math.random()<.5?-1:1),vy:Math.sin(a)*s*(dir||1)*-1,l:rnd(.3,.75),m:.75,c:Math.random()<.35?'#ffffff':c,z:Math.random()<.5?2:3})}}
 function ban(t,s,c,d){bans=[{t:t,s:s||'',c:c||'#fff',k:0,d:d||1.3}]}
 function update(dt){
  if(st==='drop'){dropT+=dt;
   if(!revOn){var stepd=false;while(plan.length&&dropT>=plan[0]){plan.shift();dropI=(dropI+1)%DISC.length;stepd=true}if(stepd)snd('sel');
    if(!plan.length){if(isMy(G.disc)){if(!glD){glD=1;glT=1.2}glT-=dt;if(Math.random()<.35)snd('glitch');if(glT<=0)reveal()}else reveal()}}
   else{revT+=dt;if(G.fel&&!G.felOn&&revT>.9)felCrack();if(revT>[0,1.5,1.9,2.5,3.2][G.disc.p]+(G.fel?1.6:0))go()}
   if(dropT>10)go();dropShk=Math.max(0,dropShk-dt*.5)}
  rfx=rfx.filter(function(p){p.l-=dt;p.x+=p.vx*dt;p.y+=p.vy*dt;p.vy+=p.gr*dt;p.vx*=.985;p.rot+=p.vr*dt;return p.l>0});
  rings=rings.filter(function(r){r.r+=r.v*dt;r.a-=dt*1.1;return r.a>0&&r.r>0});
  if(window.__pgLock&&document.pointerLockElement&&(st!=='play'||paused))__pgLock(false);if(st==='play'&&!paused){G.dur+=dt;me(dt);var lv2=Math.min(10,Math.floor(G.score/1e5));if(lv2>(G.crk||0)){for(var q2=(G.crk||0)+1;q2<=lv2;q2++)crackUp(q2);G.crk=lv2}var tr2=Math.floor(G.score/1e5);if(tr2>10&&tr2>(G.tr||10)){G.tr=tr2;ban(tr2>=100?(tr2/10).toFixed(0)+' MILLIONS':(tr2/10).toFixed(1).replace('.',',')+' MILLION'+(tr2>=20?'S':''),tr2<=12?'ÇA SE CORSE ENCORE':'YUU EST AU MAXIMUM',cA,1.4);snd('lvl')}
   if(G.sht&&!G.shOn&&!G.shDone&&G.dur>=G.sht&&B.live&&B.y>LH*.3&&B.y<LH*.7)shatter();if(G.shOn){G.shT-=dt;G.shBt=Math.max(0,(G.shBt||0)-dt);updShards(dt);if(G.shT<=0||!G.shd.length)reform()}}
  if(G&&G.boom)G.bt+=dt;if(st!=='play')ai(P,false,dt,skill(4));
  if(!(st==='play'&&paused)){
   ai(A,true,dt,skill(st==='play'?lvl():4));
   if(st==='over'){overT-=dt;if(overT<=0){showOver()}}
   if(!B.live){B.wait-=dt;if(B.wait<=0&&st!=='over'&&st!=='drop')launch()}
   else{var spd=Math.hypot(B.vx,B.vy),n=Math.max(1,Math.ceil(spd*dt/3)),h=dt/n;
    for(var i=0;i<n&&B.live;i++){B.x+=B.vx*h;B.y+=B.vy*h;
     if(B.x<B.r+2){B.x=B.r+2;B.vx=Math.abs(B.vx);wall()}else if(B.x>LW-B.r-2){B.x=LW-B.r-2;B.vx=-Math.abs(B.vx);wall()}
     if(B.vy>0&&B.y+B.r>=P_Y-PH/2&&B.y<=P_Y+2&&Math.abs(B.x-P.x)<=P.w/2+B.r*.8)hit(P,false);
     else if(B.vy<0&&B.y-B.r<=A_Y+PH/2&&B.y>=A_Y-2&&Math.abs(B.x-A.x)<=A.w/2+B.r*.8)hit(A,true);
     if(B.vy>0&&G&&st==='play'&&G.shield>0&&B.y+B.r>=LH-33){B.y=LH-33-B.r;B.vy=-Math.abs(B.vy);B.vx+=rnd(-40,40);G.shield--;flC=glow;flT=.45;shake=.3;burst(B.x,LH-33,glow,40,-1);rings.push({x:B.x,y:LH-33,r:6,a:.9,v:300,c:'#ffe08a'});ban('BOUCLIER D\'OR','IL T\'A SAUVÉ',G.disc.col,1.2);snd('gold');var kk=skill(lvl());A.react=kk.react;A.err=rnd(-1,1)*kk.err}
     if(B.y-B.r>LH)point(false);else if(B.y+B.r<0)point(true)}
    trail.push([B.x,B.y]);if(trail.length>12)trail.shift()}
   B.spin+=dt*(6+Math.abs(B.vx)*.012+(B.live?Math.hypot(B.vx,B.vy)*.006:0));
   P.fl=Math.max(0,P.fl-dt);A.fl=Math.max(0,A.fl-dt);shake=Math.max(0,shake-dt*1.6);flT=Math.max(0,flT-dt);
   parts=parts.filter(function(p){p.l-=dt;p.x+=p.vx*dt;p.y+=p.vy*dt;p.vx*=.97;p.vy*=.97;return p.l>0});
   bans=bans.filter(function(b){b.k+=dt;return b.k<b.d})}}
 function shatter(){G.shOn=true;G.shT=20;G.shd=[];var up=B.vy<0?-1:1;for(var i=0;i<2;i++){var a=(i?.55:-.55)+rnd(-.1,.1),sp=300;G.shd.push({x:B.x,y:B.y,vx:Math.sin(a)*sp,vy:-Math.cos(a)*sp,r:10,spin:rnd(0,6),vs:rnd(5,9)*(i?1:-1),k:i+1,gh:.35})}
  flC='#ffffff';flT=.55;shake=.6;burst(B.x,B.y,'#ffffff',30,-1);burst(B.x,B.y,cP,22,1);rings.push({x:B.x,y:B.y,r:6,a:1,v:380,c:'#ffffff'});ban('LE DISQUE ÉCLATE !','RENVOIE LES ÉCLATS · 20 SECONDES',cP,1.7);snd('glitch');snd('lose')}
 function reform(){var n=G.shd.length;G.shOn=false;G.shDone=true;G.shd.forEach(function(q){burst(q.x,q.y,'#ffffff',12,-1);rings.push({x:q.x,y:q.y,r:4,a:.8,v:160,c:'#ffffff'})});G.shd=[];rings.push({x:B.x,y:B.y,r:46,a:.9,v:-44,c:cP});flC='#ffffff';flT=.25;ban('LE DISQUE SE REFORME',n?'':'ÉCLATS PERDUS',cP,1.3);snd('lvl')}
 function updShards(dt){G.shd=G.shd.filter(function(q){var n=Math.max(1,Math.ceil(Math.hypot(q.vx,q.vy)*dt/4)),h=dt/n,alive=true;q.spin+=q.vs*dt;q.gh=Math.max(0,q.gh-dt);
   for(var i=0;i<n&&alive;i++){q.x+=q.vx*h;q.y+=q.vy*h;
    if(q.x<q.r+2){q.x=q.r+2;q.vx=Math.abs(q.vx)}else if(q.x>LW-q.r-2){q.x=LW-q.r-2;q.vx=-Math.abs(q.vx)}
    if(q.gh<=0&&q.vy>0&&q.y+q.r>=P_Y-PH/2&&q.y<=P_Y+3&&Math.abs(q.x-P.x)<=P.w/2+q.r){q.y=P_Y-PH/2-q.r;var off=clamp((q.x-P.x)/(P.w/2),-1,1),sp=Math.min(460,Math.hypot(q.vx,q.vy)*1.03);q.vx=Math.sin(off*.9)*sp;q.vy=-Math.cos(off*.9)*sp;G.hits++;G.sx++;G.score+=(10*G.lv+50)*G.fx.m;P.fl=.12;burst(q.x,q.y,cP,8,-1);snd('hit',3)}
    else if(q.gh<=0&&q.vy<0&&q.y-q.r<=A_Y+PH/2&&q.y>=A_Y-3&&Math.abs(q.x-A.x)<=A.w/2+q.r){q.y=A_Y+PH/2+q.r;q.vy=Math.abs(q.vy);A.fl=.12;snd('ai')}
    else if(q.y-q.r<2&&q.vy<0){q.y=q.r+2;q.vy=Math.abs(q.vy);G.sg++;var b2=100*G.lv*G.fx.m;G.score+=b2;G.shB=b2;G.shBt=1.1;flC=cP;flT=.18;burst(q.x,6,cP,16,1);snd('goal')}
    if(q.y-q.r>LH){burst(q.x,LH-6,'#ffffff',8,-1);snd('wall');alive=false}}
   return alive})}
 function wedge(g,x,y,r,rot,k,D){var c=cdImg(D,0),im=c.i;if(!im)return;var f=im._f||1,z=r/f,a0=k*2.0944,mid=a0+1.0472;g.save();g.translate(x,y);g.rotate(rot);g.translate(-Math.cos(mid)*r*.42,-Math.sin(mid)*r*.42);
  g.shadowColor=glow;g.shadowBlur=10;g.beginPath();g.moveTo(Math.cos(mid)*r*.1,Math.sin(mid)*r*.1);g.arc(0,0,r,a0+.06,a0+2.03);g.closePath();g.fillStyle='rgba(20,16,36,.9)';g.fill();g.shadowBlur=0;g.save();g.clip();g.rotate(c.r);g.drawImage(im,-z,-z,z*2,z*2);g.restore();g.strokeStyle='rgba(255,255,255,.85)';g.lineWidth=1;g.stroke();g.restore()}
 function shardDraw(g,t){G.shd.forEach(function(q){wedge(g,q.x,q.y,B.r*1.55,q.spin,q.k,G.disc)});
  g.font=F(6);g.textAlign='right';g.textBaseline='middle';g.fillStyle=BOOM()?'#2b2342':'#ffffff';g.fillText('ÉCLATS ×'+G.shd.length+' · '+Math.ceil(G.shT)+' S',LW-10,LH/2-12);
  if(G.shBt>0){g.textAlign='center';g.fillStyle=hexA(cP,Math.min(1,G.shBt*1.5));g.font=F(8);g.fillText('ÉCLAT +'+G.shB,LW/2,A_Y+34)}}
 function wall(){burst(B.x,B.y,'#ffffff',4,B.vy>0?-1:1);snd('wall')}
 function paddle(g,p,y,c,label,ly){var w=p.w,x=p.x-w/2,bm=BOOM();if(bm&&lum(c)>.7)c='#2b2342';g.save();g.shadowColor=bm?'rgba(40,30,80,.45)':c;g.shadowBlur=16;g.fillStyle=p.fl>0&&!bm?'#ffffff':c;g.fillRect(x,y-PH/2,w,PH);g.restore();if(bm){g.strokeStyle='rgba(20,14,40,.85)';g.lineWidth=1.5;g.strokeRect(x-.75,y-PH/2-.75,w+1.5,PH+1.5)}
  g.fillStyle='rgba(255,255,255,.55)';g.fillRect(x,y-PH/2,w,2);g.fillStyle='rgba(0,0,0,.28)';g.fillRect(x,y+PH/2-2,w,2);
  g.fillStyle='#05040b';g.fillRect(x,y-PH/2,2,2);g.fillRect(x+w-2,y-PH/2,2,2);g.fillRect(x,y+PH/2-2,2,2);g.fillRect(x+w-2,y+PH/2-2,2,2);
  g.font=F(6);g.textAlign='center';g.textBaseline='middle';g.fillStyle=hexA(c,.6);g.fillText(label,p.x,ly)}
 function eevPad(g,t){var OP=OPN[G.eev]||OPN.eeveie,EC=OP.c,c=EC[Math.floor(t*3)%EC.length];if(G.eevS==null)G.eevS=t;var E=t-G.eevS;
  if(E<.7){var k=E/.7,yy=A_Y-k*k*120,sc=1-k*.5;g.save();g.translate(A.x+Math.sin(E*60)*4*(1-k),yy);g.rotate(k*k*5);g.scale(sc,sc);g.globalAlpha=1-k*.8;paddle(g,{x:0,w:A.w,fl:Math.sin(E*40)>0?1:0},0,cA,'YUU',-17);g.restore();g.globalAlpha=1;
   if(Math.random()<.8)parts.push({x:A.x+rnd(-A.w/2,A.w/2),y:yy,vx:rnd(-90,90),vy:rnd(-160,-20),l:.6,m:.6,c:'#ffffff',z:2});return}
  if(E<2){var q=Math.min(1,(E-.7)/1),eb=q<1?1-Math.pow(1-q,3)*Math.cos(q*9):1,yd=-40+(A_Y+40)*eb,ra=q*q*4*6.2832;g.save();g.translate(A.x,yd);g.rotate(ra);var s2=.4+.6*Math.min(1,q*1.4);g.scale(s2,s2);paddle(g,{x:0,w:A.w,fl:0},0,c,OP.n,-17);g.restore();
   for(var i=0;i<3;i++)parts.push({x:A.x+rnd(-A.w/2,A.w/2),y:yd,vx:rnd(-60,60),vy:rnd(-40,40),l:.7,m:.7,c:EC[(Math.random()*EC.length)|0],z:Math.random()<.5?2:3});
   if(q>=1&&!G.eevLand){G.eevLand=1;shake=Math.max(shake,8);flC=c;flT=.3;rings.push({x:A.x,y:A_Y,r:8,a:1,v:340,c:c});rings.push({x:A.x,y:A_Y,r:4,a:.8,v:220,c:EC[2]});snd('lvl')}return}
  var T=2.4,D=.85,ph=((t-G.eevS)%T)/D,a=0;if(ph<1){var e=ph<.5?2*ph*ph:1-Math.pow(-2*ph+2,2)/2;a=e*6.2832}
  var R=13,cx=A.x+Math.sin(a)*R,cy=A_Y+(1-Math.cos(a))*R;g.save();g.translate(cx,cy);g.rotate(a);paddle(g,{x:0,w:A.w,fl:A.fl},0,c,OP.n,-17);g.restore();
  if(ph<1&&Math.random()<.5)parts.push({x:cx+rnd(-A.w/2,A.w/2),y:cy,vx:rnd(-30,30),vy:rnd(10,60),l:.5,m:.5,c:c,z:2})}
 function fitF(g,s,px,maxW){g.font=F(px);var w=g.measureText(s).width;while(w>maxW&&px>5){px-=1;g.font=F(px);w=g.measureText(s).width}return px}
 function txt(g,s,x,y,px,c,al){px=fitF(g,s,px,LW-24);g.font=F(px);g.textAlign=al||'center';g.textBaseline='middle';g.fillStyle='rgba(255,40,90,.6)';g.fillText(s,x-1,y);g.fillStyle='rgba(40,200,255,.6)';g.fillText(s,x+1,y);g.fillStyle=c;g.fillText(s,x,y)}
 function bigCD(c2,z,D,t,sz){c2.setTransform(1,0,0,1,0,0);c2.clearRect(0,0,z,z);c2.setTransform(z/sz,0,0,z/sz,0,0);drawCD(c2,sz/2,sz/2,sz*.435,t,t,D,false)}
 function render(t){var g=cx;g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,cv.width,cv.height);g.drawImage(bgc,0,0);if(BOOM())boomBg(g,t);else if(G&&CRK.length){if(!crc)mkCrk();if(crc){if(G.crk>=8&&Math.random()<.06)g.globalAlpha=.55;g.drawImage(crc,0,0);g.globalAlpha=1}}
  var sx=shake>0?rnd(-1,1)*shake*9:0,sy=shake>0?rnd(-1,1)*shake*9:0;g.setTransform(sc*dpr,0,0,sc*dpr,sx*sc*dpr,sy*sc*dpr);
  if(G&&st!=='title'&&st!=='drop'){g.font=F(56);g.textAlign='center';g.textBaseline='middle';g.fillStyle=BOOM()?'rgba(40,30,80,.08)':hexA(cA,.09);g.fillText(String(G.lost),LW/2,LH/4+12);g.fillStyle=BOOM()?'rgba(40,30,80,.08)':hexA(cP,.09);g.fillText(String(G.goals),LW/2,LH*3/4-12)}
  if(G&&G.eev&&G.eevIn&&st!=='title')eevPad(g,t);else paddle(g,A,A_Y,cA,'YUU',A_Y-17);paddle(g,P,P_Y,cP,'YOU',P_Y+17);
  var D=G&&st!=='title'?G.disc:(carL()[carI]||DISC[0]);
  rings.forEach(function(r){g.strokeStyle=hexA(r.c,Math.max(0,r.a));g.lineWidth=2;g.beginPath();g.arc(r.x,r.y,Math.max(.01,r.r),0,7);g.stroke()});
  if(st!=='drop'){var T=G&&st!=='title'?G.disc.p:1,la=Math.min(.18,G?(G.lv-1)*.02:0);g.save();g.globalCompositeOperation=BOOM()?'source-over':'lighter';for(var i=0;i<trail.length;i++){var q=(i+1)/trail.length,s=Math.max(2,Math.round(B.r*1.2*q/2)*2),tx=Math.round(trail[i][0]/3)*3,ty=Math.round(trail[i][1]/3)*3;
    g.fillStyle=T===4?(nv?'hsla(228,14%,'+(BOOM()?18+q*20:35+q*45)+'%,'+(q*(.42+la))+')':'hsla('+(40+(i*3+t*60)%18)+',100%,'+(BOOM()?42+q*10:55+q*15)+'%,'+(q*(.38+la))+')'):T===3?(i%3?'hsla('+(350+(i*7)%14)+',100%,52%,'+(q*(.36+la))+')':'rgba(0,0,0,'+(q*.5)+')'):'hsla('+((t*220+i*24)%360)+',100%,62%,'+(q*(.32+la))+')';g.fillRect(tx-s/2,ty-s/2,s,s);
    if(T>=2&&Math.random()<.25+.1*T){g.fillStyle=T===4?(nv?'#e9ecf5':'#fff1c2'):T===3?'#ff2a4a':'#cfe6ff';g.fillRect(tx+rnd(-9,9),ty+rnd(-9,9),2,2)}}
   if(T===3&&B.live&&Math.random()<.04){g.fillStyle='rgba(255,30,60,.35)';g.fillRect(0,B.y+rnd(-30,30),LW,1+Math.random()*3)}g.restore();
   var sh=G&&G.shOn&&st==='play';if(B.live||Math.floor(t*7)%2===0){if(sh)wedge(g,B.x,B.y,B.r*1.55,B.spin,0,D);else drawCD(g,B.x,B.y,B.r,B.spin,t,D)}if(sh)shardDraw(g,t)}
  parts.forEach(function(p){g.globalAlpha=clamp(p.l/p.m,0,1);g.fillStyle=p.c;g.fillRect(Math.round(p.x),Math.round(p.y),p.z,p.z)});g.globalAlpha=1;
  g.font=F(7);g.textBaseline='middle';g.textAlign='left';g.fillStyle=BOOM()?'#5a5470':nv?'#aab0c4':gm?'#d9b25a':'#9a94c8';g.fillText('HI '+p6(hiScore()),10,15);
  if(G&&st==='play'&&G.shield>0){g.save();g.shadowColor=nv?'#b9c1dc':'#ffd65a';g.shadowBlur=10;g.fillStyle=(nv?'rgba(200,206,226,':'rgba(255,214,90,')+(.55+.25*Math.sin(t*4))+')';for(var bx=4;bx<LW;bx+=10)g.fillRect(bx,LH-34,6,2);g.restore();g.font=F(5);g.textAlign='right';g.fillStyle=nv?'rgba(214,219,235,.8)':'rgba(255,224,138,.8)';g.fillText('BOUCLIER',LW-8,LH-40)}
  if(G&&st!=='title'&&st!=='drop'){g.textAlign='left';g.fillStyle=BOOM()?'#1d1830':nv?'#eef0f7':gm?'#ffe7a0':'#f3f0ff';g.fillText('SCORE '+p6(G.score)+(G.fx.m>1?' ×'+G.fx.m:''),10,LH-14);g.textAlign='center';g.fillStyle=BOOM()?'#5a5470':G.beat?'#ffd166':nv?'#aab0c4':gm?'#d9b25a':'#9a94c8';g.fillText(G.beat?'∞ NIV '+G.lv:'NIV '+G.lv,LW/2+40,LH-14);
   for(var j=0;j<G.lives;j++)drawCD(g,LW-14-j*17,LH-14,6,t*2+j,t,G.disc,false);
   if(G.rally>=4&&B.live){g.textAlign='right';g.fillStyle=hexA('#ffd166',.75);g.font=F(6);g.fillText('COMBOS ×'+G.rally,LW-10,LH/2+12)}}
  else if(st==='title'){g.textAlign='center';g.fillStyle='#9a94c8';g.fillText('INSÈRE UN DISQUE',LW/2,LH-14)}
  var b=bans[0];if(b){var k=b.k<.15?b.k/.15:b.d-b.k<.25?(b.d-b.k)/.25:1;g.fillStyle='rgba(5,4,11,'+(.72*k)+')';var hh=(b.s?62:44)*k;g.fillRect(0,LH/2-hh/2,LW,hh);
   if(k>.6){txt(g,b.t,LW/2,LH/2-(b.s?9:0),b.t.length>10?14:18,b.c);if(b.s){fitF(g,b.s,7,LW-20);g.textAlign='center';g.fillStyle='#f3f0ff';g.fillText(b.s,LW/2,LH/2+16)}}}
  if(flT>0){g.fillStyle=hexA(flC,flT*.35);g.fillRect(-20,-20,LW+40,LH+40)}
  if(st==='play'&&paused){g.fillStyle='rgba(5,4,11,.7)';g.fillRect(0,0,LW,LH);txt(g,'PAUSE',LW/2,LH/2-10,20,'#fff');g.font=F(7);g.textAlign='center';g.fillStyle='#ffd166';g.fillText(TOUCH?'TOUCHE POUR REPRENDRE':'ESPACE POUR REPRENDRE',LW/2,LH/2+20)}
  if(!ui.title.hidden&&DISC.length){carT+=1;var CAR=carL(),cyc=Math.floor(t/1.8)%CAR.length;if(cyc!==carI){carI=cyc;var C=CAR[carI],R=RAR[C.p]||RAR[1],my=isMy(C),pc=C===GOLD?ahaP():C===NOIR?noirP():C.pc;ui.dn.innerHTML=esc(C.name)+' · <b style="color:'+(C===NOIR?'#c9cfe0':R[1])+'">'+(my?'MYTHIQUE':R[0])+'</b> · '+fmtP(pc)+'% · <b style="color:#ffd166">×'+fx(C).m+'</b>'}
   var ph=(t/1.8)%1,sq=ph<.08?ph/.08:ph>.92?(1-ph)/.08:1;var z=ui.cd.width;ui.cdx.setTransform(1,0,0,1,0,0);ui.cdx.clearRect(0,0,z,z);ui.cdx.setTransform(z/92*Math.max(.02,sq),0,0,z/92,z/2*(1-Math.max(.02,sq)),0);drawCD(ui.cdx,46,46,40,t*1.4,t,carL()[carI]||DISC[0],false)}
  if(st==='drop'&&!ui.drop.hidden){var Dd=revOn?G.disc:(glD&&Math.random()<.5?DISC[Math.floor(Math.random()*DISC.length)]:DISC[dropI]),zz=ui.cd2.width,sp=revOn?t*1.2:t*9;bigCD(ui.cdx2,zz,Dd,sp,150);
   if(glD&&!revOn){var c3=ui.cdx2;c3.setTransform(1,0,0,1,0,0);for(var q2=0;q2<6;q2++){var yy=Math.random()*zz,hh2=2+Math.random()*zz*.08;try{c3.drawImage(ui.cd2,0,yy,zz,hh2,rnd(-zz*.15,zz*.15),yy,zz,hh2)}catch(e){}}c3.globalCompositeOperation='source-atop';c3.fillStyle='rgba('+(Math.random()<.5?'255,40,90':'40,220,255')+',.25)';c3.fillRect(0,0,zz,zz);c3.globalCompositeOperation='source-over'}
   if(revOn&&G.disc.p>=3){ui.cdx2.setTransform(1,0,0,1,0,0);ui.cdx2.globalCompositeOperation='source-atop';ui.cdx2.fillStyle=G.disc===NOIR?'rgba(0,0,6,'+(.18+.14*Math.sin(t*9))+')':G.disc.p===4?'rgba(255,220,120,'+(.1+.08*Math.sin(t*9))+')':'rgba(255,40,70,'+(.12+.1*Math.sin(t*20))+')';ui.cdx2.fillRect(0,0,zz,zz);ui.cdx2.globalCompositeOperation='source-over'}
   ui.cd2.style.transform=dropShk>0?'translate('+rnd(-1,1)*dropShk*14+'px,'+rnd(-1,1)*dropShk*14+'px)':'';
   fxDraw(t)}}
 function star(g,x,y,r,c){g.fillStyle=c;g.beginPath();for(var i=0;i<8;i++){var a=i*Math.PI/4,rr=i%2?r*.35:r;g.lineTo(x+Math.cos(a)*rr,y+Math.sin(a)*rr)}g.closePath();g.fill()}
 function fxDraw(t){var c=ui.fx,g=ui.fxx;g.setTransform(1,0,0,1,0,0);g.clearRect(0,0,c.width,c.height);g.setTransform(sc*dpr,0,0,sc*dpr,0,0);
  if(glD&&!revOn){for(var i=0;i<16;i++){g.fillStyle='rgba('+(Math.random()<.5?'255,40,90':'40,220,255')+','+(Math.random()*.22)+')';g.fillRect(0,Math.random()*LH,LW,1+Math.random()*7)}for(var j=0;j<120;j++){g.fillStyle='rgba(255,255,255,'+(Math.random()*.25)+')';g.fillRect(Math.random()*LW,Math.random()*LH,2,2)}return}
  if(!revOn)return;var T=G.disc.p,k=revT,col=T===4?(nv?'#4a4660':'#ffd65a'):RAR[T][1];
  var hg=g.createRadialGradient(cdX,cdY,cdR*.8,cdX,cdY,cdR*(2+T*.7));if(T===4&&nv){hg.addColorStop(0,'rgba(0,0,0,.85)');hg.addColorStop(.5,'rgba(4,2,10,.55)');hg.addColorStop(1,'rgba(0,0,0,0)')}else{hg.addColorStop(0,hexA(col,.1+.07*T));hg.addColorStop(1,hexA(col,0))}g.fillStyle=hg;g.fillRect(0,0,LW,LH);
  if(T>=2){var n=[0,0,8,12,18][T],RR=Math.max(LW,LH),a0=k*(.2+.12*T)*(T===3?-1:1);g.save();g.translate(cdX,cdY);g.globalCompositeOperation='lighter';
   for(var i2=0;i2<n;i2++){var a=a0+i2/n*6.2832,w=.07+.02*T;g.fillStyle=hexA(col,(T===3?.05+.05*Math.abs(Math.sin(t*12+i2)):.04+.025*T)*Math.min(1,k*3));g.beginPath();g.moveTo(0,0);g.arc(0,0,RR,a-w,a+w);g.closePath();g.fill()}g.restore()}
  for(var r=0;r<T;r++){var kk=k-r*.22;if(kk<0||kk>1.3)continue;g.strokeStyle=hexA(T===4?(nv?'#9a90c8':'#ffe08a'):col,(1-kk/1.3)*(T===4&&nv?.45:.7));g.lineWidth=1+T;g.beginPath();g.arc(cdX,cdY,cdR+kk*LW*.75,0,7);g.stroke()}
  var fa=[0,.22,.4,.65,.9][T]-k*1.6;if(fa>0){g.fillStyle=T===3?'rgba(255,30,60,'+fa+')':T===4?(nv?'rgba(0,0,0,'+Math.min(.85,fa*1.1)+')':'rgba(255,236,170,'+fa+')'):'rgba(255,255,255,'+fa+')';g.fillRect(0,0,LW,LH)}
  rfx.forEach(function(p){g.globalAlpha=clamp(p.l/p.m,0,1);if(p.coin){var w2=Math.abs(Math.cos(p.rot))*p.z;g.fillStyle=p.c;g.beginPath();g.ellipse(p.x,p.y,Math.max(.6,w2),p.z,0,0,7);g.fill();g.fillStyle='rgba(255,255,255,.7)';g.fillRect(p.x-.5,p.y-p.z*.6,1,p.z*.5)}else{g.fillStyle=p.c;g.fillRect(Math.round(p.x),Math.round(p.y),p.z,p.z)}});g.globalAlpha=1;
  if(T===3&&Math.random()<.6){for(var q=0;q<3;q++){g.fillStyle=Math.random()<.5?'rgba(0,0,0,.55)':'rgba(255,20,50,.22)';g.fillRect(0,Math.random()*LH,LW,2+Math.random()*10)}}
  if(T===4){for(var s2=0;s2<14;s2++){var sx=(Math.sin(s2*91.7+t*.3)*.5+.5)*LW,sy=(Math.cos(s2*37.3+t*.25)*.5+.5)*LH,tw=Math.max(0,Math.sin(t*5+s2*2));star(g,sx,sy,2+5*tw,nv?'rgba(150,140,205,'+(tw*.55)+')':'rgba(255,240,190,'+(tw*.9)+')')}}}
 function loop(now){raf=requestAnimationFrame(loop);var dt=Math.min(.033,Math.max(0,(now-(last||now))/1000));last=now;try{update(dt)}catch(e){oops(e)}try{render(now/1000)}catch(e){oops(e)}
  if(ERR)try{var g=cx;g.setTransform(sc*dpr,0,0,sc*dpr,0,0);g.font=F(5);g.textAlign='left';g.fillStyle='#ff6b81';g.fillText('ERR '+ERR,6,LH-34)}catch(e){}}
 function oops(e){var m=String(e&&e.message||e).slice(0,70);if(!ERR){ERR=m;try{console.error(e)}catch(x){}}if(st==='drop'&&dropT>3)try{go()}catch(x){}}
 /* ---------- clavier ---------- */
 function key(e){if(!window.PGON)return;var k=e.key||'',up=e.type==='keyup',L=k==='ArrowLeft'||k==='a'||k==='A'||k==='q'||k==='Q',R=k==='ArrowRight'||k==='d'||k==='D';
  e.stopPropagation();
  if(up){if(L)keys.l=false;if(R)keys.r=false;return}
  if(k==='Escape'){e.preventDefault();close();return}
  if(st==='enter'){e.preventDefault();if(k==='ArrowUp')turn(1);else if(k==='ArrowDown')turn(-1);else if(k==='ArrowLeft'){cur=(cur+2)%3;iniDraw()}else if(k==='ArrowRight'){cur=(cur+1)%3;iniDraw()}
   else if(k==='Backspace'){cur=Math.max(0,cur-1);iniDraw()}else if(k==='Enter')submit();else if(k.length===1){var i=CH.indexOf(k.toUpperCase());if(i>=0){ini[cur]=i;cur=Math.min(2,cur+1);iniDraw();if(window.SND&&SND.game)SND.game('sel')}}return}
  if(L||R){e.preventDefault();if(L)keys.l=true;if(R)keys.r=true;return}
  if(k===' '||k==='Enter'){if(e.target&&e.target.tagName==='BUTTON')return;e.preventDefault();if(st==='drop'&&revOn&&revT>.4){go();return}if(st==='title'||st==='res')start();else if(st==='play'&&paused){paused=false;muPlay()}return}
  if((k==='p'||k==='P')&&st==='play'){paused=!paused;if(paused)muStop(true);else muPlay()}}
 function vis(){if(document.hidden){if(st==='play')paused=true;muStop(true)}}
 /* ---------- ouverture / fermeture ---------- */
 function font(){if(!document.getElementById('pgfont')){var l=document.createElement('link');l.id='pgfont';l.rel='stylesheet';var mf=document.querySelector('meta[name="yuu-pgfont"]'),lc=mf&&mf.getAttribute('content')||'';l.href=/^\/assets\/fonts\/[\w.-]+\.css$/.test(lc)?lc:'https://fonts.googleapis.com/css2?family=Press+Start+2P&display=swap';document.head.appendChild(l)}}
 function open(o){if(window.PGON)return;FORCE=o&&o.force||null;PRESC=o&&+o.score||0;font();TOUCH=matchMedia('(pointer:coarse)').matches;build();window.PGON=true;window.FRZ=true;window.PGDK=0;
  oldOv=document.documentElement.style.overflow;oldOvB=document.body.style.overflow;document.documentElement.style.overflow='hidden';document.body.style.overflow='hidden';
  NEWREC=false;mkDiscs();goldPrep();goldSync();photos();setCol(DISC[0]);layout();var tt=root.querySelector('.pg-test'),fD=forced();tt.hidden=!FORCE;if(fD)tt.innerHTML='MODE TEST · <b style="color:'+RAR[fD.p][1]+'">'+esc(fD.name)+'</b><br>SCORE NON ENREGISTRÉ';else if(FORCE)tt.innerHTML='MODE TEST · <b style="color:#ffb38a">'+(FORCE==='fele'?'DISQUE FÊLÉ':FORCE==='eclat'?'LE DISQUE ÉCLATE':esc(String(FORCE).toUpperCase()))+'</b><br>SCORE NON ENREGISTRÉ';st='title';G=null;paused=false;show('title');serve(false,.6);P.x=A.x=LW/2;P.w=80;load();sndUi();carI=-1;
  addEventListener('keydown',key,true);addEventListener('keyup',key,true);addEventListener('resize',layout);document.addEventListener('visibilitychange',vis);
  try{if(window.SND)SND.amb()}catch(e){}last=0;raf=requestAnimationFrame(loop);if(window.SND&&SND.game)SND.game('coin')}
 function close(){if(!window.PGON)return;try{if(window.__pgLock)__pgLock(false)}catch(e){}cancelAnimationFrame(raf);removeEventListener('keydown',key,true);removeEventListener('keyup',key,true);removeEventListener('resize',layout);document.removeEventListener('visibilitychange',vis);
  muStop(true);if(root)root.remove();root=null;window.PGON=false;window.FRZ=false;window.PGDK=0;document.documentElement.style.overflow=oldOv;document.body.style.overflow=oldOvB;st='title';G=null;DISC.forEach(function(D){D.frames=null;D.still=null});
  try{if(window.__gl){__gl.shotsFree&&__gl.shotsFree();__gl.front?__gl.front(1400):__gl.hold(performance.now()+1400)}}catch(e){}GOLD.frames=GOLD.still=NOIR.frames=NOIR.still=null;try{if(window.SND)SND.amb()}catch(e){}}
 setTimeout(function(){try{goldPrep()}catch(e){}},4000);
 var PGD=function(){return !!(window.__PGT||(typeof OWN!=='undefined'&&OWN))};
 var PUB={open:open,close:close,on:function(){return !!window.PGON}},TT=null,SS=null;
 SS=function(){return{chip:!!CHP,ERR:ERR,revOn:revOn,st:st,G:G,B:B,P:P,A:A,src:src,board:board,paused:paused,LH:LH,sc:sc,DISC:DISC,shotsOK:shotsOK}};
 TT={fx:function(k){mkDiscs();var D=k==='noir'?NOIR:k==='ahabah'?GOLD:ALL.filter(function(x){return x.k===k})[0];return D?fx(D):null},badN:badN,start:start,point:point,submit:submit,turn:turn,draw1:draw1,go:go,GOLD:GOLD,NOIR:NOIR,noirize:noirize,myth:function(v){try{goldPrep()}catch(e){}return mythD(v,mysD())},mu:function(){return MU?{src:MU.src,rate:MU.playbackRate,paused:MU.paused,on:MUon,routed:!!MUG,gain:MUG?MUG.gain.value:MU.volume}:null}};
 var TPUB={myth:TT.myth,noirize:noirize};
 Object.defineProperty(PUB,'_s',{get:function(){return PGD()?SS:undefined}});Object.defineProperty(PUB,'_t',{get:function(){return PGD()?TT:TPUB}});
 return Object.freeze(PUB)
})();
function eg4Go(){if((S.eg4.mode||'game')==='game'&&window.PONG)PONG.open();else cdnOpen()}
/* n°5 : figer le disque sur son dos en le maintenant appuyé -> texte gravé */
(function(){var pt=null,ph=null,px=0,py=0,dn=false;var g=document.getElementById('grab');function stop(){clearTimeout(pt);clearTimeout(ph);pt=ph=null;if(window.__gl&&!ENGON)__gl.hint(false)}
 function arm(){clearTimeout(pt);clearTimeout(ph);if(!dn||!S.eg5||!S.eg5.on||ENGON||window.PZA)return;
  ph=setTimeout(function(){if(window.__gl&&__gl.side()&&curDisc().egg&&!ENGON)__gl.hint(true);else if(window.__gl&&!ENGON)__gl.hint(false)},800);
  pt=setTimeout(function(){pt=null;if(dn&&window.__gl&&__gl.side()&&curDisc().egg&&!ENGON&&!document.documentElement.classList.contains('locked')){engOn(true);if(window.SND)SND.play('egg');if(S.eg5.go!==false)setTimeout(function(){var q=hidP();if(q)location.hash=q.s},1700)}else stop()},2200)}
 if(g){g.addEventListener('contextmenu',function(e){e.preventDefault()});
  g.addEventListener('pointerdown',function(e){px=e.clientX;py=e.clientY;dn=true;arm()});
  g.addEventListener('pointermove',function(e){if(dn&&Math.abs(e.clientX-px)+Math.abs(e.clientY-py)>12){px=e.clientX;py=e.clientY;arm()}});
  ['pointerup','pointercancel','touchend','touchcancel','mouseup'].forEach(function(n){addEventListener(n,function(){dn=false;stop()})})}})();
var FLT=[],LSD=null,LTH=0,CHT=0;
function engOn(on){ENGON=!!on;if(window.__gl)__gl.engrave(!!on)}
(function(){var gb=$('grab'),x0=0,y0=0,t0=0;if(!gb)return;
 gb.addEventListener('pointerdown',function(e){x0=e.clientX;y0=e.clientY;t0=Date.now();LTH=Date.now();if(window.__gl)LSD=__gl.side()});
 addEventListener('pointerup',function(e){if(!t0)return;if(window.PZA||Date.now()-(window.PZT||0)<500){t0=0;return}var dx=e.clientX-x0,dy=e.clientY-y0,n=Date.now();LTH=n;t0=0;
  if(S.eg4.on&&Math.max(Math.abs(dx),Math.abs(dy))>=70&&n-0>0){var c=Math.abs(dx)>=Math.abs(dy)?(dx>0?'D':'G'):(dy>0?'B':'H');if(n-SWT>9000)SWB='';SWT=n;SWB=(SWB+c).slice(-12);var code=String(S.eg4.code||'').toUpperCase().replace(/[^DGHB]/g,'');if(code&&SWB.slice(-code.length)===code){SWB='';eg4Go()}}});
 setInterval(function(){if(!window.__gl||!S.eg5.on)return;var s=__gl.side(),n=Date.now();var el=$('engl'),p=hidP();if(el){if(s)CHT=n;var sh=ENGON&&S.eg5.chip&&p&&curDisc().egg&&n-CHT<3200&&!document.documentElement.classList.contains('locked');if(sh){el.hidden=false;el.href='#'+p.s;el.textContent=engLink()+' →'}else el.hidden=true}if(LSD===null){LSD=s;return}
  if(s!==LSD){LSD=s;if(n-LTH<1800&&curDisc().egg){FLT.push(n);FLT=FLT.filter(function(t){return n-t<20000});}}},120)})();

/* ================= le disque qui se brise au toucher (page d'accueil) =================
   Une visite sur 1000 pour chaque effet (puzzle, version cassée, gravité). Le compteur s'affiche toujours. */
var DSH=null;
(function(){
 S.brk=merge({on:true,puz:'1000',cas:'1000',gra:'1000'},S.brk||{});
 function N(k){var n=parseInt(S.brk[k],10);return isFinite(n)&&n>0?1/n:0}
 if(S.brk.on!==false){var r=Math.random(),a=N('puz'),b=N('cas'),c=N('gra');DSH=r<a?'puz':r<a+b?'cas':r<a+b+c?'gra':null}
 var gb=$('grab'),x0=0,y0=0,t0=0,busy=false;
 if(gb){gb.addEventListener('pointerdown',function(e){x0=e.clientX;y0=e.clientY;t0=Date.now()});
  gb.addEventListener('pointerup',function(e){if(!DSH||busy||OWN&&EDIT||window.PZA||document.documentElement.classList.contains('locked'))return;
   if(Math.hypot(e.clientX-x0,e.clientY-y0)<12&&Date.now()-t0<450){var k=DSH;DSH=null;go(k)}})}
 window.dshGo=function(k){if(busy)return;go(k)};
 function rn(a,b){return a+Math.random()*(b-a)}
 function ord(n){return n===1?'1re':n+'e'}
 // ---------- compteur : toujours affiché ----------
 function counter(){var show=function(n,dev){var c=document.createElement('div');c.id='dshc';c.setAttribute('role','status');
   c.innerHTML='<b>💿</b><span></span>';c.querySelector('span').textContent='Tu es la '+ord(n)+' personne à avoir brisé le disque.'+(dev?' (sur cet appareil)':'');
   document.documentElement.appendChild(c);requestAnimationFrame(function(){c.classList.add('on')});setTimeout(function(){c.classList.remove('on');setTimeout(function(){c.remove()},600)},7000)};
  var loc=function(){var n=1;try{n=(parseInt(localStorage.getItem('yuu-brise-n'),10)||0)+1;localStorage.setItem('yuu-brise-n',String(n))}catch(e){}show(n,true)};
  if(typeof isSA==='function'&&isSA()){fetch('/.netlify/functions/brise',{method:'POST',headers:{'Content-Type':'application/json'},body:'{}',cache:'no-store'}).then(function(r){return r.ok?r.json():null}).then(function(j){var n=j&&parseInt(j.n,10);if(n>0)show(n,false);else loc()}).catch(loc)}else loc()}
 // ---------- éclats du disque ----------
 function pieces(R){var ia=rn(0,6.2832),ir=R*rn(.3,.45),I=[Math.cos(ia)*ir,Math.sin(ia)*ir],n=6,A=[],E=[],P=[],o=rn(0,6.2832);
  for(var i=0;i<n;i++)A.push(o+(i+rn(-.22,.22))/n*6.2832);
  A.forEach(function(a){var dx=Math.cos(a),dy=Math.sin(a),b=I[0]*dx+I[1]*dy,T=-b+Math.sqrt(b*b-(I[0]*I[0]+I[1]*I[1]-R*R)),L=[],nx=-dy,ny=dx;for(var j=0;j<=5;j++){var t=T*j/5,w=j&&j<5?rn(-.022,.022)*R:0;L.push([I[0]+dx*t+nx*w,I[1]+dy*t+ny*w])}E.push(L)});
  var split={};[0,2,4].forEach(function(i){split[(i+Math.floor(rn(0,2)))%n]=1});
  function arc(p0,p1){var a0=Math.atan2(p0[1],p0[0]),a1=Math.atan2(p1[1],p1[0]);while(a1<a0)a1+=6.2832;var out=[];for(var k=1;k<8;k++){var a=a0+(a1-a0)*k/8;out.push([Math.cos(a)*R,Math.sin(a)*R])}return out}
  function add(p){var cx=0,cy=0;p.forEach(function(q){cx+=q[0];cy+=q[1]});cx/=p.length;cy/=p.length;var d=Math.hypot(cx-I[0],cy-I[1])||1,sp=rn(240,480);P.push({p:p,cx:cx,cy:cy,dx:0,dy:0,rot:0,vx:(cx-I[0])/d*sp,vy:(cy-I[1])/d*sp-100,vr:rn(-5,5),ok:false})}
  for(var i=0;i<n;i++){var L0=E[i],L1=E[(i+1)%n];
   if(split[i]){var j=2+Math.floor(rn(0,2)),m=[(L0[j][0]+L1[j][0])/2+rn(-.04,.04)*R,(L0[j][1]+L1[j][1])/2+rn(-.04,.04)*R];
    add(L0.slice(0,j+1).concat([m],L1.slice(0,j+1).reverse()));add(L0.slice(j).concat(arc(L0[5],L1[5]),L1.slice(j).reverse(),[m]))}
   else add(L0.concat(arc(L0[5],L1[5]),L1.slice().reverse()))}
  return P}
 function go(k){busy=true;var r=gb.getBoundingClientRect(),W=innerWidth,H=innerHeight,X=r.left+r.width/2,Y=r.top+r.height/2,R=Math.min(r.width,r.height)/2/1.06,top0=scrollY,
   d=typeof curDisc==='function'?curDisc():null;
  var wasS=false,wasA=false,AC=null;
  function mute(){try{wasS=!!SNDON;SNDON=false;if(window.SND)SND.amb();if(window.AUD&&!AUD.paused){wasA=true;AUD.pause()}}catch(e){}}
  function unmute(){try{if(wasS){SNDON=true;if(window.SND)SND.amb()}if(wasA&&window.AUD)AUD.play().catch(function(){});wasS=wasA=false}catch(e){}}
  function tick(f){try{AC=AC||new (window.AudioContext||window.webkitAudioContext)();if(AC.state==='suspended')AC.resume();var o=AC.createOscillator(),gn=AC.createGain(),n=AC.currentTime;o.type='triangle';o.frequency.setValueAtTime(f,n);o.frequency.exponentialRampToValueAtTime(f*1.5,n+.08);gn.gain.setValueAtTime(.0001,n);gn.gain.exponentialRampToValueAtTime(.22,n+.01);gn.gain.exponentialRampToValueAtTime(.0001,n+.22);o.connect(gn);gn.connect(AC.destination);o.start(n);o.stop(n+.25)}catch(e){}}
  function crack(){try{AC=AC||new (window.AudioContext||window.webkitAudioContext)();if(AC.state==='suspended')AC.resume();var n=AC.currentTime,len=Math.floor(AC.sampleRate*.5),bf=AC.createBuffer(1,len,AC.sampleRate),dt=bf.getChannelData(0);for(var i=0;i<len;i++){var e=Math.pow(1-i/len,5);dt[i]=(Math.random()*2-1)*e*(i<len*.03?1:.55+.45*(Math.random()<.02?3:0))}
    var sr=AC.createBufferSource(),hp=AC.createBiquadFilter(),gn=AC.createGain();sr.buffer=bf;hp.type='highpass';hp.frequency.value=1400;gn.gain.value=.5;sr.connect(hp);hp.connect(gn);gn.connect(AC.destination);sr.start(n);
    var o=AC.createOscillator(),og=AC.createGain();o.type='sawtooth';o.frequency.setValueAtTime(420,n);o.frequency.exponentialRampToValueAtTime(38,n+.35);og.gain.setValueAtTime(.28,n);og.gain.exponentialRampToValueAtTime(.0001,n+.4);o.connect(og);og.connect(AC.destination);o.start(n);o.stop(n+.42);
    [2900,3700,4600,5300,6100].forEach(function(f,i){var t=n+.03+i*.035+Math.random()*.03,p=AC.createOscillator(),pg=AC.createGain();p.type='sine';p.frequency.value=f*(1+Math.random()*.08);pg.gain.setValueAtTime(.0001,t);pg.gain.exponentialRampToValueAtTime(.09,t+.004);pg.gain.exponentialRampToValueAtTime(.0001,t+.16);p.connect(pg);pg.connect(AC.destination);p.start(t);p.stop(t+.2)})}catch(e){}}
  function sparkle(){try{AC=AC||new (window.AudioContext||window.webkitAudioContext)();if(AC.state==='suspended')AC.resume();var n=AC.currentTime;[1568,2093,2637,3136,3951,4186,5274,6272].forEach(function(f,i){var t=n+i*.07+(i>4?Math.random()*.05:0),p=AC.createOscillator(),pg=AC.createGain();p.type='sine';p.frequency.value=f;pg.gain.setValueAtTime(.0001,t);pg.gain.exponentialRampToValueAtTime(.085,t+.008);pg.gain.exponentialRampToValueAtTime(.0001,t+.7);p.connect(pg);pg.connect(AC.destination);p.start(t);p.stop(t+.75)})}catch(e){}}
  if(k==='puz'){mute();crack()}else if(window.SND)try{SND.play('break')}catch(e){}
  var start=function(img){
   var cv=document.createElement('canvas'),dpr=Math.min(2,devicePixelRatio||1);cv.id='dsh';cv.width=Math.round(W*dpr);cv.height=Math.round(H*dpr);cv.style.cssText='position:absolute;left:0;top:'+top0+'px;width:'+W+'px;height:'+H+'px;z-index:26;touch-action:none;pointer-events:'+(k==='puz'?'auto':'none');
   document.body.appendChild(cv);var imgG=null,gT=0,g=cv.getContext('2d'),P=pieces(R);window.__dshT={P:P,X:X,Y:Y};var t0=performance.now(),last=t0,drag=null,fin=false,raf=0,gold=0,isc=img?R/(img.width/2*(img._f||.94)):1;
   if(window.__gl&&__gl.vis)__gl.vis(false);
   var tint=k==='puz'?'#16161c':(d&&d.tint)||'#9fb4ea';
   function draw(){g.setTransform(dpr,0,0,dpr,0,0);g.clearRect(0,0,W,H);P.forEach(function(q){g.save();g.translate(X+q.cx+q.dx,Y-(scrollY-top0)*0+q.cy+q.dy);g.rotate(q.rot);g.translate(-q.cx,-q.cy);
     g.beginPath();q.p.forEach(function(v,i){if(i)g.lineTo(v[0],v[1]);else g.moveTo(v[0],v[1])});g.closePath();g.save();g.clip();
     if(img)g.drawImage(img,-img.width/2*isc,-img.height/2*isc,img.width*isc,img.height*isc);else{var gr=g.createLinearGradient(-R,-R,R,R);gr.addColorStop(0,'#f4f6fb');gr.addColorStop(.5,tint);gr.addColorStop(1,'#8b92a6');g.fillStyle=gr;g.fillRect(-R,-R,2*R,2*R)}
     if(gold>0&&imgG){g.globalAlpha=gold;g.drawImage(imgG,-imgG.width/2*isc,-imgG.height/2*isc,imgG.width*isc,imgG.height*isc);g.globalAlpha=1}g.restore();
     var ea=fin?Math.max(0,1-gold*1.6):1;if(ea>0){g.globalAlpha=ea;g.strokeStyle='rgba(0,0,0,.55)';g.lineWidth=2.2;g.stroke();g.strokeStyle=q.ok?'rgba(255,214,90,.85)':'rgba(255,255,255,.7)';g.lineWidth=.8;g.stroke();g.globalAlpha=1}g.restore()});
    if(false){var gg=g.createRadialGradient(X,Y,R*.9,X,Y,R*1.7);gg.addColorStop(0,'rgba(255,205,90,'+(.5*gold)+')');gg.addColorStop(1,'rgba(255,205,90,0)');g.globalCompositeOperation='lighter';g.fillStyle=gg;g.beginPath();g.arc(X,Y,R*1.7,0,7);g.arc(X,Y,R*.98,0,7,true);g.fill();g.globalCompositeOperation='source-over'}}
   function step(now){var dt=Math.min(.04,(now-last)/1000),T=(now-t0)/1000;last=now;
    if(k==='puz'){P.forEach(function(q,i){if(q===drag||q.ok)return;if(T<.9){q.dx+=q.vx*dt;q.dy+=q.vy*dt;q.vx*=.93;q.vy*=.93;q.rot+=q.vr*dt;q.vr*=.95}else{q.dy+=Math.sin(T*1.3+i)*.15;q.rot+=Math.sin(T+i)*.002}
      var hx=X+q.cx+q.dx,hy=Y+q.cy+q.dy;if(hx<20)q.dx+=1.5;if(hx>W-20)q.dx-=1.5;if(hy<20)q.dy+=1.5;if(hy>H-20)q.dy-=1.5});
     if(drag){drag.rot*=.85}
     if(fin&&imgG){gold=Math.min(1,gold+dt*1.1);if(gold>=1&&(gT+=dt)>.35&&window.__dshEnd)window.__dshEnd()}}
    else if(k==='cas'){if(T<.6)P.forEach(function(q){q.dx+=q.vx*dt*.12;q.dy+=q.vy*dt*.12;q.rot+=q.vr*dt*.08})}
    else if(k==='gra'){if(T<4.2)P.forEach(function(q){q.vy+=1500*dt;q.dx+=q.vx*dt*.4;q.dy+=q.vy*dt;q.rot+=q.vr*dt;var by=H-24-(Y+q.cy);if(q.dy>by){q.dy=by;q.vy*=-.35;q.vx*=.7;q.vr*=.6}});
     else{var u=Math.min(1,(T-4.2)/1.4),e=u*u*(3-2*u);P.forEach(function(q,i){var s=Math.max(0,Math.min(1,e*1.6-i*.06));q.dx*=1-s*.25;q.dy*=1-s*.25;q.rot*=1-s*.25});
      if(T>6.2){end();return}}}
    draw();raf=requestAnimationFrame(step)}
   function end(){cancelAnimationFrame(raf);cv.style.pointerEvents='none';cv.style.transition='opacity .28s';cv.style.opacity=0;setTimeout(function(){cv.remove()},300);if(window.__gl&&__gl.vis)__gl.vis(true);busy=false;document.documentElement.style.overflow=''}
   // puzzle : on remet chaque éclat à sa place
   if(k==='puz'){document.documentElement.style.overflow='hidden';var skip=document.createElement('button');skip.type='button';skip.id='dshx';skip.textContent='Laisser le disque cassé ✕';document.documentElement.appendChild(skip);
    var hint=document.createElement('div');hint.id='dshh';hint.textContent='Remets les éclats à leur place';document.documentElement.appendChild(hint);
    var GD=null,oldG=window.DSHG;try{GD=PONG._t.myth('ahabah')}catch(x){}if(GD){window.DSHG=S.discs.filter(function(z){return z.k==='ahabah'&&z.myt})[0]||GD;window.DSHK=1;[0,250,900].forEach(function(ms){setTimeout(function(){try{if(window.DSHK)__gl.cd()}catch(x){}},ms)})}
    skip.onclick=function(){window.DSHG=oldG||null;window.DSHK=0;try{__gl.cd()}catch(x){}unmute();skip.remove();hint.remove();k='gra';t0=performance.now()-300;P.forEach(function(q){q.vy=rn(-200,0);q.vx=rn(-80,80)});cv.style.pointerEvents='none'};
    var inside=function(q,x,y){var c=Math.cos(-q.rot),s=Math.sin(-q.rot),lx=x-(X+q.cx+q.dx),ly=y-(Y+q.cy+q.dy),px=lx*c-ly*s+q.cx,py=lx*s+ly*c+q.cy,o=false;for(var i=0,j=q.p.length-1;i<q.p.length;j=i++){var a=q.p[i],b=q.p[j];if((a[1]>py)!==(b[1]>py)&&px<(b[0]-a[0])*(py-a[1])/(b[1]-a[1])+a[0])o=!o}return o};
    var ox=0,oy=0;
    cv.addEventListener('pointerdown',function(e){if(fin)return;for(var i=P.length-1;i>=0;i--){var q=P[i];if(!q.ok&&inside(q,e.clientX,e.clientY)){drag=q;ox=e.clientX-q.dx;oy=e.clientY-q.dy;P.splice(i,1);P.push(q);try{cv.setPointerCapture(e.pointerId)}catch(x){}return}}});
    cv.addEventListener('pointermove',function(e){if(!drag)return;drag.dx=e.clientX-ox;drag.dy=e.clientY-oy});
    cv.addEventListener('pointerup',function(){if(!drag)return;var q=drag;drag=null;var first=!P.some(function(z){return z.ok});if(Math.hypot(q.dx,q.dy)<(first?90:28)&&(first||Math.abs(q.rot)<.5)){q.dx=0;q.dy=0;q.rot=0;q.ok=true;P.splice(P.indexOf(q),1);P.unshift(q);tick(520+P.filter(function(z){return z.ok}).length*60);
      if(P.every(function(z){return z.ok})){fin=true;skip.remove();hint.textContent='✦ Disque réparé ✦';try{__gl.cd();__gl.face()}catch(x){}sparkle();hint.remove();unmute();end();try{goldSite()}catch(x){}}}})}
   // version cassée : tout le site en noir et blanc fissuré, la musique se dérègle, jusqu'au rechargement
   if(k==='cas'){document.documentElement.classList.add('dsh-cas');var bw=document.createElement('div');bw.id='dshbw';document.documentElement.appendChild(bw);
    var ck=document.createElement('canvas');ck.id='dshk';ck.width=Math.round(W*dpr);ck.height=Math.round(H*dpr);document.documentElement.appendChild(ck);var c2=ck.getContext('2d');c2.setTransform(dpr,0,0,dpr,0,0);c2.lineCap='round';
    var walk=function(x,y,a,L,w,al){c2.beginPath();c2.moveTo(x,y);var s=0;while(s<L){var st=rn(10,22);a+=rn(-.12,.12);x+=Math.cos(a)*st;y+=Math.sin(a)*st;s+=st;c2.lineTo(x,y)}c2.strokeStyle='rgba(0,0,0,'+al+')';c2.lineWidth=w+1.2;c2.stroke();c2.strokeStyle='rgba(255,255,255,'+al+')';c2.lineWidth=w;c2.stroke()};
    for(var i=0;i<14;i++)walk(X,Y,i/14*6.2832+rn(-.2,.2),rn(120,Math.max(W,H)*.8),1.2,.55);for(var j=0;j<10;j++)walk(rn(0,W),rn(0,H),rn(0,6.3),rn(80,300),.8,.35);
    try{if(window.FXm)FXm.force('casse')}catch(e){}try{if(window.SND)SND.broke(true)}catch(e){}
    var t1=performance.now();setInterval(function(){var q=(performance.now()-t1)/1000;window.BRKW=.74+.07*Math.sin(q*1.7)+.04*Math.sin(q*5.3);try{if(window.SND)SND.sync()}catch(e){}},160)}
   // gravité : tout le site s'effondre puis se reconstruit morceau par morceau
   if(k==='gra'){var els=[].slice.call(document.querySelectorAll('header > *, .hero h1, .hero p, .hero .hint, .dsw, main > section > *, main .card, footer > *')).filter(function(el){var b=el.getBoundingClientRect();return b.width&&b.height&&b.bottom>0&&b.top<H&&el.animate});
    els.slice(0,60).forEach(function(el,i){var b=el.getBoundingClientRect(),dy=Math.max(40,H-b.bottom-rn(0,30)),rot=rn(-18,18),del=rn(0,500);
     el.animate([{transform:'none'},{transform:'translateY('+dy+'px) rotate('+rot+'deg)',offset:.75},{transform:'translateY('+(dy-14)+'px) rotate('+(rot*.8)+'deg)',offset:.87},{transform:'translateY('+dy+'px) rotate('+rot+'deg)'}],{duration:1100,delay:del,easing:'cubic-bezier(.55,0,1,.45)',fill:'forwards'});
     setTimeout(function(){var a2=el.animate([{transform:'translateY('+dy+'px) rotate('+rot+'deg)'},{transform:'none'}],{duration:700,delay:i*70,easing:'cubic-bezier(.2,.8,.3,1.15)',fill:'forwards'});a2.onfinish=function(){try{el.getAnimations().forEach(function(x){x.cancel()})}catch(e){}}},4300)})}
   raf=requestAnimationFrame(step)};
  var sd=d,nz=false;if(k==='puz'){try{sd=PONG._t.myth('noir');nz=true}catch(x){sd=d}}
  if(window.__gl&&__gl.shots&&sd)__gl.shots([sd],{still:Math.max(160,Math.round(R*2)),flat:1}).then(function(o){var im=o&&o[sd.k]&&o[sd.k].still||null;if(im&&nz)try{var f=im._f;im=PONG._t.noirize(im);im._f=f}catch(x){}start(im)}).catch(function(){start(null)});else start(null);
  setTimeout(counter,1300)}
})();

/* n°6 : l'écharpe cachée -> à poser sur « yuu » */
var SCF=false,SCV='<svg viewBox="0 0 60 40" aria-hidden="true"><path d="M22 18L33 17L35 34L24 35Z" fill="#060608" stroke="rgba(255,255,255,.3)" stroke-width="1.2" stroke-linejoin="round"/><path d="M33 17L43 16L47 32L36 34Z" fill="#060608" stroke="rgba(255,255,255,.3)" stroke-width="1.2" stroke-linejoin="round"/><path d="M25 35v3M28 35v3M31 35v3M37 34v3M40 34v3M43 33v3M46 32v3" stroke="rgba(255,255,255,.4)" stroke-width="1.1" stroke-linecap="round"/><path d="M2 11Q14 2 30 9T58 7L58 17Q44 24 30 18T2 19Z" fill="#060608" stroke="rgba(255,255,255,.3)" stroke-width="1.2" stroke-linejoin="round"/><path d="M6 13Q16 7 30 12T54 10" fill="none" stroke="rgba(255,255,255,.14)" stroke-width="1"/></svg>';
(function(){
 var SP=[['#contact','left:2%;bottom:.5rem;transform:rotate(9deg)'],['footer','right:9%;top:-20px;transform:rotate(-6deg)']];
 var SPI=Math.floor(Math.random()*SP.length);
 function place(){if(!S.eg6||!S.eg6.on||ESCON||SCF)return;[SP[SPI]].forEach(function(s){var host=document.querySelector(s[0]);if(!host||host.querySelector(':scope>.scf'))return;var b=document.createElement('button');b.type='button';b.className='scf';b.tabIndex=-1;b.setAttribute('aria-hidden','true');b.setAttribute('style',s[1]);b.innerHTML=SCV;b.addEventListener('pointerdown',pick);host.appendChild(b)})}
 function clearS(){document.querySelectorAll('.scf').forEach(function(x){x.remove()})}
 var DRG6=false,LY=0;
 function mv(e){var c=$('scfc');LY=e.clientY;if(c&&c.classList.contains('fol')){c.style.left=e.clientX+'px';c.style.top=e.clientY+'px'}}
 function auto(){if(!DRG6)return;if(LY<100)scrollBy({top:-16,behavior:'instant'});else if(LY>innerHeight-100)scrollBy({top:16,behavior:'instant'});requestAnimationFrame(auto)}
 function rel(){if(!DRG6)return;DRG6=false;var c=$('scfc');if(c){c.classList.remove('fol');c.style.left='';c.style.top=''}}
 function pick(e){if(SCF)return;e.preventDefault();e.stopPropagation();SCF=true;document.querySelectorAll('.scf').forEach(function(x){x.style.visibility='hidden'});var c=document.createElement('div');c.id='scfc';c.innerHTML=SCV+'<span></span>';c.querySelector('span').textContent=S.eg6.tk||'';document.body.appendChild(c);
  var fine=window.matchMedia&&matchMedia('(hover:hover) and (pointer:fine)').matches;if(fine){c.classList.add('fol');mv(e)}if(window.SND)SND.play('tap',3)}
 function drop(){SCF=false;DRG6=false;ESCON=true;var c=$('scfc');if(c)c.remove();clearS();render();
  var b=document.querySelector('header b');if(b&&!b.querySelector('.scfy')){var y=document.createElement('span');y.className='scfy';y.innerHTML=SCV;b.appendChild(y)}
  toast(S.eg6.ok||'');if(window.SND)SND.play('egg');setTimeout(function(){var s=$('boutique');if(s&&s.scrollIntoView)s.scrollIntoView({behavior:'smooth',block:'start'})},1700)}
 addEventListener('pointermove',mv);
 addEventListener('pointerup',function(e){if(!SCF)return;var t=document.elementFromPoint(e.clientX,e.clientY);if(t&&t.closest&&t.closest('header b'))drop();else rel()},true);
 addEventListener('pointercancel',rel,true);
 window.scfReset=function(){SCF=false;ESCON=false;var c=$('scfc');if(c)c.remove();var y=document.querySelector('.scfy');if(y)y.remove();render()};
 window.scfShow=function(){drop()};
 var _r=render;render=function(){_r.apply(this,arguments);try{place()}catch(e){}};
 place()})();
/* n°7 : le petit chat noir -> une photo */
(function(){
 var CAT='<svg viewBox="0 0 44 44" aria-hidden="true"><path d="M30 41C42 41 44 30 38 25" fill="none" stroke="#060608" stroke-width="4" stroke-linecap="round"/><path d="M9 43C5 31 10 21 21 21C31 21 35 31 31 43Z" fill="#060608" stroke="rgba(255,255,255,.2)" stroke-width="1"/><circle cx="21" cy="14.5" r="8" fill="#060608" stroke="rgba(255,255,255,.2)" stroke-width="1"/><path d="M13.5 10L14.2 1.5L19.5 7Z M28.5 10L27.8 1.5L22.5 7Z" fill="#060608" stroke="rgba(255,255,255,.2)" stroke-width="1" stroke-linejoin="round"/><ellipse class="ey" cx="17.8" cy="14.5" rx="1.2" ry="1.8" fill="#f3d36b" opacity=".8"/><ellipse class="ey" cx="24.2" cy="14.5" rx="1.2" ry="1.8" fill="#f3d36b" opacity=".8"/></svg>';
 function place(){var e=S.eg7;if(!e||!e.on||!(e.img||OWN))return;var host=document.querySelector('#clip');if(!host||host.querySelector(':scope>.cat7'))return;var b=document.createElement('button');b.type='button';b.className='cat7';b.tabIndex=-1;b.setAttribute('aria-hidden','true');b.innerHTML=CAT;b.addEventListener('click',function(){window.catOpen()});host.appendChild(b);pos()}
 function pos(){var b=document.querySelector('.cat7'),c=document.querySelector('#clv .clc'),hs=$('clip');if(!b||!c||!hs)return;var r=c.getBoundingClientRect(),hr=hs.getBoundingClientRect();if(!r.width)return;b.style.right='auto';b.style.left=Math.round(r.left-hr.left+r.width*.72)+'px';b.style.top=Math.round(r.top-hr.top-33)+'px'}
 addEventListener('resize',pos);setTimeout(pos,800);setTimeout(pos,2500);try{var cv=$('clv');if(cv)new MutationObserver(pos).observe(cv,{childList:true,subtree:true});if(window.ResizeObserver&&$('clip'))new ResizeObserver(pos).observe($('clip'))}catch(e){}
 window.catClose=function(){var o=$('cph');if(o)o.remove()};
 window.catOpen=function(){if($('cph'))return;var o=document.createElement('div');o.id='cph';o.setAttribute('role','dialog');
  if(S.eg7.img){var i=document.createElement('img');i.alt='';i.src=safeImg(S.eg7.img);o.appendChild(i)}else{var m=document.createElement('p');m.textContent='Aucune photo pour l’instant : ajoute-la dans Personnaliser > Secrets > Secret n°7.';o.appendChild(m)}
  if(S.eg7.cap){var p=document.createElement('p');p.textContent=S.eg7.cap;o.appendChild(p)}
  var kc=String(S.cart.code||'').trim();if(kc){var d=document.createElement('div');d.className='ccd';d.innerHTML='<span></span><b></b><button type="button"></button>';d.querySelector('span').textContent=S.eg7.ctx||'';d.querySelector('b').textContent=kc.toUpperCase();var bt=d.querySelector('button');bt.textContent='Appliquer à mon panier';bt.addEventListener('click',function(ev){ev.stopPropagation();cCodeSet(kc);try{toast('Code '+kc.toUpperCase()+' appliqué à ton panier')}catch(x){}bt.textContent='✓ Appliqué';bt.disabled=true});d.addEventListener('click',function(ev){ev.stopPropagation()});o.appendChild(d)}
  var s=document.createElement('small');s.textContent='touche pour fermer';o.appendChild(s);o.addEventListener('click',catClose);document.body.appendChild(o);if(window.SND)SND.play('egg')};
 addEventListener('keydown',function(e){if(e.key==='Escape')catClose()});
 var _r2=render;render=function(){_r2.apply(this,arguments);try{place()}catch(e){}};
 place()})();
/* compte client : lien vers le portail Stripe */
function acctUpd(){var a=$('ac');if(!a||!S.acct)return;var on=!!S.acct.on&&/^https:\/\//i.test(String(S.acct.url||'').trim());a.hidden=!on;if(on){a.href=String(S.acct.url).trim();a.setAttribute('aria-label',S.acct.lbl||'Mon compte');a.title=S.acct.lbl||'Mon compte'}}
(function(){var _r3=render;render=function(){_r3.apply(this,arguments);try{acctUpd()}catch(e){}};acctUpd()})();
/* ================= panier ================= */
var CART=[];try{CART=JSON.parse(localStorage.getItem('yuu-cart')||'[]');if(!Array.isArray(CART))CART=[]}catch(e){CART=[]}
function cSave(){try{localStorage.setItem('yuu-cart',JSON.stringify(CART))}catch(e){}}
function num(v){var n=parseFloat(String(v==null?'':v).replace(',','.').replace(/[^\d.]/g,''));return isFinite(n)?n:0}
function eur(n){n=Math.round(n*100)/100;return n.toLocaleString('fr-FR',{minimumFractionDigits:n%1?2:0,maximumFractionDigits:2})}
function cItems(){return CART.map(function(c){var p=S.products.filter(function(x){return x.s===c.s})[0];return p?{p:p,q:c.q}:null}).filter(Boolean)}
var CCODE='';try{CCODE=localStorage.getItem('yuu-code')||''}catch(e){}
function cCodeOk(){var k=String(S.cart.code||'').trim().toUpperCase();return !!k&&String(CCODE).trim().toUpperCase()===k}
function cCodeSet(v){CCODE=v||'';try{if(CCODE)localStorage.setItem('yuu-code',CCODE);else localStorage.removeItem('yuu-code')}catch(e){}if(!$('cart').hidden)cartRender()}
function cSub(){return cItems().reduce(function(a,x){return a+num(x.p.p)*x.q},0)}
function cartUpd(){var n=cItems().reduce(function(a,x){return a+x.q},0),b=$('cb');if(!b)return;b.hidden=!S.cart.on;$('cn').textContent=n;$('cn').hidden=!n;if(!$('cart').hidden)cartRender()}
function cartOpen(on){var c=$('cart');c.hidden=!on;if(on)cartRender();if(!on&&location.hash==='#panier')history.replaceState(null,'',location.pathname+location.search)}
function cartRender(){var el=$('ci'),ft=$('cf'),its=cItems();
 if(!its.length){el.innerHTML='<p class="ce">'+esc(S.tx.cartEmpty)+'</p>';ft.innerHTML='<button type="button" class="btn alt" data-cc>'+esc(S.tx.cartCont)+'</button>';return}
 el.innerHTML=its.map(function(x){return '<div class="cr2"><span class="ct" style="'+bgj(x.p,0)+'"></span><div class="cd"><b>'+esc(x.p.n)+'</b><span>'+esc(x.p.p)+' '+esc(S.tx.cur)+'</span></div><div class="cq"><button type="button" data-cm="'+esc(x.p.s)+'" aria-label="Moins">−</button><span>'+x.q+'</span><button type="button" data-cp="'+esc(x.p.s)+'" aria-label="Plus">+</button></div><button type="button" class="cz" data-cd="'+esc(x.p.s)+'" aria-label="Retirer">✕</button></div>'}).join('');
 var sub=cSub(),free=num(S.cart.free),m='',bar='';
 var hasC=!!String(S.cart.code||'').trim(),okC=cCodeOk();
 if(okC){m=S.tx.cartCodeOk}else if(free>0){m=sub>=free?S.tx.cartFreeOk:String(S.tx.cartFreeMsg).replace('{x}',eur(free-sub));bar='<div class="cbar"><i style="width:'+Math.min(100,sub/free*100)+'%"></i></div>'}
 var pr=!hasC?'':(okC?'<button type="button" class="lk" data-cprm>'+esc(S.tx.cartCodeRm)+' ('+esc(String(CCODE).toUpperCase())+')</button>':'<div class="cpr"><input type="text" id="cpi" placeholder="'+esc(S.tx.cartCodePh)+'" autocomplete="off" autocapitalize="characters" spellcheck="false"><button type="button" class="btn alt" data-cpromo>'+esc(S.tx.cartCodeBtn)+'</button></div>');
 ft.innerHTML='<div class="cl"><span>'+esc(S.tx.cartTot)+'</span><b>'+eur(sub)+' '+esc(S.tx.cur)+'</b></div>'+bar+(m?'<p class="cm">'+esc(m)+'</p>':'')+pr+'<p class="cs">'+esc(S.tx.cartShipNote)+'</p><button type="button" class="btn big" data-cpay>'+esc(S.tx.cartPay)+'</button><button type="button" class="lk" data-cc>'+esc(S.tx.cartCont)+'</button>'}
function cartAdd(s,d){var c=CART.filter(function(x){return x.s===s})[0];if(c){c.q=Math.max(0,Math.min(10,c.q+d))}else if(d>0)CART.push({s:s,q:1});CART=CART.filter(function(x){return x.q>0});cSave();cartUpd()}
document.addEventListener('click',function(e){var T=e.target.closest&&e.target.closest('[data-add],[data-cm],[data-cp],[data-cd],[data-cc],[data-cpay],[data-cpromo],[data-cprm],#cb');if(!T)return;
 if(T.hasAttribute('data-cprm')){cCodeSet('');return}
 if(T.hasAttribute('data-cpromo')){var iv=($('cpi')||{}).value||'';if(iv.trim().toUpperCase()===String(S.cart.code||'').trim().toUpperCase()&&iv.trim()){cCodeSet(iv.trim())}else{try{toast(S.tx.cartCodeBad)}catch(x){}}return}
 if(T.id==='cb'){cartOpen(true);return}
 if(T.hasAttribute('data-add')){if(OWN&&!EDIT&&e.detail>1)return;cartAdd(T.dataset.add,1);var n=$('cn');n.classList.remove('bump');void n.offsetWidth;n.classList.add('bump');try{toast(S.tx.cartAdded)}catch(x){}cartOpen(true);return}
 if(T.hasAttribute('data-cm')){cartAdd(T.dataset.cm,-1);return}if(T.hasAttribute('data-cp')){cartAdd(T.dataset.cp,1);return}
 if(T.hasAttribute('data-cd')){var q=CART.filter(function(x){return x.s===T.dataset.cd})[0];if(q)cartAdd(q.s,-q.q);return}
 if(T.hasAttribute('data-cc')){cartOpen(false);return}
 if(T.hasAttribute('data-cpay')){if(T.disabled)return;T.disabled=true;var l0=T.textContent;T.textContent='…';
  fetch('/.netlify/functions/checkout',{method:'POST',headers:Object.assign({'Content-Type':'application/json'},S.mt&&/^\d{10}\.[a-f0-9]{64}$/.test(S.mt.k||'')?{'X-Yuu-K':S.mt.k}:{}),body:JSON.stringify({items:CART,code:cCodeOk()?CCODE:''})}).then(function(r){if(r.status===404)throw new Error('Fonction de paiement non installée sur ce site (dossier netlify/ manquant).');return r.json()}).then(function(j){if(j&&typeof j.url==='string'&&/^https:\/\/checkout\.stripe\.com\//.test(j.url)){location.href=j.url}else throw new Error((j&&typeof j.error==='string'&&j.error)||'x')}).catch(function(e){T.disabled=false;T.textContent=l0;var m=e&&e.message&&e.message!=='x'&&!/JSON|fetch|Unexpected/i.test(e.message)?' ('+e.message+')':'';if(cartDirect())return;try{toast(S.tx.cartErr+(OWN?m:''))}catch(x){}})}});
function cartDirect(){var its=cItems().filter(function(x){return /^https:\/\//i.test(safeUrl(x.p.pay||''))});if(!its.length||its.length!==cItems().length)return false;
 if(its.length===1&&its[0].q===1){location.href=safeUrl(its[0].p.pay);return true}
 var ft=$('cf');if(!ft)return false;ft.innerHTML='<p class="cn2">'+esc(S.tx.cartSplit||'Paiement article par article :')+'</p>'+its.map(function(x){return '<a class="btn" style="display:block;text-align:center;margin:.4rem 0" target="_blank" rel="noopener" href="'+esc(safeUrl(x.p.pay))+'">'+esc(x.p.n)+(x.q>1?' ×'+x.q:'')+' · '+esc(x.p.p)+' '+esc(S.tx.cur)+'</a>'}).join('')+'<button type="button" class="lk" data-cc>'+esc(S.tx.cartCont)+'</button>';return true}
document.addEventListener('keydown',function(e){if(e.key==='Escape'&&!$('cart').hidden)cartOpen(false)});

/* ================= double-clic : modifier un texte directement (propriétaire) ================= */
var clickT=null,asT=null,INLCH=false;
function autoSave(){clearTimeout(asT);asT=setTimeout(function(){if(!(art&&OWN)||EDIT)return;try{toast('Enregistrement…')}catch(e){}save()},900)}
document.addEventListener('click',function(e){var th=e.target.closest&&e.target.closest('.th');if(!th)return;var h=hdec(),p=S.products.filter(function(x){return x.s===h})[0];if(!p)return;GI=+th.dataset.gi||0;var m=$('gm');if(m){m.style.opacity=.15;setTimeout(function(){m.setAttribute('style',bgj(p,GI));m.style.opacity=1},150)}document.querySelectorAll('#prod .th').forEach(function(x){x.classList.toggle('on',x===th)})});
document.addEventListener('dblclick',function(e){
 if(!OWN||EDIT||!e.target.closest)return;var el=e.target.closest('[data-pi]');if(!el)return;e.preventDefault();clearTimeout(clickT);
 var p=S.products[+el.dataset.pi];if(!p)return;var j=el.id==='gm'?GI:0,f=document.createElement('input');f.type='file';f.accept='image/*';
 f.onchange=function(){up(f.files[0],function(u){p.imgs=p.imgs||[];if(j<p.imgs.length)p.imgs[j]=u;else p.imgs.push(u);dirty();render();autoSave()},{max:1600})};f.click()});
document.addEventListener('click',function(e){
 if(!OWN||EDIT||!e.target.closest)return;var a=e.target.closest('a[data-p],a[data-pi]');if(!a||a.isContentEditable)return;
 e.preventDefault();e.stopImmediatePropagation();
 if(e.detail>1){clearTimeout(clickT);return}
 clearTimeout(clickT);clickT=setTimeout(function(){var h=a.getAttribute('href')||'';
  if(a.target==='_blank'){var ta=document.createElement('a');ta.href=h;ta.target='_blank';ta.rel='noopener';document.body.append(ta);ta.click();ta.remove()}else if(h.charAt(0)==='#'){if(location.hash==='#'+h.slice(1)||(h==='#top'&&location.hash==='#top')){route();scrollTo(0,0)}else location.hash=h.slice(1)}else location.href=h},260)},true);
function inlineEdit(el){
 clearTimeout(clickT);clearTimeout(asT);INLCH=false;
 try{el.contentEditable='plaintext-only'}catch(x){}if(el.contentEditable!=='plaintext-only')el.contentEditable='true';
 el.spellcheck=false;el.classList.add('inl');el.focus();
 try{var r=document.createRange();r.selectNodeContents(el);var s=getSelection();s.removeAllRanges();s.addRange(r)}catch(x){}
 var done=function(){el.removeEventListener('blur',done);el.removeAttribute('contenteditable');el.classList.remove('inl');render();if(INLCH){INLCH=false;autoSave()}};
 el.addEventListener('blur',done)}
document.addEventListener('dblclick',function(e){
 if(!OWN||EDIT||!e.target.closest)return;var el=e.target.closest('[data-p]');if(!el||el.isContentEditable)return;e.preventDefault();inlineEdit(el)});
(function(){var lt=0,le=null;document.addEventListener('pointerup',function(e){if(e.pointerType!=='touch'||!OWN||EDIT||!e.target.closest)return;var el=e.target.closest('[data-p]');if(!el||el.isContentEditable){le=null;return}var n=performance.now();if(le===el&&n-lt<400){le=null;inlineEdit(el);return}le=el;lt=n},true)})();
FXm.apply();SND.ui();mtRender();

/* ================= écriture directement sur la page ================= */
document.addEventListener('click',function(e){if(EDIT&&e.target.closest&&e.target.closest('[data-p]')&&e.target.closest('a'))e.preventDefault()},true);
document.addEventListener('keydown',function(e){
 if(!(EDIT||OWN)||e.key!=='Enter'||!e.target.closest)return;var el=e.target.closest('[data-p]');
 if(el&&!el.hasAttribute('data-ml')){e.preventDefault();el.blur()}
});
document.addEventListener('input',function(e){
 if(!(EDIT||OWN)||!e.target.closest)return;var el=e.target.closest('[data-p]');if(!el||!el.isContentEditable)return;
 var v=el.innerText.replace(/ /g,' ');if(!el.hasAttribute('data-ml'))v=v.replace(/\s*\n\s*/g,' ');
 var path=el.dataset.p;sp(S,path,v);
 document.querySelectorAll('[data-p="'+path+'"]').forEach(function(o){if(o!==el)o.textContent=v});
 if(path==='name'||path==='tx.tab'||/^products\.\d+\.n$/.test(path))docTitle();
 dirty();INLCH=true;
});
document.addEventListener('focusout',function(e){
 if(!EDIT||!e.target.closest||!e.target.closest('[data-p]'))return;
 setTimeout(function(){var p=$('pn');if(p&&!p.hidden&&!p.contains(document.activeElement))refresh()},0);
});

/* ================= panneau de personnalisation ================= */
function fmt(v){return String(Math.round(v*100)/100)}
function dirty(){try{mqUpd()}catch(e){}var b=$('sv');if(b)b.disabled=false;msg('Modifications non enregistrées. Pense à publier.')}
function msg(t){var m=$('ms');if(m)m.textContent=t}
function after(){dirty();render();refresh()}
function refresh(){var b=$('pb');if(!b)return;var y=b.scrollTop;fillBody();b.scrollTop=y}
function ib(txt,tip,fn){var b=mk('button',{className:'ib',textContent:txt,title:tip,onclick:fn});b.setAttribute('aria-label',tip);return b}
function btn(txt,fn,cls){return mk('button',{className:cls||'act',textContent:txt,onclick:fn})}
function mv(arr,j,d){var k=j+d;if(k<0||k>=arr.length)return;var t=arr[j];arr[j]=arr[k];arr[k]=t;after()}
function rowBtns(arr,j){return [ib('↑','Monter',function(){mv(arr,j,-1)}),ib('↓','Descendre',function(){mv(arr,j,1)}),ib('✕','Supprimer',function(){arr.splice(j,1);after()})]}
var GN=0,OPG={};
function syncToc(){var n=document.querySelector('#pb .toc');if(!n)return;n.querySelectorAll('.tc[data-n]').forEach(function(b){var g=document.querySelector('#pb details.g[data-n="'+b.dataset.n+'"]');b.classList.toggle('on',!!(g&&g.open))})}
function G(title,hint,open){var key=TAB+':'+title,def=open!=null?open:GN===0;GN++;
 var g=mk('details',{className:'g'});g.dataset.n=GN;g.open=key in OPG?OPG[key]:def;g.addEventListener('toggle',function(){OPG[key]=g.open;syncToc()});
 g.append(mk('summary',{},[mk('span',{className:'gn',textContent:GN}),mk('h5',{textContent:title})]));if(hint)g.append(mk('p',{className:'gh',textContent:hint}));return g}
function sub(title,hint,open){var key=TAB+':s:'+OPEND+':'+title,d=mk('details',{className:'sub'});d.open=key in OPG?OPG[key]:(open!=null?open:(TAB==='cd'&&OPEND!=null?/^1 ·/.test(title):true));d.addEventListener('toggle',function(){OPG[key]=d.open});
 d.append(mk('summary',{},[mk('b',{textContent:title})]));if(hint)d.append(mk('p',{className:'fh',textContent:hint}));return d}
function lab(t){return mk('span',{className:'fl',textContent:t})}
function fld(o,k,label,t,x){
 x=x||{};var arr=Array.isArray(o[k]),i,out=null,val=arr?o[k].join('\n'):o[k];if(val==null)val='';
 if(t==='a')i=mk('textarea',{rows:x.rows||3,value:val});
 else if(t==='c')i=mk('input',{type:'color',value:val});
 else if(t==='r'){i=mk('input',{type:'range',min:x.min,max:x.max,step:x.step,value:val});out=mk('output',{textContent:fmt(val)})}
 else i=mk('input',{type:'text',value:val});
 i.oninput=function(){var v=i.value;if(arr)v=v.split('\n').filter(Boolean);else if(t==='r'){v=+v;out.textContent=fmt(v)}o[k]=v;dirty();render()};
 return mk('label',{className:'f'},[mk('span',{className:'fl'},out?[label,out]:[label]),x.hint?mk('p',{className:'fh',textContent:x.hint}):null,i]);
}
function colFld(label,get,set,hint){var i=mk('input',{type:'color',value:get()});i.oninput=function(){set(i.value);dirty();render()};
 return mk('label',{className:'f'},[lab(label),hint?mk('p',{className:'fh',textContent:hint}):null,i])}
function chkF(o,k,label){var i=mk('input',{type:'checkbox',checked:!!o[k]});i.onchange=function(){o[k]=i.checked;after()};return mk('label',{className:'chk'},[i,mk('span',{textContent:label})])}
function strList(arr,addTxt){
 var box=mk('div');
 arr.forEach(function(v,j){var i=mk('input',{type:'text',value:v});i.oninput=function(){arr[j]=i.value;dirty();render()};box.append(mk('div',{className:'lr'},[i].concat(rowBtns(arr,j))))});
 box.append(btn(addTxt,function(){arr.push('');after()},'add'));return box;
}
function prep(file,o){return new Promise(function(res){
 var url=URL.createObjectURL(file),im=new Image();
 im.onload=function(){URL.revokeObjectURL(url);
  var s=Math.min(1,o.max/Math.max(im.width,im.height)),isPng=file.type==='image/png',isJpg=file.type==='image/jpeg';
  if(s===1&&file.size<3.5e6&&(o.png?isPng:(isPng||isJpg))){res(file);return}
  var keepPng=o.png||(!o.jpg&&isPng),cv=document.createElement('canvas');cv.width=Math.round(im.width*s);cv.height=Math.round(im.height*s);
  var g=cv.getContext('2d');g.imageSmoothingQuality='high';g.drawImage(im,0,0,cv.width,cv.height);
  cv.toBlob(function(b){res(b||file)},keepPng?'image/png':'image/jpeg',.94)};
 im.onerror=function(){URL.revokeObjectURL(url);res(file)};im.src=url})}
function up(file,cb,o){
 if(!file)return;if(!asg){msg('Import d’images indisponible ici.');return}
 msg('Import de l’image…');
 prep(file,o||{max:2000}).then(function(b){return asg.upload(b)}).then(function(r){cb(r.url);msg('Image importée. Pense à publier.')},function(e){msg('Import impossible : '+(e&&(e.message||e.code)||'erreur'))});
}
function danger(label,sure,fn){var b=mk('button',{className:'danger',textContent:label}),t=null;
 b.onclick=function(){if(t){clearTimeout(t);fn();return}b.textContent=sure;t=setTimeout(function(){t=null;b.textContent=label},4000)};return b}
function uid(){return 'p-'+Date.now().toString(36)+Math.floor(Math.random()*1e3).toString(36)}

function tabTxt(B){
 B.append(mk('p',{className:'fh',textContent:'Astuce : double-clique sur un texte du site pour le modifier sur place (Entrée valide). Tu peux aussi cocher « Écrire directement sur la page » ci-dessus pour que tout soit modifiable d’un simple clic.'}));
 var g=G('En haut de la page');
 g.append(fld(S,'name','Nom en haut à gauche','t'),fld(S.tx,'nav','Lien en haut à droite','t'),fld(S.tx,'tab','Fin du titre de l’onglet du navigateur','t',{hint:'S’affiche après ton nom, par exemple « yuu – Boutique ».'}));B.append(g);
 g=G('Grand écran avec le disque');
 g.append(fld(curDisc(),'t','Titre derrière le disque (disque affiché)','t'),fld(S.tx,'hint','Phrase sous le disque','t'));B.append(g);
 g=G('Section boutique');
 g.append(fld(S.tx,'shopH','Titre de la section','t'),fld(S,'intro','Texte sous le titre','a'),fld(S.tx,'view','Bouton des cartes produit','t'),fld(S.tx,'feat','Étiquette du produit mis en avant','t'),fld(S.tx,'cur','Symbole de la monnaie','t'));B.append(g);
 g=G('Page d’un produit');
 g.append(fld(S.tx,'back','Lien de retour','t'),fld(S.tx,'buy','Bouton pour commander','t'),fld(S.tx,'moreH','Titre « autres produits » en bas de la page','t'),fld(S.tx,'thanks','Message après un paiement réussi (adresse /#merci)','t'));B.append(g);
 g=G('Comment commander','Cette partie apparaît sur l’accueil et sur chaque page produit.');
 g.append(fld(S.tx,'stepsH','Titre','t'),lab('Étapes'),strList(S.tx.steps,'+ Ajouter une étape'),fld(S.tx,'note','Note sous les étapes','a',{rows:2}));B.append(g);
 g=G('À propos');g.append(fld(S.tx,'aboutH','Titre','t'),fld(S,'about','Texte','a',{rows:5}));B.append(g);
 g=G('Bas de page');g.append(fld(S.tx,'foot','Texte à gauche','t'),lab('Liens à droite'));
 S.tx.links.forEach(function(l,j){var a=mk('input',{type:'text',value:l.t,placeholder:'Nom'}),u=mk('input',{type:'text',value:l.u,placeholder:'Adresse (https://…)'});
  a.oninput=function(){l.t=a.value;dirty();render()};u.oninput=function(){l.u=u.value;dirty();render()};
  g.append(mk('div',{className:'lr'},[a].concat(rowBtns(S.tx.links,j))),mk('div',{className:'lr'},[u]))});
 g.append(btn('+ Ajouter un lien',function(){S.tx.links.push({t:'Lien',u:'#'});after()},'add'));B.append(g);
}
function selF(o,k,label,opts,hint){var s=mk('select');opts.forEach(function(x){s.append(mk('option',{value:x[0],textContent:x[1]}))});s.value=o[k];
 s.onchange=function(){o[k]=s.value;dirty();render()};return mk('label',{className:'f'},[lab(label),hint?mk('p',{className:'fh',textContent:hint}):null,s])}
var OPEND=null,CDK=[['holo','Reflets irisés',0,1,.02],['grain','Paillettes',0,1,.02],['relief','Relief (texture carte holo)',0,1,.02],['cen','Visibilité du centre (0 = invisible)',0,1,.02],['edge','Visibilité du bord (0 = invisible)',0,1,.02],['hole','Taille du trou central',.03,.22,.005],['fit','Rognage du bord de l’image (fond blanc)',.8,1,.01],['glare','Reflets de lumière blanche',0,2,.05],['la','Direction de la lumière',0,6.28,.05]],
 TIK=[['holo','Reflets irisés',0,1,.02],['grain','Paillettes',0,1,.02],['rock','Relief rocheux 3D',0,1,.02],['glare','Reflets de lumière blanche',0,2,.05],['la','Direction de la lumière',0,6.28,.05]];
function sliders(box,o,keys){keys.forEach(function(k){box.append(fld(o,k[0],k[1],'r',{min:k[2],max:k[3],step:k[4]}))})}
function copyAll(prop,src){S.discs.forEach(function(x){x[prop]=JSON.parse(JSON.stringify(src))});after();msg('Réglages copiés sur tous les disques.')}
function ownBlock(d,prop,base,keys,title,hint,sc){
 var box=sub(title,hint),own=!!d[prop];
 var i=mk('input',{type:'checkbox',checked:own});i.onchange=function(){if(i.checked)d[prop]=sc(d);else delete d[prop];after()};
 box.append(mk('label',{className:'chk'},[i,mk('span',{textContent:'Réglages propres à ce disque'})]));
 if(own){sliders(box,d[prop],keys);box.append(btn('Copier sur tous les disques',function(){copyAll(prop,d[prop])}))}
 else box.append(mk('p',{className:'fh',textContent:'Ce disque utilise les réglages communs.'}));
 return box}
function showDisc(d){if(d&&d.myt){window.DSHG=d;if(window.__gl){__gl.cd();__gl.front(1500)}return}if(window.DSHG&&window.DSHG.myt&&!window.DSHK){window.DSHG=null;if(window.__gl)__gl.cd()}if(vis().indexOf(d)<0){EGGON=true;dsig='';dswSync()}pick(vis().indexOf(d))}
function discFx(d){var box=sub('6 · Animation : shader et rotation de ce disque','Quand ce disque est affiché, le shader du site et la vitesse de rotation peuvent changer. Chaque disque a les siens.');
 var i=mk('input',{type:'checkbox',checked:!!d.fx});i.onchange=function(){if(i.checked)d.fx={mode:S.fx.mode,spd:S.fx.spd==null?1:S.fx.spd,amt:S.fx.amt,sheen:S.fx.sheen,grain:S.fx.grain,vig:S.fx.vig};else delete d.fx;after()};
 box.append(mk('label',{className:'chk'},[i,mk('span',{textContent:'Shader propre à ce disque'})]));
 if(d.fx){box.append(selF(d.fx,'mode','Shader',fxOpts()));sliders(box,d.fx,[['spd','Vitesse du mouvement',0,3,.05],['amt','Intensité globale',0,1,.05],['sheen','Force de l’effet principal',0,1,.05],['grain','Grain',0,1,.05],['vig','Vignette (bords sombres)',0,1,.05]]);box.append(btn('Copier sur tous les disques',function(){copyAll('fx',d.fx)}))}
 else box.append(mk('p',{className:'fh',textContent:'Ce disque utilise le shader commun (onglet Apparence).'}));
 var r=mk('input',{type:'checkbox',checked:typeof d.rs==='number'});r.onchange=function(){if(r.checked)d.rs=S.spd;else delete d.rs;after()};
 box.append(mk('label',{className:'chk'},[r,mk('span',{textContent:'Vitesse de rotation propre à ce disque'})]));if(typeof d.rs==='number')box.append(fld(d,'rs','Vitesse de rotation','r',{min:0,max:3,step:.05}));
 return box}
function discTh(d){var box=sub('5 · Couleurs du site pour ce disque','Quand ce disque est affiché, ces couleurs remplacent les couleurs communes (onglet Apparence). Laisse vide pour garder les communes.');
 var cs=getComputedStyle(document.documentElement);
 function cur(k){var v=cs.getPropertyValue('--'+k).trim();return /^#[0-9a-f]{6}$/i.test(v)?v:'#000000'}
 [['accent','Boutons et accents'],['onaccent','Texte des boutons'],['ink','Texte principal'],['muted','Texte secondaire'],['card','Cartes et blocs'],['line','Traits et bordures'],['tcol','Titre derrière le disque']].forEach(function(c){
  box.append(colFld(c[1],function(){return (d.th&&d.th[c[0]])||cur(c[0])},function(v){d.th=d.th||{};d.th[c[0]]=v}))});
 box.append(btn('Revenir aux couleurs communes',function(){delete d.th;after()}));return box}
function discBg(d){var box=sub('4 · Fond de la page quand ce disque est affiché','Couleur et image de fond de tout le site pour ce disque. Sans réglage propre, le fond commun (onglet Apparence) est utilisé.');
 var ci=mk('input',{type:'color',value:/^#[0-9a-f]{6}$/i.test(d.bgc||'')?d.bgc:(/^#[0-9a-f]{6}$/i.test(S.th.bg||'')?S.th.bg:'#e8e4f3'),oninput:function(){d.bgc=this.value;bgColor();dirty()}});
 box.append(mk('label',{className:'f'},[lab('Couleur de fond derrière ce disque'),ci]),btn('Revenir à la couleur commune',function(){delete d.bgc;after()}));
 var f=mk('input',{type:'file',accept:'image/*',multiple:true});f.onchange=function(){var fs=Array.prototype.slice.call(f.files),n=0;d.bgs=d.bgs||[];fs.forEach(function(x){up(x,function(u){d.bgs.push(u);if(++n===fs.length){if(typeof d.bgo!=='number')d.bgo=S.bgo;after()}},{max:3840,jpg:true})})};
 box.append(mk('label',{className:'f'},[lab('Ajouter des images de fond'),f]));
 (d.bgs||[]).forEach(function(u,j){box.append(mk('div',{className:'lr'},[mk('img',{src:safeImg(u),alt:''}),mk('span',{textContent:'Image '+(j+1)})].concat(rowBtns(d.bgs,j))))});
 if(d.bgs&&d.bgs.length)box.append(fld(d,'bgo','Visibilité de l’image','r',{min:0,max:1,step:.05}),btn('Revenir au fond commun',function(){delete d.bgs;delete d.bgo;after()}));
 else box.append(mk('p',{className:'fh',textContent:'Ce disque utilise le fond commun (onglet Apparence).'}));
 return box}
function discBlock(B){
 var g=G('Disques proposés','Ouvre un disque pour régler : 1 nom et image · 2 effets · 3 titre · 4 fond · 5 couleurs du site · 6 animation. Il s’affiche en direct.');
 S.discs.forEach(function(d,j){
  var row=mk('div',{className:'prow'});
  row.append(mk('div',{className:'prh'},[mk('button',{className:'nm',textContent:(OPEND===j?'▾ ':'▸ ')+(d.n||'Sans nom')+(d.egg?'  ✦ secret':''),onclick:function(){OPEND=OPEND===j?null:j;if(OPEND===j)showDisc(d);refresh()}}),ib('↑','Monter',function(){mv(S.discs,j,-1)}),ib('↓','Descendre',function(){mv(S.discs,j,1)})]));
  if(OPEND===j){var b=mk('div',{className:'prb'});
   var f=mk('input',{type:'file',accept:'image/*'});f.onchange=function(){up(f.files[0],function(u){d.img=u;after()},{max:4096,jpg:true})};
   var idb=sub('1 · Nom, titre et image du disque');
   idb.append(fld(d,'n','Nom sur le bouton','t'),fld(d,'t','Titre derrière ce disque','t'),mk('label',{className:'f'},[lab('Image du disque'),mk('p',{className:'fh',textContent:'Image carrée, 2000 px ou plus de préférence.'}),f]));
   if(d.img)idb.append(btn('Retirer l’image',function(){d.img='';after()}));
   idb.append(fld(d,'tint','Couleur de base (sans image)','c'));b.append(idb);
   b.append(ownBlock(d,'cd',null,CDK,'2 · Effets et textures de ce disque (indépendants des autres)','Reflets, paillettes, relief, trou central, bord… Active « Réglages propres » pour que ce disque ait les siens.',function(x){return dcd(x)}));
   /* image derriere ce disque */
   var tb=sub('3 · Titre derrière ce disque (texte ou image)','Optionnelle. Sans image propre, c’est l’image commune qui s’affiche.');
   var tf=mk('input',{type:'file',accept:'image/*'});tf.onchange=function(){up(tf.files[0],function(u){d.timg=u;if(!d.tm&&S.tmode==='text')d.tm='image';after()},{max:2048,png:true})};
   tb.append(mk('label',{className:'f'},[lab(d.timg?'Remplacer l’image':'Ajouter une image pour ce disque'),tf]));
   if(d.timg)tb.append(btn('Retirer (revenir à l’image commune)',function(){d.timg='';after()}));
   if(typeof d.tgr==='number')tb.append(fld(d,'tgr','Grain sur le texte de ce disque','r',{min:0,max:1,step:.05}),btn('Revenir au grain commun',function(){delete d.tgr;after()}));else tb.append(btn('Régler un grain propre à ce disque',function(){d.tgr=+S.tgr||.4;after()}));
   d.tm=d.tm||'';tb.append(selF(d,'tm','Affichage pour ce disque',[['','Comme le réglage commun'],['text','Le texte seulement'],['image','L’image seulement'],['both','Le texte et l’image']]));
   d.tf=d.tf||'';tb.append(selF(d,'tf','Image devant ou derrière le texte',[['','Comme le réglage commun'],['img','L’image devant le texte'],['txt','Le texte devant l’image']]));
   tb.append(ownBlock(d,'ti',null,TIK,'Textures de l’image','Sans réglages propres, l’image suit les réglages communs.',function(x){return dti(x)}));
   b.append(tb);b.append(discBg(d));b.append(discTh(d));b.append(discFx(d));
   if(d.myt)b.append(mk('p',{className:'fh',textContent:'Disque mythique : jamais visible dans le sélecteur du site. Il sert dans le mini-jeu'+(d.k==='ahabah'?' (AHABAH) et quand le puzzle du disque brisé est réparé.':' (DISQUE NOIR) et pour les éclats du puzzle. Tant que tu gardes sa couleur d’origine et aucune image, il est assombri automatiquement.')+' Pendant que tu le règles ici, il s’affiche à la place du disque de la page.'}));else b.append(chkF(d,'egg','Disque secret (caché tant que le visiteur ne l’a pas trouvé)'));
   if(S.discs.length>1&&!d.myt)b.append(danger('Supprimer ce disque','Confirmer la suppression',function(){S.discs.splice(j,1);OPEND=null;ACT=0;after()}));
   row.append(b)}
  g.append(row)});
 g.append(btn('+ Ajouter un disque',function(){S.discs.push({k:uid(),n:'Nouveau',t:'NOUVEAU',img:'',tint:'#cfd8f5'});OPEND=S.discs.length-1;after()},'add'));
 g.append(chkF(S,'eg','Activer le disque secret'),mk('p',{className:'fh',textContent:'Pour le débloquer, le visiteur appuie 5 fois vite sur le disque, ou tape « yukyu » au clavier.'}));
 B.append(g)}
function tabCd(B){
 discBlock(B);
 var g=G('Taille, rotation et zoom','La taille du disque, la façon dont le visiteur le fait tourner, et le zoom à la molette.',false);
 g.append(fld(S,'disc','Taille du disque','r',{min:.6,max:2,step:.05}),fld(S,'dmob','Taille du disque sur téléphone (part de la largeur de l’écran, 0,40 = 80 %)','r',{min:.25,max:.5,step:.01}),fld(S,'ts','Taille du titre (texte)','r',{min:4,max:22,step:.5}),
  chkF(S.rot,'free','Le visiteur peut incliner le disque dans tous les sens (sinon : gauche/droite et légère inclinaison)'),fld(S.tx,'flp','Texte du bouton (infobulle)','t'),mk('p',{className:'fh',textContent:'Sur téléphone, un glissement vertical fait défiler la page : le bouton ⟲ permet alors de retourner le disque.'}),
  chkF(S.zm,'on','Zoom sur le disque : molette (ou pincement du pavé tactile) sur ordinateur, deux doigts sur téléphone. Double-clic, ou pincer jusqu’à la taille normale, pour revenir.'),fld(S.zm,'max','Zoom maximum','r',{min:1.2,max:4,step:.1}));B.append(g);
 g=G('Réglages communs des disques','Valeurs par défaut de tous les disques (chacun peut avoir les siennes).',false);
 sliders(g,S.cd,CDK);g.append(fld(S,'spd','Vitesse de rotation','r',{min:0,max:3,step:.1}));B.append(g);
 g=G('Titre derrière le disque : image commune','Utilisée par les disques qui n’ont pas leur propre image. Le texte du titre se règle plus haut, dans chaque disque, ou dans l’onglet Textes.',false);
 g.append(selF(S,'tmode','Afficher',[['text','Le texte seulement'],['image','L’image seulement'],['both','Le texte et l’image']]),selF(S,'tfront','Quand les deux sont affichés',[['img','L’image devant le texte'],['txt','Le texte devant l’image']]));
 var tf=mk('input',{type:'file',accept:'image/*'});tf.onchange=function(){up(tf.files[0],function(u){S.timg=u;if(S.tmode==='text')S.tmode='image';after()},{max:2048,png:true})};
 g.append(mk('label',{className:'f'},[lab('Image commune'),mk('p',{className:'fh',textContent:'PNG à fond transparent conseillé. Elle reçoit reflets et relief, mais ne tourne pas.'}),tf]));
 if(S.timg)g.append(btn('Retirer l’image',function(){S.timg='';after()}));
 sliders(g,S.ti,TIK);
 g.append(mk('p',{className:'fh',textContent:'Logo « yuu » et titre : à cocher pour les relier. Sans ces cases, rien ne change.'}),chkF(S.tlk,'col','Logo « yuu » de la même couleur que le titre derrière le disque (suit aussi le changement de disque)'),chkF(S.tlk,'on','Relier le logo « yuu » en haut au titre derrière le disque (même couleur, même grain, même lumière)'),chkF(S.tlk,'rock','Texture rocailleuse sur le titre (et sur le logo s’il est relié)'),fld(S.tlk,'amt','Force du relief rocailleux','r',{min:0,max:1,step:.05}),fld(S.tlk,'la','Direction de la lumière (degrés, 315 = en haut à gauche)','r',{min:0,max:355,step:5}));
 g.append(fld(S,'tgr','Grain sur le texte du titre (0 = aucun)','r',{min:0,max:1,step:.05}),fld(S,'tgs','Finesse du grain (petit = fin, grand = gros)','r',{min:.5,max:4,step:.1}));
 g.append(fld(S,'tsz','Taille de l’image','r',{min:.2,max:1,step:.02}),fld(S,'ty','Position verticale de l’image','r',{min:-.8,max:.8,step:.02}));B.append(g);

}
function tabBg(B){
 var g=G('Image de fond de la page (commune)','Plusieurs images = diaporama en fondu. Chaque disque peut avoir son propre fond (onglet Disques).');
 var f=mk('input',{type:'file',accept:'image/*',multiple:true});
 f.onchange=function(){var fs=Array.prototype.slice.call(f.files),n=0;fs.forEach(function(x){up(x,function(u){S.bgs.push(u);if(++n===fs.length)after()},{max:3840,jpg:true})})};
 g.append(mk('label',{className:'f'},[lab('Ajouter des images'),f]));
 S.bgs.forEach(function(u,j){g.append(mk('div',{className:'lr'},[mk('img',{src:safeImg(u),alt:''}),mk('span',{textContent:'Image '+(j+1)})].concat(rowBtns(S.bgs,j))))});
 g.append(fld(S,'bgo','Visibilité de l’image','r',{min:0,max:1,step:.05,hint:'Baisse pour garder les textes lisibles.'}));B.append(g);
 g=G('Couleurs du site','Couleurs communes à tout le site. Chaque disque peut avoir les siennes (onglet Disques, bloc « Couleurs du site pour ce disque »).');
 var cs=getComputedStyle(document.documentElement);
 function cur(k){var v=cs.getPropertyValue('--'+k).trim();return S.th[k]||(/^#[0-9a-f]{6}$/i.test(v)?v:'#000000')}
 [['bg','Fond de la page'],['ink','Texte principal'],['muted','Texte secondaire'],['card','Cartes et blocs'],['line','Traits et bordures'],['tcol','Titre derrière le disque'],['onaccent','Texte des boutons']].forEach(function(c){
  g.append(colFld(c[1],function(){return S.th[c[0]]||(c[0]==='tcol'?cur('ink'):c[0]==='onaccent'?cur('onaccent'):cur(c[0]))},function(v){S.th[c[0]]=v}))});
 g.append(colFld('Boutons et accents',function(){return S.accent},function(v){S.accent=v}));
 g.append(btn('Réinitialiser les couleurs',function(){S.th={};after()}));
 B.append(g);
 g=G('Boutons','Un léger contour décoratif autour des boutons (Voir, Commander…).');
 g.append(chkF(S.bl,'on','Ajouter un contour autour des boutons'),fld(S.bl,'w','Épaisseur du contour','r',{min:1,max:4,step:.5}),colFld('Couleur du contour',function(){return S.bl.c||S.accent},function(v){S.bl.c=v}));
 B.append(g);
 g=G('Espacement');
 g.append(fld(S,'gap','Espace entre les sections','r',{min:1,max:8,step:.25}));B.append(g);
}
function prodBody(p,i){
 var b=mk('div',{className:'prb'});
 b.append(chkF(p,'esc','🧣 Produit écharpe : caché tant que le visiteur n’a pas posé l’écharpe sur « yuu » (secret n°6)'),chkF(p,'hid','🔒 Produit caché : invisible sur le site, accessible seulement par son lien (gravé sur le disque secret)'),chkF(p,'big','Mettre ce produit en avant (carte plus grande sur l’accueil)'),fld(p,'n','Nom du produit','t'),fld(p,'p','Prix','t'),fld(p,'d','Description courte (sur la carte)','a',{rows:2}),fld(p,'l','Description longue (page du produit)','a',{rows:4}),lab('Détails (liste à puces)'),strList(p.det,'+ Ajouter un détail'));
 var f=mk('input',{type:'file',accept:'image/*',multiple:true});f.onchange=function(){var fs=Array.prototype.slice.call(f.files),n=0,res=[];p.imgs=p.imgs||[];fs.forEach(function(x,k){up(x,function(u){res[k]=u;if(++n===fs.length){res.forEach(function(r){if(r)p.imgs.push(r)});after()}},{max:1600})})};
 b.append(mk('label',{className:'f'},[lab('Photos du produit (tu peux en ajouter plusieurs)'),mk('p',{className:'fh',textContent:'La première est la photo principale (cartes et début de la page). Les autres apparaissent en miniatures sur la page du produit. Astuce : double-clique sur une photo du site pour la remplacer.'}),f]));
 (p.imgs||[]).forEach(function(u,j){b.append(mk('div',{className:'lr'},[mk('img',{src:safeImg(u),alt:''}),mk('span',{textContent:j?'Photo '+(j+1):'Photo principale'})].concat(rowBtns(p.imgs,j))))});
 b.append(fld(p,'h','Couleur du dégradé (sans photo)','r',{min:0,max:360,step:1}),fld(p,'pay','Lien de paiement Stripe (Payment Link)','t',{hint:'Colle le lien créé dans Stripe (https://buy.stripe.com/…). Le bouton « Commander » ouvrira ce paiement.'}),fld(p,'u','Autre lien de commande (Big Cartel…)','t',{hint:'Utilisé seulement si le lien Stripe est vide. Les deux vides = ta boutique.'}));
 p.x=p.x||{t:'',l:[]};p.x.l=p.x.l||[];
 b.append(lab('Suggestions sur la page de ce produit'),fld(p.x,'t','Phrase d’introduction','t',{hint:'Exemple : « Aussi disponible en bundle. »'}));
 p.x.l.forEach(function(y,j){
  var sel=mk('select'),ok=false;
  S.products.forEach(function(q){if(q.s===p.s)return;if(q.s===y.s)ok=true;sel.append(mk('option',{value:q.s,textContent:q.n||'Sans nom'}))});
  if(!ok){sel.prepend(mk('option',{value:y.s,textContent:'(produit supprimé)'}));}
  sel.value=y.s;sel.onchange=function(){y.s=sel.value;dirty();render()};
  var t=mk('input',{type:'text',value:y.b,placeholder:'Texte du bouton'});t.oninput=function(){y.b=t.value;dirty();render()};
  b.append(mk('div',{className:'lr'},[sel].concat(rowBtns(p.x.l,j))),mk('div',{className:'lr'},[t]));
 });
 b.append(btn('+ Ajouter une suggestion',function(){var o=S.products.filter(function(q){return q.s!==p.s})[0];if(!o){msg('Ajoute d’abord un autre produit.');return}p.x.l.push({s:o.s,b:'Voir '+(o.n||'')});after()},'add'));
 var a=mk('div');
 a.append(btn('Ouvrir sa page',function(){location.hash=p.s}),btn('Dupliquer',function(){
   var c=JSON.parse(JSON.stringify(p));c.s=uid();c.n=(c.n||'')+' (copie)';S.products.splice(i+1,0,c);OPEN=c.s;after()}),
  danger('Supprimer ce produit','Confirmer la suppression',function(){S.products.splice(i,1);OPEN=null;if(location.hash.slice(1)===p.s)location.hash='boutique';after()}));
 b.append(a);return b;
}
function cartPanel(B){var g=G('🛒 Panier','Les visiteurs ajoutent plusieurs produits puis paient en une seule fois (Stripe Checkout). Demande un petit service en ligne : voir le LISEZ-MOI (variable STRIPE_SECRET_KEY sur Netlify). Il ne fonctionne pas dans l’aperçu Claude, seulement sur ton vrai site.');
 g.append(chkF(S.cart,'on','Activer le panier (bouton « Ajouter au panier » + icône en haut)'),chkF(S.cart,'direct','Garder aussi le bouton « Commander » (achat direct d’un seul produit)'),
  fld(S.cart,'ship','Frais de port (€, 0 = aucun frais à ajouter)','t'),fld(S.cart,'rate','Tarif d’expédition Stripe (identifiant « shr_… », facultatif : s’il est rempli, c’est ce tarif Stripe qui est utilisé au paiement)','t'),fld(S.cart,'free','Livraison offerte à partir de (€, 0 = jamais)','t'),fld(S.cart,'code','Code livraison offerte (donné par le chat noir, secret n°7 ; vide = pas de code)','t'),fld(S.cart,'countries','Pays livrés (codes séparés par des virgules : FR,BE,DE…)','t'));
 var s=sub('Textes du panier');['cartAdd','cartCodePh','cartCodeBtn','cartCodeOk','cartCodeBad','cartCodeRm','cartH','cartEmpty','cartTot','cartShipNote','cartPay','cartCont','cartFreeMsg','cartFreeOk','cartAdded','cartErr'].forEach(function(k){s.append(fld(S.tx,k,({cartAdd:'Bouton « Ajouter au panier »',cartCodePh:'Code : texte du champ',cartCodeBtn:'Code : bouton',cartCodeOk:'Code : message quand il est appliqué',cartCodeBad:'Code : message s’il est faux',cartCodeRm:'Code : lien pour le retirer',cartH:'Titre du panier',cartEmpty:'Panier vide',cartTot:'Libellé du total',cartShipNote:'Note sous le total',cartPay:'Bouton de paiement',cartCont:'Bouton « continuer »',cartFreeMsg:'Message avant la livraison offerte ({x} = montant restant)',cartFreeOk:'Message livraison offerte',cartAdded:'Message après ajout',cartErr:'Message si le paiement échoue'})[k],'t'))});g.append(s);B.append(g)}
function acctPanel(B){
 var g=G('👤 Compte client (Stripe)','Stripe ne propose pas de compte avec mot de passe : ton client reçoit un code par e-mail pour se connecter à un espace où il retrouve ses commandes et ses factures. Pour l’activer : dans Stripe, Paramètres > Billing > Portail client, active le portail et copie le « lien de connexion » (il ressemble à https://billing.stripe.com/p/login/…). Colle-le ci-dessous. Une icône personne apparaît alors en haut du site.',false);
 g.append(chkF(S.acct,'on','Afficher le bouton « Mon compte » en haut du site'),fld(S.acct,'url','Lien de connexion du portail client Stripe (https://billing.stripe.com/p/login/…)','t'),fld(S.acct,'lbl','Texte au survol du bouton','t'),
  chkF(S.acct,'save','Créer un client Stripe (avec facture) à chaque commande du panier : nécessaire pour qu’il retrouve ses commandes dans « Mon compte »'));B.append(g)}
function tabProd(B){
 var g=G('Boutique');g.append(fld(S,'shop','Adresse de ta boutique Big Cartel','t',{hint:'Utilisée par les boutons « Commander » quand un produit n’a pas son propre lien.'}));B.append(g);
 g=G('★ Produit mis en avant','Un seul produit peut être mis à la une : il s’affiche en premier, en grand sur toute la largeur, avec une étiquette. Tu peux aussi toucher l’étoile ☆ d’un produit dans la liste plus bas.',true);
 var fs=mk('select');fs.append(mk('option',{value:'',textContent:'Aucun'}));S.products.forEach(function(q){fs.append(mk('option',{value:q.s,textContent:q.n||'Sans nom'}))});var cb=S.products.filter(function(q){return q.big})[0];fs.value=cb?cb.s:'';
 fs.onchange=function(){S.products.forEach(function(q){q.big=q.s===fs.value});after()};
 g.append(mk('label',{className:'f'},[lab('Produit mis en avant'),mk('p',{className:'fh',textContent:'Il s’affiche en grand, sur toute la largeur, au-dessus des autres. « Aucun » = tous à la même taille.'}),fs]));B.append(g);
 g=G('Affichage des produits','Garde les cartes ou passe à un rendu sans contour avec des CD qui flottent en 3D.',false);
 g.append(selF(S.pc,'style','Style',[['card','Cartes (avec contour et fond)'],['float','Sans contour : CD flottants en 3D']]),selF(S.pc,'shape','Forme des visuels (style flottant)',[['round','Ronds, comme un CD'],['square','Carrés']]),chkF(S.pc,'hub','Centre de CD au milieu (style flottant)'),chkF(S.pc,'tilt','Inclinaison 3D qui suit la souris (style flottant)'));
 B.append(g);
 g=G('Produits','Glisse ⠿ (ordinateur) ou utilise ↑ ↓ pour changer l’ordre d’affichage.');
 S.products.forEach(function(p,i){
  var row=mk('div',{className:'prow'}),grip=mk('span',{className:'grip',textContent:'⠿',title:'Glisser pour déplacer'});
  var h=mk('div',{className:'prh'},[grip,mk('button',{className:'nm',textContent:(OPEN===p.s?'▾ ':'▸ ')+(p.hid?'🔒 ':'')+(p.esc?'🧣 ':'')+(p.n||'Sans nom'),onclick:function(){OPEN=OPEN===p.s?null:p.s;refresh()}}),
   ib(p.big?'★':'☆',p.big?'Retirer de la une':'Mettre à la une',function(){var v=!p.big;S.products.forEach(function(q){q.big=false});p.big=v;after()}),ib('↑','Monter',function(){mv(S.products,i,-1)}),ib('↓','Descendre',function(){mv(S.products,i,1)})]);
  row.dataset.slug=p.s;grip.onmousedown=function(){row.draggable=true};
  row.ondragend=function(){row.draggable=false;DRAG=null};
  row.ondragstart=function(e){DRAG=i;try{e.dataTransfer.setData('text/plain',String(i));e.dataTransfer.effectAllowed='move'}catch(x){}};
  row.ondragover=function(e){if(DRAG==null)return;e.preventDefault();row.classList.add('drop')};
  row.ondragleave=function(){row.classList.remove('drop')};
  row.ondrop=function(e){e.preventDefault();row.classList.remove('drop');if(DRAG!=null&&DRAG!==i){var x=S.products.splice(DRAG,1)[0];S.products.splice(i,0,x);DRAG=null;after()}};
  row.append(h);if(OPEN===p.s)row.append(prodBody(p,i));g.append(row);
 });
 g.append(btn('+ Ajouter un produit',function(){var p={s:uid(),n:'Nouveau produit',d:'',l:'',p:'0',h:200,u:'',img:'',det:[],x:{t:'',l:[]}};S.products.push(p);OPEN=p.s;after()},'add'));
 B.append(g);
 cartPanel(B);acctPanel(B);
}
var OPENP=null;
var HOSTS=[['open.spotify.com','Spotify'],['spotify.link','Spotify'],['music.apple.com','Apple Music'],['itunes.apple.com','Apple Music'],['music.youtube.com','YouTube Music'],['youtube.com','YouTube'],['youtu.be','YouTube'],['deezer.com','Deezer'],['deezer.page.link','Deezer'],['tidal.com','Tidal'],['music.amazon','Amazon Music',1],['soundcloud.com','SoundCloud'],['bandcamp.com','Bandcamp'],['napster.com','Napster'],['audiomack.com','Audiomack']];
var PLAT={spotify:'Spotify',appleMusic:'Apple Music',youtubeMusic:'YouTube Music',youtube:'YouTube',deezer:'Deezer',tidal:'Tidal',amazonMusic:'Amazon Music',soundcloud:'SoundCloud',bandcamp:'Bandcamp',napster:'Napster',audiomack:'Audiomack'};
function netOf(u){try{var h=new URL(u).hostname.replace(/^www\./,'').toLowerCase();for(var i=0;i<HOSTS.length;i++){var x=HOSTS[i];if(h===x[0]||h.endsWith('.'+x[0])||(x[2]&&h.indexOf(x[0])>=0))return x[1]}}catch(e){}return ''}
function cleanU(u){try{var o=new URL(u);['si','utm_source','utm_medium','utm_campaign','utm_content','fbclid','igshid','feature','context'].forEach(function(k){o.searchParams.delete(k)});return o.toString()}catch(e){return u}}
function fj(u){return new Promise(function(res,rej){var tm=setTimeout(function(){rej(new Error('délai'))},5000);
 try{fetch(u,{headers:{Accept:'application/json'}}).then(function(r){if(!r.ok)throw new Error('http '+r.status);return r.json()}).then(function(j){clearTimeout(tm);res(j)},function(e){clearTimeout(tm);rej(e)})}catch(e){clearTimeout(tm);rej(e)}})}
function setLink(p,name,u){p.l=p.l||[];var f=p.l.filter(function(x){return (x.t||'').toLowerCase()===name.toLowerCase()})[0];if(f)f.u=u;else p.l.push({t:name,u:u})}
function importLink(p,url){
 url=(url||'').trim();if(!/^https?:\/\//i.test(url)){msg('Colle une adresse complète (https://…).');return}
 var cl=cleanU(url),nm=netOf(cl)||'Lien';setLink(p,nm,cl);after();
 msg('Lien « '+nm+' » ajouté ✓. Je tente aussi de récupérer la pochette…');
 fj('https://api.song.link/v1-alpha.1/links?userCountry=FR&url='+encodeURIComponent(url)).then(function(j){
  var en=(j.entitiesByUniqueId&&j.entitiesByUniqueId[j.entityUniqueId])||{},lp=j.linksByPlatform||{};
  Object.keys(PLAT).forEach(function(k){if(lp[k]&&lp[k].url)setLink(p,PLAT[k],lp[k].url)});
  if(en.title&&(!p.n||p.n==='Nouveau projet'))p.n=en.title;
  if(en.artistName&&!p.d)p.d=en.artistName+(en.type==='album'?' · album':en.type==='song'?' · titre':'');
  function ok(){after();msg('Importé : '+(p.n||'projet')+' (liens'+(p.img?', pochette':'')+'). Vérifie puis publie.')}
  if(en.thumbnailUrl&&!p.img&&asg){fetch(en.thumbnailUrl).then(function(r){return r.blob()}).then(function(b){return asg.upload(b)}).then(function(r){p.img=r.url}).then(ok,ok)}else ok()
 },function(){msg('Lien « '+nm+' » ajouté ✓. La pochette et le titre ne peuvent pas être récupérés automatiquement ici (le navigateur bloque l’accès aux autres sites) : choisis ta pochette avec « Pochette » juste dessous.')})}
function ab2b64(ab){var u=new Uint8Array(ab),s='',n=0x8000;for(var i=0;i<u.length;i+=n)s+=String.fromCharCode.apply(null,u.subarray(i,i+n));return btoa(s)}
function wavOf(b){var n=b.length,sr=b.sampleRate,ch=b.getChannelData(0),o=new DataView(new ArrayBuffer(44+n*2));function w(p,s){for(var i=0;i<s.length;i++)o.setUint8(p+i,s.charCodeAt(i))}
 w(0,'RIFF');o.setUint32(4,36+n*2,true);w(8,'WAVE');w(12,'fmt ');o.setUint32(16,16,true);o.setUint16(20,1,true);o.setUint16(22,1,true);o.setUint32(24,sr,true);o.setUint32(28,sr*2,true);o.setUint16(32,2,true);o.setUint16(34,16,true);w(36,'data');o.setUint32(40,n*2,true);
 for(var i=0;i<n;i++){var v=Math.max(-1,Math.min(1,ch[i]));o.setInt16(44+i*2,v<0?v*32768:v*32767,true)}return o.buffer}
var PFO={st:0,d:230};
function upAudio(file,cb){if(!file)return;if(file.size>200*1048576){msg('Fichier trop lourd (200 Mo max).');return}
 var CAP=3*1048576;msg('Lecture du fichier audio…');
 var fr=new FileReader();fr.onerror=function(){msg('Lecture du fichier impossible.')};
 fr.onload=function(){var ab=fr.result,ext=((file.name||'').match(/\.(\w+)$/)||[])[1]||'',mt=/^audio\//.test(file.type||'')?file.type:({mp3:'audio/mpeg',wav:'audio/wav',ogg:'audio/ogg',m4a:'audio/mp4',aac:'audio/aac'})[ext.toLowerCase()]||'audio/mpeg';
  function fin(buf,mime,note){var u='data:'+mime+';base64,'+ab2b64(buf);
   if(!window.SND){cb(u);return}
   SND.probe(u).then(function(b){if(!b){msg('✗ Ce fichier audio n’a pas pu être lu par ton navigateur. Essaie un .mp3 ou un .wav standard.');return}var done=function(x){cb(x);msg('✓ Audio enregistré ('+Math.round(b.duration)+' s'+(note||'')+'). Pense à publier.')};if(isSA()&&asg){msg('Envoi du fichier audio…');asg.upload(new Blob([buf],{type:mime})).then(function(r){done(r.url)},function(e){msg('✗ Envoi impossible : '+(e&&e.message||'erreur'))})}else done(u)})}
  if(ab.byteLength<=CAP){fin(ab,mt,'');return}
  msg('Fichier long : préparation de la boucle…');
  SND.decode(ab.slice(0)).then(function(b){if(b.duration<=231&&ab.byteLength<=9*1048576){fin(ab,mt,', fichier gardé en entier');return}var sr=22050,st=Math.max(0,Math.min(Math.max(0,b.duration-6),+PFO.st||0)),X=Math.min(2,b.duration/8),D=Math.max(4,Math.min(Math.max(10,Math.min(230,+PFO.d||230)),b.duration-st-X));
   sr=Math.max(11025,Math.min(22050,Math.floor(6.5e6/(2*D))));var oc=new OfflineAudioContext(1,Math.max(1,Math.ceil((D+X)*sr)),sr),s=oc.createBufferSource();s.buffer=b;s.connect(oc.destination);s.start(0,st);
   oc.startRendering().then(function(r){var seg=r.getChannelData(0),N=Math.floor(D*sr),x=Math.floor(X*sr),out=new Float32Array(N);
    for(var i=0;i<N;i++){var v=seg[i];if(i<x){var w=i/x;v=seg[i]*Math.sin(w*Math.PI/2)+(seg[N+i]||0)*Math.cos(w*Math.PI/2)}out[i]=v}
    fin(wavOf({length:N,sampleRate:sr,getChannelData:function(){return out}}),'audio/wav',', boucle de '+Math.round(D)+' s à partir de '+Math.round(st)+' s')},function(){msg('✗ Conversion impossible.')})},function(){msg('✗ Ce fichier audio n’a pas pu être lu par ton navigateur.')})};
 fr.readAsArrayBuffer(file)}
function posterOf(file){return new Promise(function(res){var v=document.createElement('video'),u=URL.createObjectURL(file),done=false;
 function fin(b){if(done)return;done=true;URL.revokeObjectURL(u);res(b)}
 v.muted=true;v.playsInline=true;v.preload='auto';v.src=u;
 v.onloadeddata=function(){try{v.currentTime=Math.min(1,(v.duration||2)/4)}catch(e){fin(null)}};
 v.onseeked=function(){try{var w=v.videoWidth,h=v.videoHeight;if(!w||!h)return fin(null);var s=Math.min(1,1280/w),cv=document.createElement('canvas');cv.width=Math.round(w*s);cv.height=Math.round(h*s);cv.getContext('2d').drawImage(v,0,0,cv.width,cv.height);cv.toBlob(function(b){fin(b)},'image/jpeg',.85)}catch(e){fin(null)}};
 v.onerror=function(){fin(null)};setTimeout(function(){fin(null)},9000)})}
var OPENC=null;
function tabPj(B){
 var g=G('Projets (section « Écouter »)');
 S.pj.list.forEach(function(p,j){
  var row=mk('div',{className:'prow'});
  row.append(mk('div',{className:'prh'},[mk('button',{className:'nm',textContent:(OPENP===p.s?'▾ ':'▸ ')+(p.n||'Sans nom'),onclick:function(){OPENP=OPENP===p.s?null:p.s;refresh()}}),ib('↑','Monter',function(){mv(S.pj.list,j,-1)}),ib('↓','Descendre',function(){mv(S.pj.list,j,1)})]));
  if(OPENP===p.s){var b=mk('div',{className:'prb'});
   var im=mk('input',{type:'text',placeholder:'Colle un lien (Spotify, Apple Music, Deezer, YouTube…)'});
   var ib2=sub('Ajouter un lien d’écoute','La plateforme est reconnue toute seule et le lien est rangé dans la liste plus bas. (La pochette ne se récupère pas toute seule ici : choisis-la avec « Pochette ».)');b.append(ib2);
   ib2.append(mk('div',{className:'lr'},[im]),btn('Ajouter',function(){importLink(p,im.value)}));
   var f=mk('input',{type:'file',accept:'image/*'});f.onchange=function(){up(f.files[0],function(u){p.img=u;after()},{max:1200,jpg:true})};
   b.append(fld(p,'n','Nom du projet','t'),fld(p,'d','Description','a',{rows:2}),mk('label',{className:'f'},[lab('Pochette'),f]));
   if(p.img)b.append(btn('Retirer la pochette',function(){p.img='';after()}));
   b.append(fld(p,'h','Couleur (sans pochette)','r',{min:0,max:360,step:1}));
   var pl=sub('Plateformes d’écoute','Le visiteur choisit où écouter. Sans lecteur sur le site, le premier lien devient le gros bouton « Lancer ».');b.append(pl);
   p.l=p.l||[];
   p.l.forEach(function(l,k){var a=mk('input',{type:'text',value:l.t,placeholder:'Plateforme'}),u=mk('input',{type:'text',value:l.u,placeholder:'Adresse (https://…)'});
    a.oninput=function(){l.t=a.value;dirty();render()};u.oninput=function(){l.u=u.value;dirty();render()};
    pl.append(mk('div',{className:'lr'},[a].concat(rowBtns(p.l,k))),mk('div',{className:'lr'},[u]))});
   pl.append(btn('+ Ajouter une plateforme',function(){p.l.push({t:'Lien',u:''});after()},'add'));
   var pa=sub('Écouter directement sur le site','Ajoute des fichiers audio (mp3, m4a, wav…) : le visiteur les écoute sur la page avec le bouton « Écouter ici ». Les lecteurs Spotify ou YouTube ne peuvent pas être intégrés dans cette page.');b.append(pa);
   p.a=p.a||[];
   p.a.forEach(function(x,k){var a=mk('input',{type:'text',value:x.t,placeholder:'Titre de la piste'}),fi=mk('input',{type:'file',accept:'audio/*,.mp3,.m4a,.wav,.ogg'}),emb=/^data:/i.test(x.u||'');
    a.oninput=function(){x.t=a.value;dirty();render()};
    fi.onchange=function(){upAudio(fi.files[0],function(url){x.u=url;if(!x.t)x.t=fi.files[0].name.replace(/\.[^.]+$/,'');after()})};
    var rowU;if(emb)rowU=mk('p',{className:'fh',textContent:'✓ Fichier intégré à la page. Choisis un autre fichier pour le remplacer.'});
    else{var u=mk('input',{type:'text',value:x.u,placeholder:'Adresse du fichier (ou choisis-le ci-dessous)'});u.oninput=function(){x.u=u.value;dirty();render()};rowU=mk('div',{className:'lr'},[u])}
    pa.append(mk('div',{className:'lr'},[a].concat(rowBtns(p.a,k))),rowU,fi)});
   pa.append(btn('+ Ajouter une piste audio',function(){p.a.push({t:'',u:''});after()},'add'));
   b.append(mk('div',{},[danger('Supprimer ce projet','Confirmer la suppression',function(){S.pj.list.splice(j,1);OPENP=null;after()})]));
   row.append(b)}
  g.append(row)});
 g.append(btn('+ Ajouter un projet',function(){var p={s:uid(),n:'Nouveau projet',d:'',img:'',h:200,l:[],a:[]};S.pj.list.push(p);OPENP=p.s;after()},'add'));
 B.append(g);
 g=G('Textes de la section « Écouter »',null,false);
 g.append(fld(S.tx,'pjH','Titre de la section','t'),fld(S.tx,'pjLead','Texte sous le titre','a',{rows:2}),fld(S.tx,'pjHere','Bouton « écouter sur le site »','t'),fld(S.tx,'pjHide','Bouton pour fermer le lecteur','t'),fld(S.tx,'pjOn','Mot avant les plateformes','t'),fld(S.tx,'pjGo','Gros bouton (sans lecteur)','t'),fld(S.tx,'pjSoon','Texte quand il n’y a pas encore de lien','t'));B.append(g);
 g=G('Clips vidéo','Section avant « Nous contacter » : une miniature par clip. Un clic ouvre le lecteur sur le site (fichier vidéo importé) ou YouTube (lien). Si le site se casse, les clips buguent.');
 var CL=S.clip.list=S.clip.list||[];
 CL.forEach(function(it,j){
  var row=mk('div',{className:'prow'});it.s=it.s||uid();
  row.append(mk('div',{className:'prh'},[mk('button',{className:'nm',textContent:(OPENC===it.s?'▾ ':'▸ ')+(it.n||('Clip '+(j+1))),onclick:function(){OPENC=OPENC===it.s?null:it.s;refresh()}}),ib('↑','Monter',function(){mv(CL,j,-1)}),ib('↓','Descendre',function(){mv(CL,j,1)})]));
  if(OPENC===it.s){var b=mk('div',{className:'prb'});
   var vf=mk('input',{type:'file',accept:'video/*'});
   vf.onchange=function(){var fl=vf.files[0];if(!fl)return;if(!asg){msg('Import indisponible ici.');return}
    msg('Import du clip (ça peut prendre un moment)…');
    asg.upload(fl).then(function(r){it.u=r.url;msg('Clip importé. Création de la miniature…');after();
     if(it.p)return;return posterOf(fl).then(function(bl){if(!bl){msg('Clip importé ✓ (miniature non créée : ajoute-en une ci-dessous).');return}return asg.upload(bl).then(function(pr){it.p=pr.url;after();msg('Clip et miniature importés ✓. Pense à publier.')})})
    },function(e){msg('Le stockage refuse ce fichier ('+(e&&(e.message||e.code)||'erreur')+'). Limite : 20 Mo. Compresse le clip (mp4 H.264, 720p) et réessaie.')})};
   var pf=mk('input',{type:'file',accept:'image/*'});pf.onchange=function(){up(pf.files[0],function(u){it.p=u;after()},{max:1600,jpg:true})};
   b.append(fld(it,'n','Titre sous la miniature (facultatif)','t'),
    mk('label',{className:'f'},[lab(it.u?'Remplacer le fichier vidéo':'Importer le fichier vidéo (mp4, 20 Mo max)'),mk('p',{className:'fh',textContent:'Il se lit directement sur le site, dans une grande fenêtre.'}),vf]),
    fld(it,'u','…ou adresse directe d’un fichier vidéo','t'),
    fld(it,'x','Lien YouTube (ou autre plateforme)','t',{hint:'Sans fichier vidéo, un clic sur la miniature ouvre ce lien. Avec un fichier, il s’ajoute en bouton sous le lecteur.'}),
    mk('label',{className:'f'},[lab('Miniature'),mk('p',{className:'fh',textContent:'Pour un lien YouTube, ajoute ici l’image de ton choix (elle ne peut pas être récupérée toute seule dans cette page).'}),pf]));
   if(it.p)b.append(btn('Retirer la miniature',function(){it.p='';after()}));
   if(it.u)b.append(btn('Retirer le fichier vidéo',function(){it.u='';after()}));
   b.append(mk('div',{},[danger('Supprimer ce clip','Confirmer la suppression',function(){CL.splice(j,1);OPENC=null;after()})]));
   row.append(b)}
  g.append(row)});
 g.append(btn('+ Ajouter un clip',function(){var it={s:uid(),n:'',u:'',p:'',x:'',e:false};CL.push(it);OPENC=it.s;after()},'add'));
 g.append(fld(S.clip,'w','Largeur maximale de la zone clips','r',{min:16,max:70,step:1}),chkF(S.clip,'hide','Cacher toute la section tant qu’il n’y a pas de clip'),
  fld(S.tx,'clH','Titre de la section','t'),fld(S.tx,'clLead','Texte sous le titre','a',{rows:2}),fld(S.tx,'clSoon','Texte quand il n’y a pas encore de clip','t'),fld(S.tx,'clExt','Texte du bouton « ouvrir sur YouTube »','t'));
 B.append(g)}
function tabCt(B){
 var g=G('Où arrivent les messages','Contact, newsletter et page d’ouverture utilisent cette adresse.');
 g.append(fld(S.ct,'to','Adresse e-mail de réception','t'),selF(S.ct,'mode','Mode d’envoi',[['direct','Tenter l’envoi automatique (FormSubmit)'],['mailto','Proposer directement « ouvrir ma messagerie / copier »']],'IMPORTANT : un site publié ici ne peut pas contacter d’autres serveurs, donc l’envoi automatique échoue dans ce cadre. Le visiteur voit alors son message prêt avec ton adresse, un bouton pour ouvrir sa messagerie et un bouton copier. L’envoi automatique ne marche que si le fichier du site est hébergé sur ton propre hébergement (Big Cartel, etc.), et FormSubmit demande de confirmer l’adresse à la première utilisation.'));
 g.append(btn('Tester l’envoi',function(){msg('Test en cours…');sendMail('Test depuis le site',{Message:'Test d’envoi'}).then(function(){msg('✓ Envoi automatique OK. Regarde ta boîte mail (et FormSubmit te demandera peut-être de confirmer).')},function(e){msg('✗ Envoi automatique impossible ici ('+(e&&e.message||'erreur')+'). Les visiteurs verront ton adresse avec « ouvrir ma messagerie » et « copier ».')})}));B.append(g);
 g=G('Nous contacter');g.append(fld(S.tx,'ctH','Titre','t'),fld(S.tx,'ctLead','Texte sous le titre','a',{rows:2}),fld(S.tx,'ctName','Champ nom','t'),fld(S.tx,'ctMail','Champ e-mail','t'),fld(S.tx,'ctMsg','Champ message','t'),fld(S.tx,'ctBtn','Bouton','t'),fld(S.tx,'ctOk','Message après envoi réussi','t'),fld(S.tx,'ctFail','Message si l’envoi automatique est impossible','a',{rows:3}),fld(S.tx,'ctReady','Message en mode « messagerie »','a',{rows:2}),fld(S.tx,'ctOpen','Bouton ouvrir la messagerie','t'),fld(S.tx,'ctCopy','Bouton copier le message','t'));B.append(g);
 g=G('Newsletter');g.append(fld(S.tx,'nlH','Titre','t'),fld(S.tx,'nlLead','Texte sous le titre','a',{rows:2}),fld(S.tx,'nlPh','Champ e-mail','t'),fld(S.tx,'nlBtn','Bouton','t'),fld(S.tx,'nlOk','Message après inscription','t'));B.append(g)}
var FXN=[['iris','Iris – arc-en-ciel qui flotte'],['soleil','Soleil – lumière dorée, rayons et reflets sur les boutons'],['aurore','Aurore – rubans verts et violets, étoiles'],['pluie','Pluie – gouttes sur une vitre'],['neon','Néon – lueurs rose et cyan, lignes de balayage'],['braise','Braise – étincelles qui montent'],['eau','Eau – lumière du soleil au fond de l’eau (caustiques)'],['pellicule','Pellicule – fuites de lumière et poussière'],['rayons','Rayons – soleil rasant (façon Complementary)'],['brume','Brume – brouillard doux'],['cubique','Cubique – nuages en blocs et pixels (façon Minecraft)'],['vhs','VHS – lignes de balayage'],['casse','Signal perdu – glitch sombre']];
var EXC="// Exemple : bandes de lumière douces qui dérivent\nfloat b=fbm(p*1.4+vec2(t*.1,0.));\nvec3 col=.5+.5*cos(6.2832*(b*1.5+vec3(0.,.33,.67)));\nfloat a=smoothstep(.35,.8,b)*sh*.35;\nc=over(vec4(col*a,a),c);";
function fxOpts(){return FXN.concat((S.fx.custom||[]).map(function(c){return['c:'+c.id,(c.n||'Sans nom')+' (à moi)']}))}
function fxSnap(p){['mode','spd','amt','sheen','grain','vig'].forEach(function(k){p[k]=S.fx[k]})}
function tabFx(B){
 var g=G('Shader sur tout le site','Un voile animé posé sur toute la page. Choisis une ambiance, règle l’intensité et la vitesse.');
 g.append(chkF(S.fx,'on','Activer le shader'),selF(S.fx,'mode','Shader',fxOpts()),fld(S.fx,'spd','Vitesse du mouvement','r',{min:0,max:3,step:.05,hint:'Pour « Iris » : vitesse à laquelle l’arc-en-ciel dérive tout seul. 0 = figé.'}),fld(S.fx,'amt','Intensité globale','r',{min:0,max:1,step:.05}),fld(S.fx,'sheen','Force de l’effet principal (irisation, rayons, brume…)','r',{min:0,max:1,step:.05}),fld(S.fx,'grain','Grain','r',{min:0,max:1,step:.05}),fld(S.fx,'vig','Vignette (bords sombres)','r',{min:0,max:1,step:.05}));
 var ps=sub('Mes préréglages','Enregistre les réglages actuels (shader, vitesse, intensité, grain…) sous un nom pour les retrouver en un clic.');
 S.fx.presets.forEach(function(p,j){var n=mk('input',{type:'text',value:p.n||''});n.oninput=function(){p.n=n.value;dirty()};
  ps.append(mk('div',{className:'lr'},[n,ib('✔','Appliquer ce préréglage',function(){['mode','spd','amt','sheen','grain','vig'].forEach(function(k){if(p[k]!=null)S.fx[k]=p[k]});after()}),ib('⟳','Mettre à jour avec les réglages actuels',function(){fxSnap(p);dirty();msg('Préréglage mis à jour.')}),ib('✕','Supprimer',function(){S.fx.presets.splice(j,1);after()})]))});
 var nn=mk('input',{type:'text',placeholder:'Nom du nouveau préréglage'});
 ps.append(mk('div',{className:'lr'},[nn]),btn('+ Enregistrer les réglages actuels',function(){var p={id:uid(),n:nn.value.trim()||('Préréglage '+(S.fx.presets.length+1))};fxSnap(p);S.fx.presets.push(p);after();msg('Préréglage enregistré. Pense à publier.')},'add'));
 g.append(ps);
 var cs=sub('Mes shaders (code GLSL)','Pour créer un effet à toi. Variables disponibles : uv (0 à 1), p (uv au bon ratio), t (temps), mp (souris), res, gr (grain), sh (force), vg (vignette), et fbm(), vn(), h(). Tu dessines avec : c=over(vec4(couleur*a,a),c);');
 S.fx.custom.forEach(function(x,j){var n=mk('input',{type:'text',value:x.n||'',placeholder:'Nom du shader'});n.oninput=function(){x.n=n.value;dirty()};n.onchange=refresh;
  var ta=mk('textarea',{rows:8,value:x.code||'',spellcheck:false});ta.style.cssText='font-family:ui-monospace,Menlo,Consolas,monospace;font-size:.78rem;white-space:pre';ta.oninput=function(){x.code=ta.value;dirty()};ta.onchange=function(){render()};
  cs.append(mk('div',{className:'lr'},[n,ib('✕','Supprimer ce shader',function(){if(S.fx.mode==='c:'+x.id)S.fx.mode='iris';S.fx.custom.splice(j,1);after()})]),ta,
   btn('Tester le code',function(){var er=window.FXm?FXm.test(ta.value):'indisponible';msg(er?'✗ Erreur dans le code : '+er:'✓ Le code est valide. Clique sur « Utiliser ».')}),
   btn(S.fx.mode==='c:'+x.id?'✓ Utilisé sur le site':'Utiliser sur le site',function(){x.code=ta.value;S.fx.mode='c:'+x.id;S.fx.on=true;after()}))});
 cs.append(btn('+ Nouveau shader',function(){var x={id:uid(),n:'Mon shader',code:EXC};S.fx.custom.push(x);after()},'add'));
 g.append(cs);B.append(g)}
function snd(k){var o=SNDON;SNDON=true;SND.play(k);SNDON=o}
function fxSound(B){var g;
 g=G('Sons','Sons synthétisés, légers. Le visiteur peut les couper avec le bouton ♪ en haut de page.');
 g.append(chkF(S.snd,'show','Afficher le bouton son aux visiteurs'),chkF(S.snd,'def','Son activé par défaut (dès le premier clic du visiteur)'),
  selF(S.snd,'th','Ambiance sonore',[['cristal','Cristal (clochettes)'],['boise','Boisé (notes pincées)'],['bulle','Bulle (gouttes)'],['retro','Rétro (8 bits)'],['orgue','Orgue (voix chaude)'],['sombre','Sombre (graves)']]),
  fld(S.snd,'vol','Volume général','r',{min:0,max:1,step:.05}),fld(S.snd,'pitch','Hauteur des notes (demi-tons)','r',{min:-12,max:12,step:1}),fld(S.snd,'len','Longueur des notes','r',{min:.4,max:2.5,step:.05}),fld(S.snd,'rev','Écho / réverbération','r',{min:0,max:1,step:.05}),chkF(S.snd,'hov','Petits sons au survol'),fld(S.tx,'sndCr','Petit texte de crédit du son (bas de page, vide = rien)','t'));
 g.append(btn('▶ Clic',function(){snd('click')}),btn('▶ Changement de disque',function(){snd('switch')}),btn('▶ Disque secret',function(){snd('egg')}),btn('▶ Site cassé',function(){snd('break')}));
 B.append(g);
 g=G('Nappe d’ambiance continue','Un fond sonore qui tourne en boucle. Coche-la, puis règle-la : tout est modifiable.',false);
 g.append(chkF(S.snd,'amb','Activer la nappe en continu'),selF(S.snd,'pk','Type de nappe',[['nappe','Nappe douce (accord)'],['sombre','Nappe sombre'],['vent','Vent'],['cloches','Cloches lointaines']]),
  fld(S.snd,'pv','Volume de la nappe','r',{min:0,max:.4,step:.01}),fld(S.snd,'pn','Note de base (demi-tons)','r',{min:-12,max:12,step:1}),fld(S.snd,'pb','Brillance','r',{min:0,max:1,step:.05}),fld(S.snd,'pm','Mouvement / vitesse des ondulations','r',{min:0,max:1,step:.05}));
 g.append(btn('▶ Écouter la nappe (7 s)',function(){SND.demo()}));
 B.append(g);
 g=G('Mes propres sons (.mp3 ou .wav)','Remplace les sons synthétisés par tes fichiers. 20 Mo maximum par fichier. Les sons courts (clic, survol…) doivent être brefs.',false);
 var SK=[['click','Clic'],['hover','Survol'],['switch','Changement de disque'],['tap','Appui sur le disque'],['egg','Disque secret'],['break','Site cassé'],['ok','Succès'],['err','Erreur'],['focus','Clic dans un champ (contact, e-mail…)'],['key','Frappe au clavier']];
 SK.forEach(function(k){var cur=S.snd.files[k[0]],fi=mk('input',{type:'file',accept:'audio/*,.mp3,.wav,.ogg,.m4a'});
  fi.onchange=function(){upAudio(fi.files[0],function(u){S.snd.files[k[0]]=u;after()})};
  var box=sub(k[1]);box.append(mk('p',{className:'fh',textContent:cur?'✓ Ton fichier est utilisé.':'Son synthétisé par défaut.'}),fi);
  if(cur){box.append(btn('▶ Écouter',function(){try{var a=new Audio(cur);a.volume=Math.min(1,S.snd.vol);a.play()}catch(e){}}),btn('Retirer',function(){delete S.snd.files[k[0]];after()}))}
  g.append(box)});
 B.append(g);
 g=G('Ma nappe d’ambiance (fichier en boucle)','Un fichier .mp3 ou .wav qui tourne en boucle en fond. Il remplace la nappe synthétisée (garde « Activer la nappe en continu » coché).',false);
 var pfi=mk('input',{type:'file',accept:'audio/*,.mp3,.wav,.ogg,.m4a'});pfi.onchange=function(){var fl=pfi.files[0];upAudio(fl,function(u){S.snd.pf=u;S.snd.amb=true;S.snd.pfn=((fl&&fl.name)||'').replace(/\.[^.]+$/,'')||'Ma nappe';after()})};
 g.append(chkF(S.snd,'amb','Activer la nappe en continu'),fld(S.snd,'pfn','Nom du son d’ambiance (affiché en bas de la page)','t'),fld(S.tx,'sndHint','Petit message « touche pour lancer le son » (vide = aucun)','t'),fld(S.tx,'sndLbl','Début de la phrase en bas de page','t'),mk('p',{className:'fh',textContent:S.snd.pf?'✓ Ta nappe est utilisée.':'Aucun fichier : la nappe synthétisée est utilisée.'}),pfi,mk('p',{className:'fh',textContent:'Si ton fichier est long (plus de 230 s ou ~9 Mo), seul un extrait de 230 s maximum est gardé et mis en boucle sans coupure. Règle-le AVANT de choisir le fichier :'}),mk('label',{className:'f'},[lab('Début de l’extrait (secondes)'),mk('input',{type:'number',min:0,step:1,value:PFO.st,oninput:function(){PFO.st=+this.value||0}})]),mk('label',{className:'f'},[lab('Durée de la boucle (secondes, 10 à 230)'),mk('input',{type:'number',min:10,max:230,step:1,value:PFO.d,oninput:function(){PFO.d=+this.value||230}})]),fld(S.snd,'pfv','Volume de ma nappe','r',{min:0,max:1,step:.05}),fld(S.tx,'sndCr','Texte de secours (inutilisé)','t'));
 if(S.snd.pf)g.append(btn('▶ Écouter (8 s)',function(){SND.preview(S.snd.pf,S.snd.pfv,8)}),btn('Retirer ma nappe',function(){S.snd.pf='';S.snd.pfn='';after()}));
 B.append(g)}
function tabEg(B){
 var g=G('Secret n°2 : le site cassé','Le visiteur le déclenche en cliquant 7 fois vite sur ton nom en haut à gauche, ou en tapant « glitch ». Le site bascule dans une ambiance sombre et glitchée, le son change et le clip bugue. Un bouton « Réparer » (ou taper « repare ») remet tout en ordre.',false);
 g.append(chkF(S.eg2,'on','Activer le secret du site cassé'),fld(S.eg2,'hid','Message caché (très discret, apparaît par éclairs en bas de l’écran cassé)','t'),chkF(S.eg2,'txt','Afficher aussi les textes rouges du site cassé (message d’entrée, phrases qui clignotent, autres titres brouillés). Le titre derrière le disque reste toujours brouillé.'),fld(S.tx,'brkM','Message quand le site casse','t'),fld(S.tx,'repB','Texte du bouton pour réparer (apparaît après 5 s)','t'),fld(S.eg2,'words','Phrases qui apparaissent par flashs (une par ligne)','a',{rows:5}));
 g.append(fld(S.eg2,'threat','Texte de la scène finale (par défaut en hébreu : « Le troisième sera le dernier »)','t'),fld(S.tx,'gone','Petit mot si on essaie de le relancer après la réparation (jusqu’au prochain rechargement)','t'),mk('p',{className:'fh',textContent:'Quand le visiteur clique sur « Réparer », le site tremble de plus en plus, un énorme texte en 3D (« C’est la fin » en hébreu) s’approche et le menace, puis disparaît et le site est réparé.'}));
 g.append(btn('▶ Tester : casser le site',function(){GONE=false;setBroken(true)}),btn('▶ Voir la scène finale',function(){GONE=false;if(!BRK)setBroken(true);setTimeout(repairSeq,1200)}),btn('Réparer (direct)',function(){setBroken(false)}));B.append(g)}
function pongTests(){var box=mk('div',{className:'f'});box.append(lab('Tester avec un CD précis (partie test : le score n’est pas enregistré)'));
 var row=mk('div',{style:'display:flex;flex-wrap:wrap;gap:.4rem'});
 S.discs.forEach(function(d){if(d.myt)return;row.append(btn('▶ '+(d.mys?'« ? »':(d.n||d.k)),function(){if(window.PONG)PONG.open({force:d.k})}))});
 var row2=mk('div',{style:'display:flex;flex-wrap:wrap;gap:.4rem;margin-top:.5rem'});row2.append(mk('span',{className:'fh',style:'width:100%',textContent:'Voir l’écran du jeu à… (partie test : tu démarres directement à ce score)'}));[1,2,3,4,5,6,7,8,9,10].forEach(function(n){row2.append(btn(n<10?n+'00 000':'1 000 000',function(){if(window.PONG)PONG.open({force:'gry',score:n*100000})}))});box.append(row2);
 row.append(btn('▶ Disque noir',function(){if(window.PONG)PONG.open({force:'noir'})}),btn('▶ AHABAH',function(){if(window.PONG)PONG.open({force:'ahabah'})}),btn('▶ Disque fêlé',function(){if(window.PONG)PONG.open({force:'fele'})}),btn('▶ Le disque éclate',function(){if(window.PONG)PONG.open({force:'eclat'})}),btn('▶ Adversaire EEVEIE',function(){if(window.PONG)PONG.open({force:'eeveie'})}),btn('▶ Adversaire TAKU',function(){if(window.PONG)PONG.open({force:'taku'})}),btn('▶ Site en or (puzzle réussi)',function(){try{goldSite()}catch(e){}}));box.append(row);return box}
function upMusic(file,cb){if(!file)return;if(file.size>15*1048576){msg('Fichier trop lourd (15 Mo max).');return}
 if(!(/^audio\//.test(file.type||'')||/\.(mp3|m4a|aac|wav|ogg|oga|opus)$/i.test(file.name||''))){msg('Choisis un fichier audio (.mp3 conseillé).');return}
 function inline(){if(file.size>4*1048576){msg('Fichier trop lourd ici (4 Mo max dans l’aperçu). Raccourcis-le ou envoie-le depuis ton site (#admin).');return}var fr=new FileReader();fr.onload=function(){cb(fr.result);msg('✓ Musique enregistrée. Pense à publier.')};fr.onerror=function(){msg('Lecture du fichier impossible.')};fr.readAsDataURL(file)}
 if(isSA()&&asg){msg('Envoi de la musique…');asg.upload(file).then(function(r){cb(r.url);msg('✓ Musique enregistrée. Pense à publier.')},function(){inline()});return}
 inline()}
function musRow(k,name){var m=S.pong.mus=S.pong.mus||{},cur=m[k],box=mk('div',{className:'f'});
 var def=PMUS[{setsuna:'commun',gry:'commun',yukyu:'rare',mystere:'mystere',noir:'noir',ahabah:'ahabah',eeveie:'eeveie',taku:'taku'}[k]||'commun'];
 var fi=mk('input',{type:'file',accept:'audio/*,.mp3,.m4a,.wav,.ogg'});fi.onchange=function(){upMusic(fi.files[0],function(u){m[k]=u;after()})};
 box.append(mk('p',{className:'fh',textContent:'🎵 Musique : '+(cur?'ton propre son':'Komiku, « '+def+' »'+(k==='setsuna'||k==='gry'?' (la même pour les deux communs)':''))}),mk('label',{className:'f'},[lab('Mettre mon propre son pour '+name),fi]));
 if(cur)box.append(btn('▶ Écouter 10 s',function(){if(window.SND)SND.preview(cur,.6,10)}),btn('Revenir à la musique par défaut',function(){delete m[k];after()}));
 return box}
var PMUS={commun:'Poupi Great Adventures: The Arcade Game',rare:'Space Bicycle',mystere:'Fracture of the universe will happen soon',noir:'Mr Angst Theme',ahabah:'Universe big takedown',eeveie:'Disco Cat',taku:'Cat Race Challenge'},PDF={setsuna:[40,1],gry:[40,1],yukyu:[13,2],mystere:[5,3]};
function pdf(d){return PDF[d.k]||(d.mys?[5,3]:d.egg?[13,2]:[40,1])}
function pongSum(){var dr=S.pong.drop||{},L=[],tot=0,n=function(x,d){var v=parseFloat(String(x==null||x===''?d:x).replace(',','.'));return isFinite(v)?Math.max(0,v):d},f=function(v){return String(Math.round(v*100)/100).replace('.',',')+' %'};
 S.discs.forEach(function(d){if(d.myt)return;var o=dr[d.k]||{},w=n(o.w,pdf(d)[0]);tot+=w;L.push([d.mys?'« ? »':(d.n||d.k),w])});
 var g=Math.min(10,n(S.pong.noir,.5)),a=Math.min(10,n(S.pong.ahabah,1.5)),r=Math.max(0,100-g-a);
 return 'Chances réelles à chaque partie : '+L.map(function(x){return x[0]+' '+f(tot?r*x[1]/tot:0)}).join(' · ')+' · AHABAH '+f(a)+' · DISQUE NOIR '+f(g)}
function pongDrops(){var box=mk('div'),dr=S.pong.drop=S.pong.drop||{};
 S.discs.forEach(function(d){if(d.myt)return;var df=pdf(d),o=dr[d.k]=dr[d.k]||{w:String(df[0]),p:String(df[1])},nm=d.mys?'« ? »':(d.n||d.k);if(o.p!=null)o.p=String(o.p);
  var card=mk('div',{style:'border:1px solid var(--line,#333);border-radius:.8rem;padding:.6rem .8rem;margin:.6rem 0'});
  card.append(mk('p',{style:'margin:0 0 .3rem;font-weight:600',textContent:'💿 '+nm}),fld(o,'w','Chance de sortir (en %)','t'),selF(o,'p','Puissance',[['1','Commun · ×1'],['2','Rare · ×2 points, tir puissant'],['3','Légendaire · ×3 points, tir surpuissant, raquette large']]),musRow(d.k,nm));box.append(card)});
 return box}
function tabJeu(B){
 var g=G('Le jeu','PONG « YUU VS YOU » façon borne d’arcade : yuu en haut, le joueur en bas. Il s’ouvre avec le code du disque (secret n°4, onglet 🔒 Secrets). À chaque partie, un de tes CD est tiré au sort et devient la balle.');
 g.append(fld(S.pong,'lives','Nombre de vies (1 à 5)','t'),fld(S.pong,'goals','Buts pour battre yuu (3 à 10). Ensuite : « mode éternité », de plus en plus dur.','t'),fld(S.pong,'msg','Message quand yuu est vaincu','t'),fld(S.pong,'fel','Disque fêlé au tirage (×10 points, une seule vie) : 1 chance sur…','t'),fld(S.pong,'ecl','Le disque éclate en pleine partie (3 éclats pendant 20 s) : 1 chance sur…','t'),fld(S.pong,'eev','Adversaire EEVEIE à la place de yuu (autre musique, loopings, pas plus difficile, avec n’importe quel disque) : 1 chance sur…','t'),musRow('eeveie','EEVEIE'),fld(S.pong,'taku','Adversaire TAKU à la place de yuu (autre musique, loopings, pas plus difficile, avec n’importe quel disque) : 1 chance sur…','t'),musRow('taku','TAKU'),
  btn('▶ Lancer le mini-jeu (tirage normal)',function(){if(window.PONG)PONG.open()}),pongTests());B.append(g);
 g=G('Les CD : chances, puissance et musique','Chaque CD a sa chance de sortir, en % (0 = jamais). Avec le disque d’or et AHABAH, le total fait 100 % (sinon, tout est ajusté en proportion). Chaque disque a sa propre musique, sauf les deux communs (SETSUNA II et GRY) qui partagent la même. Tu peux mettre ton propre son pour chacun.',false);
 var psum=mk('p',{className:'fh',textContent:pongSum()}),g1=g;g.append(pongDrops(),psum);B.append(g);
 g=G('Disques mythiques (ultra secrets)','Ils n’apparaissent jamais dans le défilement du tirage : le tirage « bug » et en donne un par surprise. AHABAH (doré) et le DISQUE NOIR (sombre) ont la texture du disque « ? » (si tu changes le « ? », ils suivent), chacun avec sa chance et sa musique. AHABAH : ×5 points, bouclier d’or, tir surpuissant, raquette large. DISQUE NOIR : ×10 points mais le plus dur de tous (yuu joue au maximum, balle très rapide, raquette étroite, aucun bouclier). Tout le jeu prend leur couleur. Dans le classement, ils s’affichent à côté du nom du joueur qui les a eus, et ont leur onglet « MYTHIQUES ».',false);
 g.append(fld(S.pong,'ahabah','Chance d’AHABAH (doré), en % (1,5 = 3 parties sur 200 ; 0 = jamais)','t'),fld(S.pong,'noir','Chance du DISQUE NOIR, en % (0,5 = une partie sur 200 ; 0 = jamais)','t'),musRow('ahabah','AHABAH'),musRow('noir','le DISQUE NOIR'));B.append(g);
 [g1,g].forEach(function(x){x.addEventListener('input',function(){psum.textContent=pongSum()})});
 g=G('Musique des parties','Une légère musique d’arcade pendant les parties, selon le CD tiré. Par défaut : morceaux de Komiku (album « Poupi’s incredible adventures! »), dans le domaine public (CC0), installés automatiquement sur ton site au déploiement. Dans l’aperçu Claude, seuls tes propres sons peuvent être joués.',false);
 g.append(chkF(S.pong,'mon','Jouer la musique pendant les parties'),fld(S.pong,'mv','Volume de la musique','r',{min:0,max:1,step:.05}));B.append(g);
 g=G('Classement mondial','Sur ton site (yuu-store.com), le classement est commun à tous les visiteurs et reste pour toujours (100 meilleurs gardés, 10 affichés). Pour retirer un nom : ajoute sur Netlify la variable SCORES_ADMIN_KEY (un mot de passe), puis ouvre yuu-store.com/.netlify/functions/scores?key=TON_MOT_DE_PASSE&del=ABC (ou &reset=1 pour tout effacer). Ici, dans l’aperçu, ce sont les scores de cet appareil.',false);
 g.append(btn('Effacer les scores de cet appareil',function(){try{localStorage.removeItem('yuu-pong-top')}catch(e){}msg('Scores de cet appareil effacés.')}));B.append(g)}
function dshT(k){var P=$('pn');if(P&&!P.hidden){EDIT=false;P.hidden=true;$('ed').hidden=false;document.body.classList.remove('pn-open')}scrollTo(0,0);setTimeout(function(){if(window.dshGo)dshGo(k)},450)}
function tabEg3(B){
 var g0=G('Le disque qui se brise (page d’accueil)','Très rarement, le grand disque se brise quand le visiteur le touche. Trois effets possibles, chacun avec sa chance (une visite sur…) : le PUZZLE (il remet les éclats en place, le disque brille ensuite en doré), la VERSION CASSÉE (tout le site passe en noir et blanc fissuré et la musique se dérègle, jusqu’au rechargement), la GRAVITÉ (tout le site s’effondre puis se reconstruit). Dans tous les cas, le compteur s’affiche : « Tu es la 37e personne à avoir brisé le disque. »',false);
 g0.append(chkF(S.brk,'on','Activer le disque qui se brise'),fld(S.brk,'puz','Puzzle : une visite sur…','t'),fld(S.brk,'cas','Version cassée : une visite sur…','t'),fld(S.brk,'gra','Gravité : une visite sur…','t'),
  mk('p',{className:'fh',textContent:'Tester (le panneau se ferme, l’effet se lance tout de suite) :'}),btn('▶ Puzzle',function(){dshT('puz')}),btn('▶ Version cassée (jusqu’au rechargement)',function(){dshT('cas')}),btn('▶ Gravité',function(){dshT('gra')}));B.append(g0);

 var g=G('Secret n°3 : le disque mystère','Si le visiteur ne touche à rien pendant un moment (page d’accueil ouverte), un petit bouton « ? » apparaît à côté du sélecteur de disques et clignote doucement. S’il clique dessus, le disque mystère apparaît alors et s’affiche. Tu règles son aspect dans Disques (il y est marqué « secret »), comme les autres.',false);
 g.append(chkF(S.eg3,'on','Activer le disque mystère'),fld(S.eg3,'sec','Secondes d’inactivité avant qu’il apparaisse','t'),chkF(S.eg3,'snd','Quand le visiteur touche le « ? », activer le son (musique sombre du disque mystère) même s’il était coupé'),btn('▶ Tester : faire apparaître le bouton « ? »',function(){showMyq()}),btn('▶ Révéler directement le disque',function(){mysGo()}),btn('Le cacher à nouveau (cette session)',function(){hideMyq();MYSON=false;if(window.SND)SND.sync();dsig='';ACT=0;dswSync();heroUpd();bgr();if(window.__gl)__gl.cd()}));B.append(g);
 g=G('Secret n°4 : le code du disque → mini-jeu','Le visiteur glisse le disque dans un ordre précis (le code). Si le code est bon, le mini-jeu s’ouvre : PONG « YUU VS YOU » (yuu en haut, le joueur en bas), façon borne d’arcade. À chaque partie, un de tes CD est tiré au sort et devient la balle, avec le même rendu que sur la page. Classement commun à tous les visiteurs (initiales en 3 lettres, avec le CD obtenu). Lettres du code : D = vers la droite, G = vers la gauche, H = vers le haut, B = vers le bas. Le compte à rebours et le message sont gardés de côté : tu peux les remettre avec le menu « Ce que le code ouvre ».',false);
 g.append(chkF(S.eg4,'on','Activer le code du disque'),fld(S.eg4,'code','Code (ex. DDDG = trois glissés à droite puis un à gauche)','t'),selF(S.eg4,'mode','Ce que le code ouvre',[['game','Le mini-jeu PONG (YUU VS YOU)'],['count','Le compte à rebours'],['msg','Un message'],['both','Le compte à rebours et le message']]),
  mk('p',{className:'fh',textContent:'Le mini-jeu se règle dans son onglet : 🎮 Mini-jeu (vies, CD et taux de drop, disque d’or, musique, tests, classement).'}),btn('🎮 Ouvrir l’onglet Mini-jeu',function(){TAB='jeu';fillBody()}),
  lab('Compte à rebours et message (mis de côté)'),fld(S.eg4,'msg','Message (ex. « Rendez-vous bientôt. »)','a',{rows:3}),fld(S.eg4,'date','Date de sortie (AAAA-MM-JJTHH:MM, heure de Paris, ex. 2027-01-01T00:00)','t'),fld(S.eg4,'lbl','Titre au-dessus du compte à rebours','t'),fld(S.eg4,'pre','Petit mot (ex. « dans »)','t'),fld(S.eg4,'end','Message quand la date est passée','t'),btn('▶ Tester : afficher l’écran',function(){cdnClose();cdnOpen()}));B.append(g);
 g=G('Secret n°5 : la face cachée','Il faut d’abord débloquer le 3e disque (le disque secret : 5 appuis rapides sur le disque, ou taper « yukyu »). Si le visiteur retourne le disque sur son dos, puis le maintient appuyé sans bouger pendant environ 2 secondes (le disque reste figé et la gravure apparaît d’abord très faiblement), la gravure apparaît sur son dos argenté, avec le lien vers un produit caché (invisible sur le site). Le visiteur est ensuite emmené directement sur la page du produit caché (réglable ci-dessous).',false);
 g.append(chkF(S.eg5,'on','Activer la face cachée'),chkF(S.eg5,'go','Ouvrir directement la page du produit caché dès que la gravure apparaît'),chkF(S.eg5,'chip','Afficher aussi un petit lien cliquable sous le disque'),fld(S.eg5,'l1','Texte gravé en haut','t'),fld(S.eg5,'l3','Texte gravé à l’intérieur (ex. numéro d’édition ou code)','t'),fld(S.eg5,'host','Adresse de ton site à graver (ex. yuu.fr). Vide = l’adresse du site tel que visité','t'),mk('p',{className:'fh',textContent:'La ligne du bas est le lien automatique vers ton produit caché (celui marqué 🔒 dans Boutique : prix, photos et lien de paiement à y mettre).'}),
  btn('▶ Tester : graver le dos du disque secret',function(){if(!EGGON)unlockEgg();engOn(true)}),btn('Effacer la gravure (cette session)',function(){engOn(false)}),btn('Ouvrir le produit caché',function(){var p=hidP();if(p)location.hash=p.s}));B.append(g);
 g=G('Secret n°6 : l’écharpe','Une petite écharpe noire est cachée à un seul endroit de la page, tiré au hasard à chaque visite (près du formulaire de contact, ou dans le bas de page), presque invisible sur fond sombre. Le visiteur la touche pour la ramasser : sur ordinateur elle suit le curseur, sur téléphone elle reste collée en bas à droite de l’écran pendant qu’il fait défiler la page. Il doit la déposer sur « yuu » (en haut de la page) pour faire apparaître un produit caché : l’écharpe. Tu règles ce produit dans Boutique (il y est marqué 🧣). Tout redevient caché quand la page est rechargée.',false);
 g.append(chkF(S.eg6,'on','Activer l’écharpe cachée'),fld(S.eg6,'tk','Texte affiché quand elle est ramassée','a',{rows:2}),fld(S.eg6,'ok','Message quand elle est posée sur yuu','a',{rows:2}),
  btn('▶ Tester : faire apparaître le produit écharpe',function(){if(window.scfShow)scfShow()}),btn('Cacher à nouveau (cette session)',function(){if(window.scfReset)scfReset()}));B.append(g)}
function tabEg7(B){
 var g=G('Secret n°7 : le petit chat noir','Un tout petit chat noir est assis tout en haut de la section Clips, presque invisible. Quand le visiteur le touche, la photo de ton choix s’affiche en grand, avec un code de livraison offerte (celui réglé dans Boutique, groupe Panier) qu’il peut appliquer d’un geste à son panier. Sans photo, le chat n’apparaît que pour toi.',false);
 var pf=mk('input',{type:'file',accept:'image/*'});pf.onchange=function(){up(pf.files[0],function(u){S.eg7.img=u;after()},{max:1800,jpg:true})};
 g.append(chkF(S.eg7,'on','Activer le chat noir'),mk('label',{className:'f'},[lab('Photo à montrer'),pf]));
 if(S.eg7.img){g.append(mk('div',{className:'lr'},[mk('img',{src:safeImg(S.eg7.img),alt:''}),mk('span',{textContent:'Photo du chat noir'})]),btn('Retirer la photo',function(){S.eg7.img='';after()}))}
 g.append(fld(S.eg7,'cap','Légende sous la photo (facultatif)','t'),fld(S.eg7,'ctx','Phrase au-dessus du code de livraison offerte','t'),mk('p',{className:'fh',textContent:'Le chat donne aussi le code de livraison offerte. Le code se règle dans Boutique > Panier (vide = le chat ne donne pas de code).'}),btn('▶ Tester : ouvrir la photo',function(){catOpen()}));B.append(g)}
function tabMt(B){
 var g=G('Page d’ouverture / maintenance','Quand c’est activé, les visiteurs ne voient QUE cette page. Toi, tu vois toujours le site. Rien n’est visible tant que tu ne coches pas et ne publies pas.');
 g.append(chkF(S.mt,'on','Fermer le site (mode maintenance)'),btn('Voir la page telle que les visiteurs la voient',function(){MT_PRE=true;mtRender()}));B.append(g);
 g=G('Mot de passe d’accès','Permet à ton équipe d’entrer pendant la fermeture. Tu peux le changer quand tu veux (les anciens accès sont alors invalidés).');
 g.append(mk('p',{className:'fh',textContent:(S.mt.h||S.mt.hp)?'✓ Un mot de passe est défini.':'Aucun mot de passe défini : personne ne pourra entrer.'}));
 var i=mk('input',{type:'text',placeholder:'Nouveau mot de passe',autocomplete:'off'});
 g.append(mk('label',{className:'f'},[lab('Nouveau mot de passe'),i]),btn('Enregistrer ce mot de passe',function(){var v=i.value;if(v.length<8){msg('Mot de passe trop court (8 caractères minimum).');return}
  var a=new Uint8Array(16);crypto.getRandomValues(a);var salt=hx(a),nm={s:salt,kdf:'pbkdf2',it:210000};msg('Chiffrement du mot de passe…');hashPw(v,nm).then(function(h){if(!h){msg('Impossible ici : connexion non sécurisée.');return}S.mt.s=salt;S.mt.h=h;S.mt.kdf='pbkdf2';S.mt.it=210000;S.mt.hp=true;S.mt._new=1;i.value='';MT_OK=false;try{localStorage.removeItem('yuu-mt')}catch(e){}after();msg('Mot de passe enregistré. Pense à publier.')})}));
 if(S.mt.h||S.mt.hp)g.append(btn('Supprimer le mot de passe',function(){S.mt.h='';S.mt.s='';S.mt.kdf='';S.mt.it=0;S.mt.hp=false;S.mt._new=1;after()}));
 g.append(mk('p',{className:'fh',textContent:'Sur ton site en ligne, c’est le serveur qui garde la porte : le mot de passe n’est jamais envoyé aux visiteurs (même chiffré), il est vérifié par le serveur (8 essais ratés maximum par quart d’heure), et il ouvre la boutique pour une seule visite. À chaque rechargement ou réouverture de la page, la page d’ouverture revient. 8 caractères minimum.'}));B.append(g);
 g=G('Textes de la page');
 g.append(fld(S.mt,'t','Titre','t'),fld(S.mt,'d','Texte','a',{rows:3}),chkF(S.mt,'mail','Proposer de laisser son e-mail'),fld(S.mt,'ph','Champ e-mail','t'),fld(S.mt,'mb','Bouton e-mail','t'),fld(S.mt,'pl','Lien « accès équipe »','t'),fld(S.mt,'pb','Bouton mot de passe','t'),fld(S.mt,'bad','Message si le mot de passe est faux','t'));B.append(g)}
function tabLook(B){tabBg(B);tabFx(B);fxSound(B);tabEg(B)}
function tabSite(B){tabCt(B);tabMt(B)}
function tabLook2(B){tabFav(B);tabBg(B);tabFx(B);tabSsn(B)}
/* ================= saisons (selon la vraie date) ================= */
var SSN=(function(){
 var cv=null,g=null,P=[],cur='',run=false,last=0,wind=0,px=null,mx=.7,my=.2,W=0,H=0,dpr=1,T=0,prev=null,raf=0,SP={};
 function season(){var m=S.ssn&&S.ssn.mode;if(prev)return prev;if(m&&m!=='auto')return m;var d=new Date(),k=(d.getMonth()+1)*100+d.getDate();return k>=1221||k<320?'hiver':k<621?'printemps':k<922?'ete':'automne'}
 function calm(){return matchMedia('(prefers-reduced-motion:reduce)').matches}
 var OFF=false;try{OFF=localStorage.getItem('yuu-ssn-off')==='1'}catch(e){}
 function avail(){return (!!(S.ssn&&S.ssn.on&&S.ssn.mode!=='off')||!!prev)&&!calm()}
 function want(){return avail()&&(!OFF||!!prev)}
 function btnSync(){var b=document.getElementById('ssb');if(!b)return;var k=season();b.hidden=!avail();b.textContent={hiver:'❄',printemps:'🌸',ete:'☀',automne:'🍂'}[k]||'✦';b.setAttribute('aria-pressed',OFF?'false':'true');b.title=OFF?'Remettre les effets de saison':'Couper les effets de saison'}
 setTimeout(function(){var b=document.getElementById('ssb');if(b&&!b.dataset.w){b.dataset.w=1;b.addEventListener('click',function(){OFF=!OFF;try{localStorage.setItem('yuu-ssn-off',OFF?'1':'0')}catch(e){}apply()})}},0)
 function amt(){return Math.max(.1,Math.min(1,+S.ssn.amt||.6))}
 function size(){if(!cv)return;dpr=Math.min(2,devicePixelRatio||1);W=innerWidth;H=innerHeight;cv.width=Math.round(W*dpr);cv.height=Math.round(H*dpr);g.setTransform(dpr,0,0,dpr,0,0)}
 function count(k){var co=matchMedia('(pointer:coarse)').matches,lite=document.documentElement.classList.contains('lite');var n={hiver:90,printemps:26,ete:34,automne:24}[k]||20;return Math.max(5,Math.round(n*amt()*(co?.6:1)*(lite?.5:1)))}
 function sc(w,h,f){var c=document.createElement('canvas');c.width=w;c.height=h;f(c.getContext('2d'),w,h);return c}
 /* ---------- dessins préparés une fois (rapides à afficher) ---------- */
 function soft(col,core){return sc(64,64,function(x){var r=x.createRadialGradient(32,32,0,32,32,32);r.addColorStop(0,'rgba('+col+',1)');r.addColorStop(core,'rgba('+col+',.85)');r.addColorStop(1,'rgba('+col+',0)');x.fillStyle=r;x.fillRect(0,0,64,64)})}
 function crystal(){return sc(96,96,function(x){x.translate(48,48);x.strokeStyle='rgba(255,255,255,.95)';x.lineCap='round';x.shadowColor='rgba(200,225,255,.9)';x.shadowBlur=6;
  for(var i=0;i<6;i++){x.save();x.rotate(i*Math.PI/3);x.lineWidth=3.2;x.beginPath();x.moveTo(0,0);x.lineTo(0,-40);x.stroke();x.lineWidth=2.2;[[-14,9],[-25,7],[-33,5]].forEach(function(b){x.beginPath();x.moveTo(0,b[0]);x.lineTo(-b[1],b[0]-b[1]);x.moveTo(0,b[0]);x.lineTo(b[1],b[0]-b[1]);x.stroke()});x.restore()}
  x.fillStyle='#fff';x.beginPath();x.arc(0,0,4,0,7);x.fill()})}
 function petal(c1,c2){return sc(64,64,function(x){x.translate(32,34);var gr=x.createLinearGradient(0,26,0,-26);gr.addColorStop(0,c2);gr.addColorStop(.55,c1);gr.addColorStop(1,c1);x.fillStyle=gr;
  x.beginPath();x.moveTo(0,26);x.bezierCurveTo(-22,12,-20,-16,-7,-24);x.lineTo(0,-17);x.lineTo(7,-24);x.bezierCurveTo(20,-16,22,12,0,26);x.fill();
  x.strokeStyle='rgba(255,255,255,.35)';x.lineWidth=1;x.beginPath();x.moveTo(0,22);x.lineTo(0,-12);x.stroke();x.globalCompositeOperation='source-atop';var hl=x.createRadialGradient(-6,-6,0,-6,-6,22);hl.addColorStop(0,'rgba(255,255,255,.45)');hl.addColorStop(1,'rgba(255,255,255,0)');x.fillStyle=hl;x.fillRect(-32,-32,64,64)})}
 function maple(c1,c2){return sc(96,96,function(x){x.translate(48,50);var gr=x.createRadialGradient(-8,-10,4,0,0,44);gr.addColorStop(0,c2);gr.addColorStop(1,c1);x.fillStyle=gr;
  var pts=[[0,-40],[7,-22],[20,-30],[17,-12],[37,-16],[27,-2],[33,6],[14,6],[18,22],[4,14],[2,34],[-2,34],[-4,14],[-18,22],[-14,6],[-33,6],[-27,-2],[-37,-16],[-17,-12],[-20,-30],[-7,-22]];
  x.beginPath();pts.forEach(function(p,i){if(i)x.lineTo(p[0],p[1]);else x.moveTo(p[0],p[1])});x.closePath();x.fill();
  x.strokeStyle='rgba(70,25,5,.45)';x.lineWidth=1.3;x.beginPath();x.moveTo(0,34);x.lineTo(0,-36);x.moveTo(0,4);x.lineTo(30,-13);x.moveTo(0,4);x.lineTo(-30,-13);x.moveTo(0,10);x.lineTo(15,20);x.moveTo(0,10);x.lineTo(-15,20);x.stroke()})}
 function oval(c1,c2){return sc(64,96,function(x){x.translate(32,48);var gr=x.createLinearGradient(-20,0,20,0);gr.addColorStop(0,c1);gr.addColorStop(.5,c2);gr.addColorStop(1,c1);x.fillStyle=gr;
  x.beginPath();x.moveTo(0,-40);x.bezierCurveTo(26,-20,22,24,0,38);x.bezierCurveTo(-22,24,-26,-20,0,-40);x.fill();x.strokeStyle='rgba(70,30,5,.4)';x.lineWidth=1.2;x.beginPath();x.moveTo(0,44);x.lineTo(0,-36);for(var i=-2;i<3;i++){x.moveTo(0,i*12);x.lineTo(13,i*12-9);x.moveTo(0,i*12);x.lineTo(-13,i*12-9)}x.stroke()})}
 function sprites(){if(SP.ok)return;SP.ok=1;SP.snow=soft('255,255,255',.35);SP.snowB=soft('225,238,255',.15);SP.cry=crystal();
  SP.pet=[petal('#ffd3e4','#ff9cc2'),petal('#ffe6ef','#ffb7d0'),petal('#fff4f8','#ffc9dc'),petal('#ffc2d9','#f78db5')];
  SP.leaf=[maple('#b8401f','#f08a3c'),maple('#c9761c','#f7c34f'),maple('#8e2f1c','#d65a2c'),oval('#9a6a24','#d9a441'),oval('#b5541f','#eb9a3c'),maple('#a8531e','#e9b04a')];
  SP.dust=soft('255,226,160',.25);SP.bok=soft('255,236,190',.6)}
 function mk1(k,top){var z=Math.random(),o={x:Math.random()*W,y:top?-40-Math.random()*60:Math.random()*H,z:z,a:Math.random()*6.28,va:0,vx:0,vy:0,ph:Math.random()*6.28,fl:Math.random()*6.28,vf:0};
  if(k==='hiver'){o.cry=z>.86;o.r=o.cry?5+z*7:1+z*z*4.5;o.vy=12+z*46;o.va=(Math.random()-.5)*.8;o.al=.35+z*.6;o.sw=6+z*14}
  else if(k==='printemps'){o.r=5+z*7;o.vy=16+z*26;o.vx=10+Math.random()*16;o.va=(Math.random()-.5)*2;o.vf=1.5+Math.random()*3;o.i=(Math.random()*SP.pet.length)|0;o.al=.65+z*.35;o.sw=22}
  else if(k==='automne'){o.r=8+z*11;o.vy=24+z*34;o.va=(Math.random()-.5)*1.6;o.vf=1+Math.random()*2.4;o.i=(Math.random()*SP.leaf.length)|0;o.al=.7+z*.3;o.sw=34}
  else{o.r=1+z*3.2;o.vy=-3-Math.random()*7;o.vx=(Math.random()-.5)*5;o.al=.15+z*.45;o.bk=z>.88;if(o.bk)o.r=10+z*16;if(top)o.y=H+10}
  return o}
 function veil(k){var v=document.getElementById('ssnv');if(!v){v=document.createElement('div');v.id='ssnv';document.body.appendChild(v)}var a=amt();
  v.style.background=k==='hiver'?'radial-gradient(140% 100% at 50% 50%,transparent 58%,rgba(205,228,255,'+(.26*a)+') 100%),linear-gradient(180deg,rgba(190,215,255,'+(.06*a)+'),transparent 30%)':k==='ete'?'radial-gradient(80% 60% at 92% -6%,rgba(255,226,150,'+(.3*a)+'),rgba(255,180,90,'+(.08*a)+') 45%,transparent 70%)':k==='automne'?'radial-gradient(130% 90% at 50% 115%,rgba(214,110,36,'+(.16*a)+'),transparent 60%),radial-gradient(70% 50% at 10% 0%,rgba(255,190,110,'+(.08*a)+'),transparent 70%)':k==='printemps'?'radial-gradient(100% 70% at 12% -5%,rgba(255,206,228,'+(.16*a)+'),transparent 60%),radial-gradient(90% 60% at 100% 110%,rgba(200,240,210,'+(.07*a)+'),transparent 60%)':'none';
  v.style.mixBlendMode=k==='ete'?'screen':'normal';v.style.opacity=k?1:0}
 function draw3(img,o,base){var f=Math.cos(o.fl),w=o.r*2*(base||1);g.save();g.translate(o.x,o.y);g.rotate(o.a);g.scale(.25+.75*Math.abs(Math.sin(o.ph*.7+o.fl*.3)),f);g.globalAlpha=o.al*(.7+.3*Math.abs(f));var h=w*img.height/img.width;g.drawImage(img,-w/2,-h/2,w,h);g.restore()}
 function sun(){var a=amt(),sx=W*(.9+(mx-.5)*.04),sy=-H*.04;g.save();g.globalCompositeOperation='lighter';
  for(var i=0;i<6;i++){var ang=1.95+i*.13+Math.sin(T*.09+i*1.9)*.035,len=Math.hypot(W,H)*1.25,w=(30+((i*37)%70))/len*2.2,al=.07*a*(.55+.45*Math.sin(T*.35+i*1.3));
   var gr=g.createLinearGradient(sx,sy,sx+Math.cos(ang)*len,sy+Math.sin(ang)*len);gr.addColorStop(0,'rgba(255,232,170,'+al+')');gr.addColorStop(.5,'rgba(255,214,140,'+(al*.45)+')');gr.addColorStop(1,'rgba(255,210,140,0)');
   g.fillStyle=gr;g.beginPath();g.moveTo(sx,sy);g.lineTo(sx+Math.cos(ang-w)*len,sy+Math.sin(ang-w)*len);g.lineTo(sx+Math.cos(ang+w)*len,sy+Math.sin(ang+w)*len);g.closePath();g.fill()}
  var bl=g.createRadialGradient(sx,sy,0,sx,sy,Math.min(W,H)*.5);bl.addColorStop(0,'rgba(255,240,200,'+(.35*a)+')');bl.addColorStop(.3,'rgba(255,214,140,'+(.12*a)+')');bl.addColorStop(1,'rgba(255,200,120,0)');g.fillStyle=bl;g.fillRect(0,0,W,H);
  /* reflets d'objectif : alignés entre le soleil et la souris */
  var cx=W/2,cy=H/2,dx=cx-sx,dy=cy-sy;[[.35,26,'255,220,150',.08],[.6,14,'180,220,255',.07],[.85,46,'255,200,140',.05],[1.2,20,'255,240,200',.07],[1.45,70,'200,180,255',.035]].forEach(function(f){var x=sx+dx*f[0]*(1+(mx-.5)*.3),y=sy+dy*f[0]*(1+(my-.5)*.3),r=f[1]*(W<600?.7:1);var q=g.createRadialGradient(x,y,0,x,y,r);q.addColorStop(0,'rgba('+f[2]+','+(f[3]*a*1.6)+')');q.addColorStop(.7,'rgba('+f[2]+','+(f[3]*a)+')');q.addColorStop(1,'rgba('+f[2]+',0)');g.fillStyle=q;g.beginPath();g.arc(x,y,r,0,7);g.fill()});
  g.restore()}
 function frame(now){raf=0;if(!run)return;if(document.hidden){raf=requestAnimationFrame(frame);return}
  var dt=last?Math.min(.05,(now-last)/1000):.016;last=now;T+=dt;wind*=Math.pow(.25,dt);var gust=Math.sin(T*.23)*Math.sin(T*.071)*14;
  g.clearRect(0,0,W,H);var k=cur;if(k==='ete')sun();
  for(var i=0;i<P.length;i++){var o=P[i];o.ph+=dt*(k==='hiver'?.9:1.6);o.fl+=o.vf*dt;
   var wx=(wind*.5+gust)*(.4+o.z);o.x+=(o.vx+Math.sin(o.ph)*(o.sw||4)+wx)*dt;o.y+=(o.vy+(k==='automne'?Math.cos(o.ph*1.3)*14:0))*dt;o.a+=o.va*dt;
   if(o.y>H+40||o.x<-60||o.x>W+60||(k==='ete'&&o.y<-30)){P[i]=mk1(k,true);continue}
   if(k==='hiver'){if(o.cry){g.save();g.translate(o.x,o.y);g.rotate(o.a);g.globalAlpha=o.al;g.drawImage(SP.cry,-o.r,-o.r,o.r*2,o.r*2);g.restore()}else{var im=o.z<.35?SP.snowB:SP.snow,r=o.r*(o.z<.35?2.2:1.6);g.globalAlpha=o.al;g.drawImage(im,o.x-r,o.y-r,r*2,r*2)}}
   else if(k==='printemps')draw3(SP.pet[o.i],o,1);else if(k==='automne')draw3(SP.leaf[o.i],o,1.1);
   else{g.globalCompositeOperation='lighter';var tw=.55+.45*Math.sin(o.ph*2.3);g.globalAlpha=o.al*tw*(o.bk?.35:1);var r2=o.r*(o.bk?1:2.4);g.drawImage(o.bk?SP.bok:SP.dust,o.x-r2,o.y-r2,r2*2,r2*2);g.globalCompositeOperation='source-over'}}
  g.globalAlpha=1;raf=requestAnimationFrame(frame)}
 function apply(){try{btnSync()}catch(e){}var on=want(),k=on?season():'';
  if(!on){run=false;if(cv)cv.style.display='none';veil('');cur='';return}
  if(!cv){cv=document.createElement('canvas');cv.id='ssn';cv.setAttribute('aria-hidden','true');g=cv.getContext('2d');document.body.appendChild(cv);size();addEventListener('resize',size);
   addEventListener('pointermove',function(e){if(px!=null)wind=Math.max(-180,Math.min(180,wind+(e.clientX-px)*1.4));px=e.clientX;mx=e.clientX/Math.max(1,W);my=e.clientY/Math.max(1,H)},{passive:true})}
  cv.style.display='';sprites();var n=count(k);if(k!==cur||P.length!==n){cur=k;P=[];for(var i=0;i<n;i++)P.push(mk1(k,false))}veil(k);
  if(!run){run=true;last=0;if(!raf)raf=requestAnimationFrame(frame)}}
 return {apply:apply,season:season,preview:function(k){prev=k||null;cur='';apply()}}
})();
(function(){var _r3=render;render=function(){_r3.apply(this,arguments);try{SSN.apply()}catch(e){}};try{SSN.apply()}catch(e){}})();
function tabSsn(B){var g=G('Saisons','Un petit effet par-dessus le site selon la vraie date : neige en hiver, pétales au printemps, rayons de soleil en été, feuilles en automne. Discret, coupé tout seul si l’appareil rame ou si la personne a demandé moins d’animations. Le site en or (puzzle réussi) passe avant.',false);
 g.append(chkF(S.ssn,'on','Activer les saisons pour les visiteurs'),selF(S.ssn,'mode','Saison affichée',[['auto','Automatique (selon la date) · maintenant : '+({hiver:'hiver',printemps:'printemps',ete:'été',automne:'automne'})[(function(){var d=new Date(),k=(d.getMonth()+1)*100+d.getDate();return k>=1221||k<320?'hiver':k<621?'printemps':k<922?'ete':'automne'})()]],['hiver','Toujours l’hiver (neige)'],['printemps','Toujours le printemps (pétales)'],['ete','Toujours l’été (soleil)'],['automne','Toujours l’automne (feuilles)'],['off','Désactivé']]),fld(S.ssn,'amt','Intensité','r',{min:.1,max:1,step:.05}));
 var row=mk('div',{style:'display:flex;flex-wrap:wrap;gap:.4rem'});row.append(mk('p',{className:'fh',style:'width:100%',textContent:'Aperçu rapide (rien n’est enregistré) :'}));
 [['hiver','❄ Hiver'],['printemps','🌸 Printemps'],['ete','☀ Été'],['automne','🍂 Automne'],['','Fin de l’aperçu']].forEach(function(x){row.append(btn(x[1],function(){SSN.preview(x[0])}))});g.append(row);B.append(g)}

function tabSec(B){tabEg(B);tabEg3(B);tabEg7(B);if(isSA()){var g=G('Accès propriétaire (cet appareil)','Tu es connecté à ton dépôt GitHub avec ton jeton personnel. Les modifications sont publiées dans le dépôt, puis le site se met à jour tout seul en ~1 minute.');g.append(btn('Se déconnecter de cet appareil',function(){ghForget();location.hash='';location.reload()}));B.append(g)}}
var TABS=[['txt','✎ Textes',tabTxt],['cd','💿 Disques',tabCd],['look','🎨 Apparence',tabLook2],['prod','🛍 Boutique',tabProd],['pj','🎧 Média',tabPj],['snd','🔊 Sons',fxSound],['ct','✉ Contact & ouverture',tabSite],['sec','🔒 Secrets',tabSec],['jeu','🎮 Mini-jeu',tabJeu]];
var TI={txt:'Les textes de la page d’accueil, dans l’ordre de la page. Les textes de « Écouter » sont dans Média, ceux de « Contact » et « Newsletter » dans Contact.',cd:'Chaque disque a ses réglages (nom, aspect, titre, fond de page, shader, rotation). Plus bas : les réglages communs à tous.',look:'Le décor de tout le site : image de fond, couleurs, boutons, espacement, puis le shader animé.',prod:'Produits, style d’affichage et produit mis en avant.',pj:'Projets à écouter, pochettes, fichiers audio et clips vidéo.',snd:'Sons du site, nappe d’ambiance et tes propres fichiers audio.',ct:'Où arrivent les messages, formulaire de contact, newsletter, puis la page d’ouverture / maintenance avec son mot de passe.',sec:'Les secrets cachés du site (disque mystère, disque secret, code, face cachée, écharpe, chat).',jeu:'Le mini-jeu PONG « YUU VS YOU » : règles, CD et taux de drop, disques mythiques, événements rares, musique des parties, tests et classement.'};
function fillBody(){
 setTimeout(function(){try{var a=document.querySelector('#pn .tabs button[aria-selected=true]');if(a)a.scrollIntoView({inline:'center',block:'nearest'})}catch(e){}},0);
 var B=$('pb');B.innerHTML='';GN=0;if(SQT!==TAB){SQT=TAB;SQ=''}if(TI[TAB])B.append(mk('p',{className:'fh',textContent:TI[TAB]}));var sqi=mk('input',{type:'search',className:'srch',placeholder:'🔎 Chercher un réglage dans cet onglet…',value:SQ});sqi.oninput=function(){SQ=sqi.value;applySearch(B)};B.append(sqi);TABS.forEach(function(t){if(t[0]===TAB)t[2](B)});
 var gs=B.querySelectorAll('details.g');
 if(gs.length>1){var nav=mk('div',{className:'toc'}),all=function(v){gs.forEach(function(o){o.open=v})};
  nav.append(mk('span',{className:'tl',textContent:'Aller à :'}));
  gs.forEach(function(g){var b=mk('button',{className:'tc',textContent:g.dataset.n+' · '+g.querySelector('h5').textContent,onclick:function(){all(false);g.open=true;setTimeout(function(){g.scrollIntoView({block:'start',behavior:'smooth'})},30)}});b.dataset.n=g.dataset.n;nav.append(b)});
  nav.append(mk('button',{className:'tc ac',textContent:'Tout déplier',onclick:function(){all(true)}}),mk('button',{className:'tc ac',textContent:'Tout replier',onclick:function(){all(false)}}));
  gs[0].parentNode.insertBefore(nav,gs[0]);syncToc()}
 document.querySelectorAll('#pn .tabs button').forEach(function(b){b.setAttribute('aria-selected',b.dataset.t===TAB?'true':'false')});
 if(SQ)applySearch(B)}
var SQ='',SQT='';
function applySearch(B){var s=SQ.trim().toLowerCase();B.querySelectorAll('details.g').forEach(function(g){var subs=g.querySelectorAll('details');if(!s){g.hidden=false;subs.forEach(function(x){x.hidden=false});return}var hit=g.textContent.toLowerCase().indexOf(s)>=0;g.hidden=!hit;if(hit){g.open=true;subs.forEach(function(x){var h=x.textContent.toLowerCase().indexOf(s)>=0;x.hidden=!h;if(h)x.open=true})}});var tc=B.querySelector('.toc');if(tc)tc.hidden=!!s}
function openPanel(){
 var h=hdec(),p=S.products.filter(function(x){return x.s===h})[0];
 $('pn').hidden=false;$('ed').hidden=true;document.body.classList.add('pn-open');
 if(p){TAB='prod';OPEN=p.s}
 fillBody();
 if(p){var pb=$('pb'),r=pb.querySelector('[data-slug="'+p.s+'"]');if(r)pb.scrollTop=r.getBoundingClientRect().top-pb.getBoundingClientRect().top+pb.scrollTop-8}
}
function buildPanel(){
 var P=$('pn');P.innerHTML='';
 var live=mk('input',{type:'checkbox',id:'live'});
 live.onchange=function(){EDIT=live.checked;applyEdit()};
 var tabs=mk('div',{className:'tabs',role:'tablist'},TABS.map(function(t){var sp=t[1].indexOf(' '),b=mk('button',{onclick:function(){TAB=t[0];fillBody();$('pb').scrollTop=0}},[mk('span',{textContent:t[1].slice(0,sp)}),mk('span',{textContent:t[1].slice(sp+1)})]);b.dataset.t=t[0];b.setAttribute('role','tab');return b}));
 P.append(mk('div',{className:'ph'},[
  mk('div',{className:'pr'},[mk('b',{textContent:'Personnaliser le site'}),
   mk('button',{className:'sm pnmin',textContent:'↕',title:'Agrandir / réduire le panneau pour voir le site','aria-label':'Agrandir ou réduire le panneau',onclick:function(){P.classList.toggle('mini')}}),mk('button',{className:'sm',textContent:'Accueil',onclick:function(){location.hash='top'}}),
   mk('button',{className:'sm',textContent:'Fermer ✕',onclick:function(){EDIT=false;live.checked=false;applyEdit();P.hidden=true;$('ed').hidden=false;document.body.classList.remove('pn-open')}})]),
  mk('label',{className:'chk'},[live,mk('span',{textContent:'Écrire directement sur la page (clique sur un texte pour le modifier)'})]),tabs]));
 P.append(mk('div',{className:'pbd',id:'pb'}));
 P.append(mk('div',{className:'pf'},[mk('button',{id:'sv',className:'sv',disabled:true,textContent:'Enregistrer et publier',onclick:save}),mk('p',{id:'ms'})]));
 fillBody();
}
function save(){
 if(S.mt&&S.mt.gate){msg('Page verrouillée : entre d’abord le mot de passe d’accès.');return}
 msg('Enregistrement…');$('sv').disabled=true;
 (window.claude?fetch(location.href.split('#')[0],{cache:'no-store'}).then(function(r){return r.text()}):GHA.getIndex()).then(function(h){
  var re=/(<script type="application\/json" id="state">)[\s\S]*?(<\/script>)/;
  if(!re.test(h))throw new Error('page source introuvable');
  var R={};try{R=JSON.parse(h.match(/<script type="application\/json" id="state">([\s\S]*?)<\/script>/)[1])}catch(e){}
  var C=JSON.parse(JSON.stringify(S)),cm=C.mt=C.mt||{},rm=(R&&R.mt)||{};['srv','gate','k','hp'].forEach(function(k){delete cm[k]});
  if(cm._new)delete cm._new;else ['h','s','kdf','it'].forEach(function(k){if(rm[k]!=null&&rm[k]!=='')cm[k]=rm[k]});
  if(C.ct)delete C.ct.tx;
  h=h.replace(re,function(a,b,c){return b+JSON.stringify(C).replace(/</g,'\\u003c').replace(/\u2028/g,'\\u2028').replace(/\u2029/g,'\\u2029')+c});
  return art.publish(h);
 }).then(function(){if(!window.claude){$('sv').disabled=true;var m='✓ Publié. Le site en ligne se met à jour dans ~1 minute.';msg(m);try{toast(m)}catch(x){}}}).catch(function(e){$('sv').disabled=false;var m='Enregistrement impossible : '+(e&&(e.code||e.message)||'erreur');msg(m);try{toast(m)}catch(x){}});
}
function mqUpd(){var q=$('mq');if(!q)return;q.hidden=!OWN;q.classList.toggle('on',!!S.mt.on);q.textContent=S.mt.on?'🔧 Maintenance : ACTIVE (couper)':'🔧 Activer la maintenance'}
function initOwner(a,s){art=a;asg=s;buildPanel();OWN=true;document.body.classList.add('own');mtRender();$('ed').hidden=false;$('ed').onclick=openPanel;
 $('mq').onclick=function(){S.mt.on=!S.mt.on;mtRender();dirty();try{toast(S.mt.on?'Maintenance activée pour les visiteurs. Publication…':'Maintenance coupée. Publication…')}catch(e){}save()};mqUpd()}
/* ---- hors de Claude : le site s'édite et se publie dans ton dépôt GitHub (jeton personnel, gardé seulement sur ton appareil) ---- */
function ghCfg(){var v=null;try{v=localStorage.getItem('yuu-gh')}catch(e){}if(!v)try{v=sessionStorage.getItem('yuu-gh')}catch(e){}try{var c=JSON.parse(v||'null');return c&&/^[\w.-]+\/[\w.-]+$/.test(c.r||'')?c:null}catch(e){return null}}
function ghForget(){try{localStorage.removeItem('yuu-gh')}catch(e){}try{sessionStorage.removeItem('yuu-gh')}catch(e){}}
function ghApi(c,path,o){o=o||{};o.headers=Object.assign({Authorization:'Bearer '+c.t,Accept:'application/vnd.github+json','X-GitHub-Api-Version':'2022-11-28'},o.headers||{});
 return fetch('https://api.github.com/repos/'+c.r+path,o).then(function(r){if(r.ok)return r;return r.json().catch(function(){return {}}).then(function(j){var e=new Error((j&&j.message)||('HTTP '+r.status));e.code=r.status;throw e})})}
function b64(buf){var u=new Uint8Array(buf),s='';for(var i=0;i<u.length;i+=32768)s+=String.fromCharCode.apply(null,u.subarray(i,i+32768));return btoa(s)}
function ghAdapter(c){
 var ct=function(p){return '/contents/'+p.split('/').map(encodeURIComponent).join('/')};
 return {
  getIndex:function(){var q=ct('index.html')+'?ref='+encodeURIComponent(c.b);return ghApi(c,q,{cache:'no-store'}).then(function(r){return r.json()}).then(function(m){c.sha=m.sha;return ghApi(c,q,{headers:{Accept:'application/vnd.github.raw+json'},cache:'no-store'}).then(function(r){return r.text()})})},
  publish:function(h){return ghApi(c,ct('index.html'),{method:'PUT',body:JSON.stringify({message:'Mise à jour du site',content:b64(new TextEncoder().encode(h)),sha:c.sha,branch:c.b})}).then(function(r){return r.json()}).then(function(j){c.sha=j&&j.content&&j.content.sha;return j})},
  upload:function(blob){var ex=({'image/jpeg':'jpg','image/png':'png','image/webp':'webp','image/gif':'gif','audio/wav':'wav','audio/x-wav':'wav','audio/mpeg':'mp3','audio/mp4':'m4a','audio/ogg':'ogg','audio/aac':'aac'})[blob.type]||'bin',name='assets/up-'+Date.now().toString(36)+Math.random().toString(36).slice(2,6)+'.'+ex;
   return blob.arrayBuffer().then(function(ab){return ghApi(c,ct(name),{method:'PUT',body:JSON.stringify({message:'Ajout de '+name,content:b64(ab),branch:c.b})})}).then(function(){LOCAL[name]=URL.createObjectURL(blob);return {url:name,id:name}})}}}
function ghConnect(c,fresh,onErr){
 return ghApi(c,'').then(function(r){return r.json()}).then(function(j){
  if(!j.permissions||!j.permissions.push)throw new Error('Ce jeton n’a pas le droit d’écrire dans ce dépôt.');
  if(fresh){ghForget();try{(c.k?localStorage:sessionStorage).setItem('yuu-gh',JSON.stringify(c))}catch(e){}}
  if(S.mt&&S.mt.gate){try{sessionStorage.setItem('yuu-pn','1')}catch(e){}return 'gate'}
  GHA=ghAdapter(c);initOwner(GHA,GHA);try{if(sessionStorage.getItem('yuu-pn')){sessionStorage.removeItem('yuu-pn');setTimeout(openPanel,400)}}catch(e){}return true}).catch(function(e){if(e&&e.code===401&&!fresh)ghForget();if(onErr)onErr(e);return false})}
function ghLogin(){
 if($('gl'))return;
 var r=mk('input',{type:'text',placeholder:'ex : monpseudo/yuu-site',autocomplete:'off'}),b=mk('input',{type:'text',value:'main'}),k=mk('input',{type:'password',placeholder:'github_pat_…',autocomplete:'off'}),kp=mk('input',{type:'checkbox'}),er=mk('p',{className:'er'});
 var f=mk('form',{},[mk('h2',{textContent:'Accès propriétaire'}),mk('p',{textContent:'Entre le dépôt GitHub de ton site et ton jeton personnel (jeton « fine-grained » limité à ce seul dépôt, avec une date d’expiration). Ils restent uniquement sur cet appareil.'}),mk('label',{textContent:'Dépôt GitHub'}),r,mk('label',{textContent:'Branche'}),b,mk('label',{textContent:'Jeton personnel (droit « Contents : lecture et écriture »)'}),k,mk('label',{style:'display:flex;gap:.5rem;align-items:center;font-weight:400'},[kp,'Rester connecté sur cet appareil (sinon, déconnexion à la fermeture de l’onglet)']),er,mk('button',{className:'btn',type:'submit',textContent:'Se connecter'}),mk('button',{className:'btn alt',type:'button',textContent:'Annuler',onclick:function(){$('gl').remove();history.replaceState(null,'',location.pathname)}})]);
 f.onsubmit=function(e){e.preventDefault();var rv=r.value.trim().replace(/^https?:\/\/github\.com\//,'').replace(/\.git$/,'').replace(/\/+$/,'');if(!/^[\w.-]+\/[\w.-]+$/.test(rv)){er.textContent='Dépôt attendu sous la forme pseudo/nom-du-depot.';return}er.textContent='Connexion…';ghConnect({r:rv,b:b.value.trim()||'main',t:k.value.trim(),k:kp.checked},true,function(x){er.textContent='Connexion impossible : '+(x&&x.message||'erreur')}).then(function(ok){if(ok){$('gl').remove();history.replaceState(null,'',location.pathname);if(ok==='gate'){var t=$('mtS');if(t)t.textContent='Connecté ✓ Entre le mot de passe d’accès : ton panneau s’ouvrira juste après.';var w=$('mtPw');if(w)w.focus();return}openPanel()}})};
 document.body.append(mk('div',{id:'gl'},[f]))}
(async function(){
 try{
  if(!window.claude){
   (function(){var de=document.documentElement,rd=function(){de.style.visibility=''};de.style.visibility='hidden';setTimeout(rd,1500);
    fetch('maintenance.json',{cache:'no-store'}).then(function(r){return r.ok?r.json():null}).then(function(j){if(!j)return;if(j.on===true)S.mt.on=true;else if(j.on===false)S.mt.on=false;mtRender()}).catch(function(){}).then(rd)})();
   var c=ghCfg();if(c&&!S.mt.gate)ghConnect(c,false);else if(location.hash==='#admin')ghLogin();
   addEventListener('hashchange',function(){if(location.hash==='#admin'&&!OWN)ghLogin()});return}
  var u=await claude.use('user');if(!u||typeof u.isOwner!=='function'||!u.isOwner())return;
  art=await claude.use('artifact');asg=await claude.use('assets');if(!art)return;
  initOwner(art,asg);
 }catch(e){}
})();
