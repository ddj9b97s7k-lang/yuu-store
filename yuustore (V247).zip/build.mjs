// Exécuté par Netlify à chaque déploiement (voir netlify.toml). Fabrique le dossier « dist », le SEUL dossier publié :
// le code (build.mjs, netlify/, LISEZ-MOI…) et les secrets ne sont jamais accessibles depuis le site.
//   MAINTENANCE = on  -> ferme le site (seule la page d'ouverture est publiée)
//   MAINTENANCE = off -> force le site ouvert (même si le panneau dit « maintenance »)
//   (vide / absente)  -> c'est le réglage du panneau de configuration qui décide
//   MAINTENANCE_PASSWORD (facultatif) -> remplace le mot de passe d'accès équipe du panneau
import { readFileSync, writeFileSync, existsSync, mkdirSync, cpSync, rmSync, readdirSync, statSync } from 'node:fs';
import { createHash, randomBytes, pbkdf2Sync, webcrypto } from 'node:crypto';
import { RE, put, clean, pub } from './netlify/lib/porte-core.mjs';

if (!globalThis.crypto) globalThis.crypto = webcrypto;
const OUT = 'dist';
const sha = (b, n) => createHash('sha256').update(b).digest('hex').slice(0, n);
async function get(u, o = {}, ms = 60000) {
  const ac = new AbortController(); const tm = setTimeout(() => ac.abort(), ms);
  try { return await fetch(u, Object.assign({ signal: ac.signal, redirect: 'follow' }, o)); } finally { clearTimeout(tm); }
}

rmSync(OUT, { recursive: true, force: true });
mkdirSync(OUT, { recursive: true });
if (existsSync('assets')) cpSync('assets', OUT + '/assets', { recursive: true });
mkdirSync(OUT + '/assets', { recursive: true });
for (const f of ['legal.html', '404.html']) if (existsSync(f)) cpSync(f, OUT + '/' + f);
writeFileSync(OUT + '/robots.txt', 'User-agent: *\nAllow: /\n');

let html = readFileSync('index.html', 'utf8');
const m = html.match(RE);
if (!m) throw new Error('index.html : état du site introuvable');
const S = JSON.parse(m[2]);
S.mt = Object.assign({}, S.mt);

// Mot de passe équipe depuis Netlify (facultatif)
const pw = process.env.MAINTENANCE_PASSWORD;
if (pw) {
  const s = randomBytes(16).toString('hex');
  Object.assign(S.mt, { s, kdf: 'pbkdf2', it: 210000, h: pbkdf2Sync(pw, s, 210000, 32, 'sha256').toString('hex') });
  console.log('mot de passe équipe : celui de Netlify');
}

// Ouvert ou fermé
const v = String(process.env.MAINTENANCE || '').trim().toLowerCase();
const envOn = /^(1|true|on|oui|yes)$/.test(v) ? true : /^(0|false|off|non|no)$/.test(v) ? false : null;
const on = envOn === null ? !!S.mt.on : envOn;
writeFileSync(OUT + '/maintenance.json', JSON.stringify({ on, at: new Date().toISOString() }));

// Secrets du serveur : fichier lu par la porte et les fonctions, jamais publié (hors de « dist ») ni envoyé aux visiteurs
const key = randomBytes(32).toString('hex');
const full = clean(S, on);
mkdirSync('netlify/lib', { recursive: true });
writeFileSync('netlify/lib/site.mjs', '// Fabriqué à chaque déploiement par build.mjs. Ne pas publier, ne pas mettre dans GitHub.\nexport default ' +
  JSON.stringify({ on, key, mt: { h: S.mt.h || '', s: S.mt.s || '', kdf: S.mt.kdf || '', it: S.mt.it || 0 }, state: full }) + ';\n');
html = put(html, on ? pub(full) : full);
console.log('site :', on ? 'FERMÉ (seule la page d’ouverture est publiée ; mot de passe vérifié par le serveur)' : 'ouvert', '·', S.mt.h ? 'mot de passe équipe défini' : 'AUCUN mot de passe équipe');

// Logo du site : onglet du navigateur, favoris et écran d'accueil utilisent les MÊMES fichiers fixes
function pngSize(b) { return b && b.length > 24 && b.readUInt32BE(0) === 0x89504e47 ? [b.readUInt32BE(16), b.readUInt32BE(20)] : null; }
function ico(png) { // fichier .ico qui contient l'image PNG telle quelle
  const [w, h] = pngSize(png), d = Buffer.alloc(22);
  d.writeUInt16LE(0, 0); d.writeUInt16LE(1, 2); d.writeUInt16LE(1, 4);
  d.writeUInt8(w >= 256 ? 0 : w, 6); d.writeUInt8(h >= 256 ? 0 : h, 7);
  d.writeUInt16LE(1, 10); d.writeUInt16LE(32, 12); d.writeUInt32LE(png.length, 14); d.writeUInt32LE(22, 18);
  return Buffer.concat([d, png]);
}
try {
  const fav = String(S.fav || '');
  const fv = createHash('md5').update(fav).digest('hex').slice(0, 8);
  const files = ['favicon.ico', 'favicon.png', 'apple-touch-icon.png'];
  if (fav && html.includes('/favicon.ico?v=' + fv) && files.every((f) => existsSync(f))) {
    files.forEach((f) => cpSync(f, OUT + '/' + f));
    console.log('favicon : prêt (' + fv + ')');
  } else if (fav) {
    let buf = null;
    const d = fav.match(/^data:image\/png;base64,(.+)$/s);
    if (d) buf = Buffer.from(d[1], 'base64');
    else if (/^\/?assets\/[\w.-]+\.png$/i.test(fav) && existsSync(fav.replace(/^\//, ''))) buf = readFileSync(fav.replace(/^\//, ''));
    if (pngSize(buf)) {
      writeFileSync(OUT + '/favicon.png', buf); writeFileSync(OUT + '/apple-touch-icon.png', buf); writeFileSync(OUT + '/favicon.ico', ico(buf));
      html = html.replace(/<link[^>]*rel=["'](?:icon|shortcut icon|apple-touch-icon)["'][^>]*>\s*/g, '');
      html = html.replace('</head>', `<link rel="icon" href="/favicon.ico?v=${fv}" data-static><link rel="icon" type="image/png" href="/favicon.png?v=${fv}" data-static><link rel="apple-touch-icon" href="/apple-touch-icon.png?v=${fv}" data-static></head>`);
      console.log('favicon : refait depuis le logo du panneau (' + fv + ')');
    } else console.log('favicon : logo non PNG, laissé tel quel');
  } else console.log('favicon : logo par défaut (disque)');
} catch (e) { console.log('favicon : ignoré', e.message); }

// Bibliothèque 3D servie par le site lui-même (aucun script venant d'un autre site), avec contrôle d'intégrité
try {
  const u = 'https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js';
  const tag = `<script src="${u}"></script>`;
  if (html.includes(tag)) {
    const r = await get(u);
    const buf = Buffer.from(await r.arrayBuffer());
    const txt = buf.toString('utf8');
    if (r.ok && buf.length > 300000 && /threejs\.org\/license/.test(txt.slice(0, 400)) && /REVISION\s*=\s*["']128["']|"128"/.test(txt)) {
      const fn = 'three-r128-' + sha(buf, 10) + '.min.js';
      writeFileSync(OUT + '/assets/' + fn, buf);
      const sri = 'sha384-' + createHash('sha384').update(buf).digest('base64');
      html = html.replace(tag, `<script src="/assets/${fn}" integrity="${sri}"></script>`).replace(/<link rel="preconnect" href="https:\/\/cdnjs\.cloudflare\.com"[^>]*>/, '');
      console.log('three.js : servi par le site (' + fn + ')');
    } else console.log('three.js : téléchargement refusé (réponse inattendue), CDN conservé');
  }
} catch (e) { console.log('three.js : CDN conservé (', e.message, ')'); }

// Polices servies par le site (les visiteurs ne contactent plus Google)
const UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36';
async function fonts(cssUrl, name) {
  const r = await get(cssUrl, { headers: { 'User-Agent': UA } }, 30000);
  if (!r.ok) throw new Error('HTTP ' + r.status);
  let css = await r.text();
  const urls = [...new Set([...css.matchAll(/url\((https:\/\/fonts\.gstatic\.com\/[^)\s'"]+)\)/g)].map((x) => x[1]))];
  if (!urls.length || urls.length > 60) throw new Error('réponse inattendue');
  mkdirSync(OUT + '/assets/fonts', { recursive: true });
  for (const fu of urls) {
    const fr = await get(fu, {}, 30000);
    const b = Buffer.from(await fr.arrayBuffer());
    if (!fr.ok || b.length < 500 || b.toString('ascii', 0, 4) !== 'wOF2') throw new Error('fichier de police inattendu');
    const fn = 'f-' + sha(b, 12) + '.woff2';
    writeFileSync(OUT + '/assets/fonts/' + fn, b);
    css = css.split(fu).join('/assets/fonts/' + fn);
  }
  const cn = name + '-' + sha(css, 10) + '.css';
  writeFileSync(OUT + '/assets/fonts/' + cn, css);
  return '/assets/fonts/' + cn;
}
try {
  const lk = html.match(/<link href="(https:\/\/fonts\.googleapis\.com\/css2\?[^"]+)" rel="stylesheet">/);
  if (lk) {
    const local = await fonts(lk[1].replace(/&amp;/g, '&'), 'site');
    html = html.replace(lk[0], `<link href="${local}" rel="stylesheet">`)
      .replace(/<link rel="preconnect" href="https:\/\/fonts\.(googleapis|gstatic)\.com"[^>]*>\s*/g, '');
    console.log('polices : servies par le site');
  }
} catch (e) { console.log('polices : Google conservé (', e.message, ')'); }
try {
  const pg = await fonts('https://fonts.googleapis.com/css2?family=Press+Start+2P&display=swap', 'jeu');
  html = html.replace('</head>', `<meta name="yuu-pgfont" content="${pg}"></head>`);
  console.log('police du jeu : servie par le site');
} catch (e) { console.log('police du jeu : Google conservé (', e.message, ')'); }

// Musiques du mini-jeu (domaine public, CC0) : Komiku, album « Poupi's incredible adventures! » (archive.org)
const AR = 'https://archive.org/download/Komiku-Poupis_incredible_adventures/';
const MUSIC = {
  'commun-v1.mp3': 'Komiku_-_29_-_Poupi_Great_Adventures__The_Arcade_Game.mp3',
  'rare-v1.mp3': 'Komiku_-_25_-_Space_Bicycle.mp3',
  'mystere-v1.mp3': 'Komiku_-_14_-_Fracture_of_the_universe_will_happen_soon.mp3',
  'noir-v1.mp3': 'Komiku_-_35_-_Mr_Angst_Theme.mp3',
  'ahabah-v1.mp3': 'Komiku_-_58_-_Universe_big_takedown.mp3',
  'eeveie-v1.mp3': 'Komiku_-_16_-_Disco_Cat.mp3',
  'taku-v1.mp3': 'Komiku_-_19_-_Cat_Race_Challenge.mp3',
};
mkdirSync(OUT + '/assets/music', { recursive: true });
for (const [f, src] of Object.entries(MUSIC)) {
  const out = OUT + '/assets/music/' + f;
  if (existsSync(out) && statSync(out).size > 100000) { console.log('musique', f, ': déjà là'); continue; }
  try {
    const r = await get(AR + src);
    const b = Buffer.from(await r.arrayBuffer());
    const mp3 = b.length > 100000 && ((b[0] === 0x49 && b[1] === 0x44 && b[2] === 0x33) || (b[0] === 0xff && (b[1] & 0xe0) === 0xe0));
    if (r.ok && mp3) { writeFileSync(out, b); console.log('musique', f, ':', Math.round(b.length / 1024), 'Ko'); }
    else console.log('musique', f, ': non téléchargée (', r.status, ')');
  } catch (e) { console.log('musique', f, ': non téléchargée', e.message); }
}

writeFileSync(OUT + '/index.html', html);

// Dernier contrôle : aucun secret ne doit se retrouver dans les fichiers publiés (sinon le déploiement s'arrête)
const secrets = [S.mt.h, key].filter((x) => typeof x === 'string' && x.length >= 32);
const mail = S.ct && typeof S.ct.to === 'string' && /@/.test(S.ct.to) ? S.ct.to : '';
(function scan(dir) {
  for (const f of readdirSync(dir)) {
    const p = dir + '/' + f;
    if (statSync(p).isDirectory()) { scan(p); continue; }
    if (!/\.(html|js|css|json|txt|svg|xml|webmanifest)$/i.test(f)) continue;
    const t = readFileSync(p, 'utf8');
    for (const x of secrets) if (t.includes(x)) throw new Error('SÉCURITÉ : un secret se retrouverait dans ' + p + ' — déploiement arrêté');
    if (mail && t.includes(mail)) console.log('attention : ton adresse e-mail est écrite en clair dans', p.replace(OUT + '/', ''), '(c’est toi qui l’as mise dans un texte)');
  }
})(OUT);
console.log('contrôle : aucun secret dans les fichiers publiés ✓');
