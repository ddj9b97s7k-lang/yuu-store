// Porte de maintenance côté serveur (Netlify Edge Function).
// Quand le site est fermé, la page publiée ne contient QUE la page d'ouverture (produits, prix, codes et secrets n'y sont pas).
// Même si cette fonction tombait en panne, le site resterait donc fermé.
// L'équipe tape le mot de passe : la fonction « porte » (netlify/functions/porte.mjs) le vérifie et donne un passe
// à usage unique (cookie HttpOnly, 60 s). Ici, ce passe ouvre la boutique pour UNE page, puis il est effacé :
// à chaque rechargement, nouvel onglet ou réouverture, la page d'ouverture revient.
import site from '../lib/site.mjs';
import { RE, put, okTok, mkTok } from '../lib/porte-core.mjs';

const CLEAR = ['yuu_pass', 'yuu_porte'].map((n) => n + '=; Path=/; Max-Age=0; HttpOnly; Secure; SameSite=Strict');

export async function porte(html, cookie) {
  if (!site.on || !RE.test(html)) return { html, open: false };
  const tok = (String(cookie || '').match(/(?:^|;\s*)yuu_pass=(\d{10}\.[a-f0-9]{64})(?:;|$)/) || [])[1];
  if (!tok || !(await okTok(site.key, 'pass', tok))) return { html, open: false };
  const S = JSON.parse(JSON.stringify(site.state));
  // jeton « équipe » (3 h) : permet de payer pendant la fermeture, sans jamais donner le mot de passe
  S.mt = Object.assign({}, S.mt, { srv: 'ok', k: await mkTok(site.key, 'buy', 3 * 3600) });
  delete S.mt.gate;
  return { html: put(html, S), open: true };
}

export default async (request, context) => {
  if (request.method !== 'GET' && request.method !== 'HEAD') return;
  const cookie = request.headers.get('cookie') || '';
  const had = /(?:^|;\s*)yuu_(?:pass|porte)=/.test(cookie);
  if (!site.on && !had) return; // site ouvert : rien à faire
  const res = await context.next();
  const type = res.headers.get('content-type') || '';
  if (!type.includes('text/html')) return res;
  const out = await porte(await res.text(), cookie);
  const h = new Headers(res.headers);
  h.delete('content-length'); h.delete('etag');
  if (site.on) {
    h.set('Cache-Control', 'no-store');
    h.set('Vary', 'Cookie');
    if (!out.open) h.set('X-Robots-Tag', 'noindex');
  }
  if (had) { CLEAR.forEach((c) => h.append('Set-Cookie', c)); h.set('Cache-Control', 'no-store'); }
  return new Response(request.method === 'HEAD' ? null : out.html, { status: res.status, headers: h });
};

export const config = {
  path: '/*',
  excludedPath: ['/.netlify/*', '/assets/*', '/maintenance.json', '/legal.html', '/404.html', '/favicon.*', '/apple-touch-icon.png', '/robots.txt'],
  onError: 'bypass',
};
