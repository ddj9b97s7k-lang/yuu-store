// Classement commun du mini-jeu (secret n°4). Stockage : Netlify Blobs « yuu-pong » (créé tout seul, jamais effacé).
// « top » : classement général (100 meilleurs gardés, 10 affichés). « cats » : un classement par disque
// (SETSUNA, GRY, YUKYU, « ? », et MYTHIQUES = AHABAH + DISQUE NOIR), 100 gardés et 10 affichés chacun.
// Facultatif, pour modérer : variable d'environnement SCORES_ADMIN_KEY (un mot de passe de ton choix, 16 caractères minimum), puis :
//   retirer un nom : https://yuu-store.com/.netlify/functions/scores?key=TON_MOT_DE_PASSE&del=ABC
//   tout effacer   : https://yuu-store.com/.netlify/functions/scores?key=TON_MOT_DE_PASSE&reset=1
import site from '../lib/site.mjs';
import { withStore, limiter } from '../lib/limit.mjs';
import { J, same, sameOrigin, ipOf, sign } from '../lib/porte-core.mjs';
import { randomUUID } from 'node:crypto';

const BAD = new Set('ADF AFD AHH ANL ANU ARS ASS BCT BGN BIC BIT BJB BLD BNL BTD BTE BTR BZ1 CAC CAK CHT CKE CNE CNR CNT COC COK CON CUL CUM DAE DCK DIC DIE DIK EIL ENC ENK FAG FCK FDP FFS FUC FUK FUQ GAZ GNE GOU HER HIT HIV HOE HTL HTR ISI ISS JEW JIZ KAK KIL KKK KLL KLX KMS KYS LFI LFN LPN LRN LSD MDM MLP MRD MRT NAZ NEG NGA NGG NGO NGR NIG NIK NIQ NKT NPA NTA NTM NUD PCF PDD PDE PED PEN PIP PIS PNL PNS POR PRN PTN PUS PUT RAP RAT RPE SAL SEX SHO SHT SLP SLT SSS SUC SUI SUK SXE SXY TEB TGL TIT TPD TWT UMP VAG VIH WHR WPW WTF XXX ZEB ZEM ZMR ZOB'.split(' '));
// noms interdits (insultes, haine, sexe, drogue, politique), y compris écrits avec des chiffres (N1G, H1T, 5EX…)
const PAT = /^(L|N)?[RF]N|[RF]N[0-9LN]$|^SS|SS[0-9]$|^PD|PD$|88|14$|^H8|^AH[0-9]|^K[KQ]K/;
const bad = (n) => { const u = String(n || '').toUpperCase(), l = u.replace(/0/g, 'O').replace(/1/g, 'I').replace(/3/g, 'E').replace(/4/g, 'A').replace(/5/g, 'S').replace(/7/g, 'T').replace(/8/g, 'B').replace(/9/g, 'G').replace(/6/g, 'G'), l3 = u.replace(/0/g, 'O').replace(/1/g, 'L'); if (PAT.test(u) || PAT.test(l)) return true; return [u, l, l.replace(/I/g, 'L'), l3].some((x) => BAD.has(x)); };
const KEEP = 100, SHOW = 10;
const MYTH = new Set(['or', 'ahabah', 'noir']); // « or » : ancien disque d'or (scores déjà enregistrés)
const DISCS = ((site.state && site.state.discs) || []).map((d) => String(d.k)).filter((k) => /^[a-z0-9_-]{1,24}$/.test(k) && !MYTH.has(k));
const CDS = new Set(DISCS.concat([...MYTH]));
const catOf = (c) => (c === 'noir' ? 'noir' : MYTH.has(c) ? 'myth' : DISCS.includes(c) ? c : ''); // « myth » = dorés (AHABAH, ancien disque d'or), « noir » = disque noir
// ---------- anti-triche : le tirage se fait ICI (serveur), pas dans le navigateur ----------
// Au début de chaque partie, le site demande un « ticket » signé : disque tiré, fêlé ou non, éclat ou non, adversaire.
// À l'envoi du score, le ticket doit être valide, jamais utilisé, cohérent avec la partie et avec le temps réellement écoulé.
const PC = (site.state && site.state.pong) || {};
const DEFW = { setsuna: [40, 1], gry: [40, 1], yukyu: [13, 2], mystere: [5, 3] };
const POOL = ((site.state && site.state.discs) || []).filter((d) => !d.myt && /^[a-z0-9_-]{1,24}$/.test(String(d.k))).map((d) => {
  const df = DEFW[d.k] || (d.mys ? [5, 3] : d.egg ? [13, 2] : [40, 1]), o = (PC.drop || {})[d.k] || {};
  let w = parseFloat(String(o.w == null ? '' : o.w).replace(',', '.')); if (!Number.isFinite(w)) w = df[0];
  const p = Math.min(3, Math.max(1, parseInt(o.p, 10) || df[1]));
  return { k: String(d.k), w: Math.max(0, w), p };
}).filter((x) => x.w > 0);
const pcv = (x, d) => { const v = parseFloat(String(x == null || x === '' ? d : x).replace(',', '.')); return Number.isFinite(v) ? Math.min(10, Math.max(0, v)) : d; };
const rnd = () => { const a = new Uint32Array(1); crypto.getRandomValues(a); return a[0] / 4294967296; };
const rar = (k, d) => { const n = parseInt(PC[k], 10); return rnd() < 1 / (Number.isFinite(n) && n > 0 ? n : d); };
function drawDisc() {
  const aha = pcv(PC.ahabah, 1.5), noir = pcv(PC.noir, 0.5), r = rnd() * 100;
  if (r < aha) return 'ahabah';
  if (r < aha + noir) return 'noir';
  const tot = POOL.reduce((a, x) => a + x.w, 0);
  let q = rnd() * tot;
  for (const x of POOL) { q -= x.w; if (q <= 0) return x.k; }
  return POOL.length ? POOL[POOL.length - 1].k : 'setsuna';
}
const baseOf = (c) => (c === 'noir' ? 10 : c === 'ahabah' || c === 'or' ? 5 : (POOL.find((x) => x.k === c) || { p: 1 }).p);
const b64 = (s) => Buffer.from(s, 'utf8').toString('base64url');
const unb64 = (s) => Buffer.from(String(s), 'base64url').toString('utf8');
async function ticket() {
  const o = { n: randomUUID(), t: Date.now(), c: drawDisc(), f: rar('fel', 2000) ? 1 : 0, e: rar('ecl', 2000) ? 1 : 0, o: rar('eev', 200) ? 'eeveie' : rar('taku', 200) ? 'taku' : '' };
  const p = b64(JSON.stringify(o));
  return { tok: p + '.' + (await sign(site.key, 'pong|' + p)), c: o.c, f: o.f, e: o.e, o: o.o };
}
async function readTicket(tok) {
  const [p, s] = String(tok || '').split('.');
  if (!p || !s || p.length > 600 || !site.key) return null;
  if (!same(s, await sign(site.key, 'pong|' + p))) return null;
  try { const o = JSON.parse(unb64(p)); return o && typeof o === 'object' ? o : null; } catch { return null; }
}
const TICKET_MAX = 12 * 3600e3;

const pub = (l, id) => l.filter((e) => !bad(e.n)).map((e) => { const o = { n: e.n, s: e.s, d: e.d }; if (e.c) o.c = e.c; if (e.f) o.f = 1; if (id) o.me = e.id === id; return o; });
const byScore = (a, b) => b.s - a.s;
function pubCats(cats, id) { const o = {}; for (const k of Object.keys(cats)) o[k] = pub(cats[k].slice(0, SHOW), id); return o; }
async function getCats(st, top) {
  let cats = null;
  try { cats = await st.get('cats', { type: 'json' }); } catch {}
  if (cats && typeof cats === 'object' && !Array.isArray(cats)) {
    if (Array.isArray(cats.myth) && cats.myth.some((e) => e.c === 'noir')) { // les noirs ont maintenant leur propre colonne
      cats.noir = (cats.noir || []).concat(cats.myth.filter((e) => e.c === 'noir')).sort(byScore).slice(0, KEEP);
      cats.myth = cats.myth.filter((e) => e.c !== 'noir');
      await st.setJSON('cats', cats);
    }
    return cats;
  }
  // première fois : chaque classement par disque est rempli avec les scores déjà enregistrés (rien n'est perdu)
  cats = {};
  for (const e of top) { const k = catOf(e.c); if (k) (cats[k] = cats[k] || []).push(e); }
  for (const k of Object.keys(cats)) cats[k] = cats[k].sort(byScore).slice(0, KEEP);
  await st.setJSON('cats', cats);
  return cats;
}

export default async (req, context) => {
  const url = new URL(req.url);
  try {
    return await withStore('yuu-pong', async (st) => {
      let top = (await st.get('top', { type: 'json' })) || [];
      if (!Array.isArray(top)) top = [];
      const cats = await getCats(st, top);

      if (req.method === 'GET') {
        const k = url.searchParams.get('key');
        if (k !== null) {
          const adm = String(process.env.SCORES_ADMIN_KEY || '');
          const lim = await limiter(st, ipOf(req, context), [[15 * 60e3, 10]]);
          if (!lim.ok) return J({ error: 'trop' }, 429);
          if (adm.length < 16 || !same(k, adm)) { await lim.add(); return J({ error: 'clé' }, 403); }
          if (url.searchParams.get('reset') === '1') { await st.setJSON('top', []); await st.setJSON('cats', {}); return J({ ok: true, top: [], cats: {} }); }
          const del = String(url.searchParams.get('del') || '').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 3);
          if (del) {
            top = top.filter((e) => e.n !== del); await st.setJSON('top', top);
            for (const c of Object.keys(cats)) cats[c] = cats[c].filter((e) => e.n !== del);
            await st.setJSON('cats', cats);
          }
          return J({ ok: true, total: top.length, top: pub(top), cats: pubCats(cats) });
        }
        return J({ top: pub(top.slice(0, SHOW)), cats: pubCats(cats) });
      }

      if (req.method !== 'POST') return J({ error: 'method' }, 405);
      if (!sameOrigin(req)) return J({ error: 'origine' }, 403);
      let b;
      try { b = await req.json(); } catch { return J({ error: 'json' }, 400); }
      if (!b || typeof b !== 'object') return J({ error: 'json' }, 400);
      if (b.go === 1) { // début de partie : tirage côté serveur
        const lg = await limiter(st, 'go|' + ipOf(req, context), [[2500, 1], [864e5, 600]]);
        if (!lg.ok) return J({ error: 'trop' }, 429);
        await lg.add();
        return J(await ticket());
      }
      const tk = await readTicket(b.tok);
      if (!tk) return J({ error: 'ticket' }, 400);
      const n = String(b.n || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
      if (n.length !== 3 || bad(n)) return J({ error: 'nom' }, 400);
      const I = (v) => { const x = Math.floor(Number(v)); return Number.isFinite(x) ? x : -1; };
      const s = I(b.s), h = I(b.h), g = I(b.g), lv = I(b.lv), t = I(b.t), m = I(b.m) > 0 ? I(b.m) : 1;
      const c = CDS.has(String(b.c || '')) ? String(b.c) : '';
      const f = b.f === 1 || b.f === '1'; // disque fêlé : ×10
      const x = Math.max(0, I(b.x)), y = Math.max(0, I(b.y)); // éclats renvoyés / éclats marqués (le disque qui éclate)
      const base = f ? m / 10 : m;
      // Vraisemblance : le score doit pouvoir s'expliquer par la partie (renvois, buts, niveau, durée)
      if (!Number.isInteger(base) || base < 1 || (base > 5 && base !== 10) || s < 1 || s > 2e9 || h < 0 || h > 1e5 || g < 0 || g > 1e4 || lv !== g + 1 || t < 1000 || x > h || x > 400 || y > 60) return J({ error: 'score' }, 400);
      const max = m * (h * (10 * lv + 100) + g * 100 * lv + (g >= 3 ? 1000 : 0) + y * 100 * lv); // m = bonus du CD tiré (×1 à ×5, ×10 de plus s'il est fêlé)
      if (s > max || t < (h - x) * 600 + g * 900) return J({ error: 'score' }, 400);
      if (MYTH.has(c) ? base !== (c === 'noir' ? 10 : 5) : base >= 5) return J({ error: 'score' }, 400); // ×5 AHABAH, ×10 DISQUE NOIR, jamais pour un disque normal
      // le ticket : même disque, même fêlure, pas d'éclats sans éclat tiré, durée annoncée <= temps réellement écoulé, ticket récent
      const age = Date.now() - Number(tk.t);
      if (tk.c !== c || (tk.f ? 1 : 0) !== (f ? 1 : 0) || base !== baseOf(c) || (!tk.e && (x > 0 || y > 0)) || !(age >= 0 && age <= TICKET_MAX) || t > age + 1500) return J({ error: 'score' }, 400);

      // Anti-spam : un envoi toutes les 10 s et 60 par jour au maximum, par connexion
      const lim = await limiter(st, ipOf(req, context), [[10000, 1], [864e5, 60]]);
      if (!lim.ok) return J({ error: 'trop' }, 429);
      await lim.add();
      // un ticket ne sert qu'une fois
      let used = {};
      try { used = (await st.get('used', { type: 'json' })) || {}; } catch {}
      if (typeof used !== 'object' || Array.isArray(used)) used = {};
      const nk = String(tk.n).slice(0, 40);
      if (used[nk]) return J({ error: 'deja' }, 400);
      const now0 = Date.now();
      for (const k of Object.keys(used)) if (now0 - used[k] > TICKET_MAX + 3600e3) delete used[k];
      used[nk] = now0;
      await st.setJSON('used', used);

      const e = { n, s, c, d: new Date().toISOString().slice(0, 10), id: randomUUID() };
      if (f) e.f = 1;
      top.push(e);
      top = top.sort(byScore).slice(0, KEEP);
      await st.setJSON('top', top);
      const ck = catOf(c);
      let crank = 0;
      if (ck) {
        cats[ck] = (cats[ck] || []).concat(e).sort(byScore).slice(0, KEEP);
        await st.setJSON('cats', cats);
        crank = cats[ck].findIndex((x) => x.id === e.id) + 1;
      }
      const rank = top.findIndex((x) => x.id === e.id) + 1;
      return J({ rank, crank, top: pub(top.slice(0, SHOW), e.id), cats: pubCats(cats, e.id) });
    });
  } catch {
    return J({ error: 'stockage' }, 500);
  }
};
