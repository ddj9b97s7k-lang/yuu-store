// Compteur commun « Tu es la Ne personne à avoir brisé le disque » (page d'accueil). Stockage : Netlify Blobs « yuu-brise ».
// Jamais remis à zéro tout seul. Anti-abus : 5 fois par jour au maximum par connexion (l'IP n'est jamais enregistrée).
import { withStore, limiter } from '../lib/limit.mjs';
import { J, sameOrigin, ipOf } from '../lib/porte-core.mjs';

export default async (req, context) => {
  try {
    return await withStore('yuu-brise', async (st) => {
      let n = parseInt(await st.get('n'), 10) || 0;
      if (req.method === 'GET') return J({ n });
      if (req.method !== 'POST') return J({ error: 'method' }, 405);
      if (!sameOrigin(req)) return J({ error: 'origine' }, 403);
      const lim = await limiter(st, ipOf(req, context), [[864e5, 5]]);
      if (!lim.ok) return J({ n });
      await lim.add();
      n += 1;
      await st.set('n', String(n));
      return J({ n });
    });
  } catch {
    return J({ error: 'stockage' }, 500);
  }
};
