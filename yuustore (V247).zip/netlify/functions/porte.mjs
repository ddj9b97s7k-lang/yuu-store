// Vérifie le mot de passe d'accès équipe pendant la fermeture du site.
// Le mot de passe n'est jamais envoyé aux visiteurs (même chiffré) : seul ce serveur le connaît.
// Trop d'essais ratés depuis une même connexion -> bloqué un moment (8 par quart d'heure, 30 par jour).
// Bon mot de passe -> passe à usage unique (cookie HttpOnly de 60 s) que la porte consomme à la page suivante.
import site from '../lib/site.mjs';
import { withStore, limiter } from '../lib/limit.mjs';
import { J, pwOk, mkTok, sameOrigin, ipOf } from '../lib/porte-core.mjs';

export default async (req, context) => {
  if (req.method !== 'POST') return J({ error: 'method' }, 405);
  if (!sameOrigin(req)) return J({ error: 'origine' }, 403);
  if (!site.on) return J({ ok: true, open: true });
  let b;
  try { b = await req.json(); } catch { return J({ error: 'json' }, 400); }
  const pw = b && typeof b.pw === 'string' ? b.pw : '';
  if (!pw || pw.length > 200) return J({ ok: false }, 401);
  let lim = null;
  try { lim = await withStore('yuu-porte', (st) => limiter(st, ipOf(req, context), [[15 * 60e3, 8], [864e5, 30]])); } catch {}
  if (lim && !lim.ok) return J({ ok: false, error: 'trop' }, 429);
  if (!(await pwOk(site.mt, pw))) {
    if (lim) { try { await lim.add(); } catch {} } else await new Promise((r) => setTimeout(r, 1500));
    return J({ ok: false }, 401);
  }
  const tok = await mkTok(site.key, 'pass', 60);
  return J({ ok: true }, 200, { 'Set-Cookie': `yuu_pass=${tok}; Path=/; Max-Age=60; HttpOnly; Secure; SameSite=Strict` });
};
