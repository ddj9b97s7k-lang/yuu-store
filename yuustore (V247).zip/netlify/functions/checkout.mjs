// Paiement du panier : crée une session Stripe Checkout (la carte bancaire est saisie chez Stripe, jamais sur ce site).
// Les prix viennent du serveur (copie de la boutique faite au déploiement), jamais de ce qu'envoie le navigateur.
// Variable d'environnement requise sur Netlify : STRIPE_SECRET_KEY (conseillé : une clé restreinte rk_live_…)
// Pendant la fermeture du site, seule l'équipe (qui a tapé le mot de passe) peut payer.
import site from '../lib/site.mjs';
import { withStore, limiter } from '../lib/limit.mjs';
import { J, okTok, sameOrigin, ipOf } from '../lib/porte-core.mjs';

export default async (req, context) => {
  if (req.method !== 'POST') return J({ error: 'method' }, 405);
  if (!sameOrigin(req)) return J({ error: 'origine' }, 403); // seul ton site peut lancer un paiement
  if (site.on && !(await okTok(site.key, 'buy', req.headers.get('x-yuu-k')))) return J({ error: 'La boutique est fermée pour le moment.' }, 403);
  const key = process.env.STRIPE_SECRET_KEY;
  if (!key) { console.error('STRIPE_SECRET_KEY manquante'); return J({ error: 'Paiement indisponible pour le moment.' }, 500); }
  // anti-abus : 15 paiements lancés par quart d'heure et 60 par jour au maximum, par connexion
  try {
    const lim = await withStore('yuu-pay', (st) => limiter(st, ipOf(req, context), [[15 * 60e3, 15], [864e5, 60]]));
    if (!lim.ok) return J({ error: 'Trop de tentatives. Réessaie dans quelques minutes.' }, 429);
    await lim.add();
  } catch {}
  let body;
  try { body = await req.json(); } catch { return J({ error: 'json' }, 400); }
  const origin = new URL(req.url).origin;
  const S = site.state;
  const num = (v) => { const n = parseFloat(String(v ?? '').replace(',', '.').replace(/[^\d.]/g, '')); return isFinite(n) ? n : 0; };
  const cart = S.cart || {};
  if (cart.on === false) return J({ error: 'Le panier est désactivé.' }, 403);
  const items = (Array.isArray(body && body.items) ? body.items : []).slice(0, 30);
  const f = new URLSearchParams();
  let sub = 0, i = 0;
  const seen = new Set();
  for (const it of items) {
    const s = String((it && it.s) || '');
    if (seen.has(s)) continue;
    const p = (S.products || []).find((x) => x.s === s);
    const q = Math.max(1, Math.min(10, parseInt(it && it.q) || 0));
    const price = p ? num(p.p) : 0;
    if (!p || !price || price > 100000) continue;
    seen.add(s);
    const cents = Math.round(price * 100);
    f.set(`line_items[${i}][quantity]`, String(q));
    f.set(`line_items[${i}][price_data][currency]`, 'eur');
    f.set(`line_items[${i}][price_data][unit_amount]`, String(cents));
    f.set(`line_items[${i}][price_data][product_data][name]`, String(p.n || p.s).slice(0, 120));
    sub += price * q; i++;
  }
  if (!i) return J({ error: 'panier vide' }, 400);
  const ship = Math.round(num(cart.ship) * 100), free = num(cart.free);
  const code = String((body && body.code) || '').trim().toUpperCase().slice(0, 40);
  const okCode = !!String(cart.code || '').trim() && code === String(cart.code).trim().toUpperCase();
  const cost = okCode || (free > 0 && sub >= free) ? 0 : ship;
  const rate = String(cart.rate || '').trim();
  if (cost && /^shr_[A-Za-z0-9]+$/.test(rate)) {
    f.set('shipping_options[0][shipping_rate]', rate); // tarif créé dans ton tableau de bord Stripe
  } else {
    f.set('shipping_options[0][shipping_rate_data][type]', 'fixed_amount');
    f.set('shipping_options[0][shipping_rate_data][display_name]', cost ? 'Livraison' : 'Livraison offerte');
    f.set('shipping_options[0][shipping_rate_data][fixed_amount][amount]', String(cost));
    f.set('shipping_options[0][shipping_rate_data][fixed_amount][currency]', 'eur');
  }
  String(cart.countries || 'FR').split(',').map((c) => c.trim().toUpperCase()).filter((c) => /^[A-Z]{2}$/.test(c))
    .forEach((c, k) => f.set(`shipping_address_collection[allowed_countries][${k}]`, c));
  f.set('mode', 'payment'); f.set('locale', 'fr');
  if ((S.acct || {}).save !== false) { f.set('customer_creation', 'always'); f.set('invoice_creation[enabled]', 'true'); } // le client retrouve ses commandes dans le portail client Stripe
  f.set('success_url', origin + '/#merci'); f.set('cancel_url', origin + '/#panier');
  let j = {};
  try {
    const r = await fetch('https://api.stripe.com/v1/checkout/sessions', {
      method: 'POST', headers: { Authorization: 'Bearer ' + key, 'Content-Type': 'application/x-www-form-urlencoded' }, body: f });
    j = await r.json();
  } catch (e) { console.error('Stripe injoignable'); }
  if (!j.url) console.error('Stripe :', j.error && j.error.message);
  return j.url && /^https:\/\/checkout\.stripe\.com\//.test(j.url) ? J({ url: j.url }) : J({ error: 'Le paiement n’a pas pu démarrer. Réessaie dans un instant.' }, 502);
};
